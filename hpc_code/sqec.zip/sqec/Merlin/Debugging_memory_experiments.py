import networkx as nx
from sqec.modify_stim_circuit import (
    remove_noise_from_circuit,
)
import Merlin.add_shuttling_noise as sn
import Merlin.create_qubit_layout as cql
from sympy.abc import x, y
import numpy as np
from qldpc import circuits, codes
import matplotlib.pyplot as plt
import Merlin.combined_memory_experiment as cmex
import Merlin.BB_codes as BBcodes


# Initiate BB-code
# Initiate BB-code
codes_to_simulate = [
    codes.BBCode(
        {x: 12, y: 6},
        x**3 + y + y**2,
        y**3 + x + x**2,
    )
]


L = 12
M = 6
X = 2 * L
Y = 2 * M

A = []
B = []

A.append(BBcodes.create_x_matrix(3, L, M))
A.append(BBcodes.create_y_matrix(1, L, M))
A.append(BBcodes.create_y_matrix(2, L, M))

B.append(BBcodes.create_y_matrix(3, L, M))
B.append(BBcodes.create_x_matrix(1, L, M))
B.append(BBcodes.create_x_matrix(3, L, M))

Grid = nx.grid_2d_graph(X, Y, periodic=False, create_using=None)
Grid_check = True

(
    data_qubit_list,
    check_qubit_list,
    qubit_list,
    qubit_type,
    code_matrix,
) = cql.get_key_data(A, B)


# Choose error rates
error_rates = list(np.logspace(-3, -1.5, 4))
ratio_T1toT2 = 0
ratio_T1toshuttlinghalf = 0.004
# ratio_T1toT2  = 3.26
# ratio_T1toidlehalf  = 0.0017
# ratio_T1toshuttlinghalf  = 0.004


distance = codes_to_simulate[0].get_distance(bound=100)
error_rate = 0
noise_model = circuits.DepolarizingNoiseModel(0, include_idling_error=False)

(
    initialization,
    qec_cycle,
    readout,
    measurement_record,
    detector_record,
    qubit_ids,
) = circuits.get_memory_experiment_parts(
    codes_to_simulate[0], basis=None, num_rounds=distance
)
qec_cycle = noise_model.noisy_circuit(qec_cycle)
clean_circ = remove_noise_from_circuit(qec_cycle)
qubit_list_sn = sn.create_qubit_list(clean_circ)

decoding_kwargs = dict(
    with_BP_LSD=True, max_iter=30, bp_method="ms", lsd_method="lsd_cs", lsd_order=0
)

# Produce Tanner graph starting coordinates (suboptimal)
# Tanner_layout_init = BBcodes.get_qubit_coordinates(qubit_list, qubit_type, L, M)
# Tanner_layout = cql.translate_dictionary(Tanner_layout_init)
# fig1, ax1 = cmex.make_combined_memory_experiment_figure(codes_to_simulate,error_rates, Grid = Grid, X = X, Y = Y, Grid_check = Grid_check, starting_coord = Tanner_layout, ratio_T1toT2 = ratio_T1toT2, **decoding_kwargs)


# #Produce folded Tanner starting coordinates (semi-optimized)
# folded_Tanner_layout_init = cql.create_qubit_layout(qubit_list, X, Y)
# folded_Tanner_layout =cql.translate_dictionary(folded_Tanner_layout_init)
# fig2, ax2 = cmex.make_combined_memory_experiment_figure(codes_to_simulate,error_rates, Grid = Grid, X = X, Y = Y, Grid_check = Grid_check, starting_coord = folded_Tanner_layout, ratio_T1toT2 = ratio_T1toT2, **decoding_kwargs)

# Produce optimized starting coordinates.
optimized_layout_init, Grid, X1, Y1 = cql.get_optimized_qubit_layout(A, B, L, M)
optimized_layout = cql.translate_dictionary(optimized_layout_init)
fig3, ax3 = cmex.make_combined_memory_experiment_figure(
    codes_to_simulate,
    error_rates,
    Grid=Grid,
    X=X1,
    Y=Y1,
    Grid_check=Grid_check,
    starting_coord=optimized_layout,
    ratio_T1toT2=ratio_T1toT2,
    **decoding_kwargs,
)


# cmex.make_combined_memory_experiment_figure(codes_to_simulate,error_rates, Grid = Grid, X = X, Y = Y, Grid_check = Grid_check, starting_coord = Tanner_layout, **decoding_kwargs)
# print(circ)
plt.show()
