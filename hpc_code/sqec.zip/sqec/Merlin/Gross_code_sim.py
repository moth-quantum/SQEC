import networkx as nx
from sqec.modify_stim_circuit import (
    remove_noise_from_circuit,
)
import Merlin.add_shuttling_noise as sn
import Merlin.create_qubit_layout as cql
from sympy.abc import x, y
import qldpc
import numpy as np
import sinter
from collections.abc import Sequence
from qldpc import circuits, codes, decoders
import matplotlib.pyplot as plt
import os


def get_label(
    code: codes.ClassicalCode | codes.QuditCode,
    distance_trials: bool | int = False,
) -> str:
    """Get a label for a code in a figure.

    If the code distance is not known, use a given number of trials to estimate it.
    """
    known_distance = code.get_distance_if_known()
    if isinstance(known_distance, int):
        return f"$d={known_distance}$"
    if not distance_trials:
        return f"[{len(code)}, {code.dimension}]"
    distance_estimate = code.get_distance_bound(num_trials=int(distance_trials))
    return f"[{len(code)}, {code.dimension}, d <= {distance_estimate}]"


def run_combined_memory_experiments(
    codes_to_simulate: Sequence[codes.QuditCode],
    error_rates: Sequence[float] = list(np.logspace(-3, -2, 3)),
    max_shots: int = 10**5,
    max_errors: int = 100,
    distance_trials: int = 100,
    Grid: nx.Graph = nx.grid_2d_graph(12, 24, periodic=False, create_using=None),
    X: int = 12,
    Y: int = 24,
    Grid_check: bool = False,
    starting_coord: dict = {},
    **decoding_kwargs: object,
) -> list[sinter.TaskStats]:
    """Use sinter to simulate memory cycles of the given codes.

    This function ...
      1. Builds a memory experiment for each code.
      2. Adds a depolarizing noise to all gates, at the provided error rates.
      2. Wraps each noisy circuit in a `sinter.Task``.
      3. Runs batched Monte Carlo sampling with `sinter.collect`.

    Args:
        codes_to_simulate: The codes we wish to simulate.
        error_rates: The i.i.d. probabilities of a depolarizing error after each gate.
        max_shots: Stop sampling the circuit after this many shots.
        max_errors: Stops the sampling process after this many errors have been seen in samples
            taken from the circuit.
        distance_trials: If the code distance is not known, estimate it with this many trials.
            The estimated distance determines the number of rounds of syndrome measurement.
        **decoding_kwargs: Arguments to pass to the decoder.

    Returns:
        A `sinter` stats object aggregating shots, errors, and metadata for downstream plotting.
    """

    #    Grid = nx.grid_2d_graph(X, Y, periodic=False, create_using=None)

    # noise_models = {
    #     prob: circuits.DepolarizingNoiseModel(prob, include_idling_error=False)
    #     for prob in error_rates
    # }

    tasks = []
    custom_decoders = {}  # each code is going to need its own decoder
    for code_index, code in enumerate(codes_to_simulate):
        distance = code.get_distance(bound=distance_trials)

        # Collect the components of the memory experiment.  In particular, we will need the record
        # of detectors and qubit indices.
        (
            initialization,
            qec_cycle,
            readout,
            measurement_record,
            detector_record,
            qubit_ids,
        ) = circuits.get_memory_experiment_parts(code, basis=None, num_rounds=distance)

        # Identify detectors associated with X-type and Z-type stabilizers (parity checks).
        detectors_x = detector_record.get_events(*qubit_ids.checks_x)
        detectors_z = detector_record.get_events(*qubit_ids.checks_z)

        # Build a decoder that separately decodes X and Z sectors to predict X and Z observables.
        # Here X observables are numbered 0, 1, ..., code.dimension - 1, and Z observables are
        # numbered code.dimension, code.dimension + 1, ..., code.dimension * 2 - 1.
        decoder = decoders.SubgraphSinterDecoder(
            (detectors_x, detectors_z),  # X/Z detectors
            (
                range(code.dimension),
                range(code.dimension, 2 * code.dimension),
            ),  # X/Z observables
            **decoding_kwargs,
        )
        decoder_name = f"decoder_{code_index}"
        custom_decoders[decoder_name] = decoder

        noise_model_init = qldpc.circuits.DepolarizingNoiseModel(
            0, include_idling_error=False
        )
        qec_cycle = noise_model_init.noisy_circuit(qec_cycle)
        clean_circ = remove_noise_from_circuit(qec_cycle)
        # test_qubits = sn.create_qubit_list(clean_circ)
        #        starting_coord = create_qubit_layout(test_qubits, X, Y)
        shuttling_routes = sn.determine_shuttling_routes(
            clean_circ, starting_coord, Grid, X, Y, Grid_check
        )

        print("Shuttling routes determined.")

        for prob in error_rates:
            # noise_model = qldpc.circuits.DepolarizingNoiseModel(prob, include_idling_error=False)

            # qec_cycle = noise_model.noisy_circuit(qec_cycle)
            # #return qec_cycle
            # clean_circ = remove_noise_from_circuit(qec_cycle)
            # #return clean_circ
            # test_qubits = sn.create_qubit_list(clean_circ)
            # #The next four lines create a qubit-layout for the starting coordinates. It is expected to be highly suboptimal.
            # # i = 0
            # # for qubit in test_qubits:
            # #     starting_coord[qubit] = (i // 12, i % 12)
            # #     i = i + 1

            # starting_coord = create_qubit_layout(test_qubits, X, Y)

            # shuttling_routes = sn.determine_shuttling_routes(clean_circ, starting_coord, Grid)

            noisy_circuit = (
                initialization
                + sn.add_shuttling_noise_new(clean_circ, shuttling_routes, Grid, prob)
                + readout
            )
            # noisy_circuit = initialization + noise_model.noisy_circuit(qec_cycle) + readout
            tasks.append(
                sinter.Task(
                    circuit=noisy_circuit,
                    decoder=decoder_name,
                    json_metadata={"label": get_label(code), "prob": prob},
                )
            )

    return sinter.collect(
        num_workers=os.cpu_count() - 2,
        max_shots=max_shots,
        max_errors=max_errors,
        tasks=tasks,
        custom_decoders=custom_decoders,
    )


def make_combined_memory_experiment_figure(
    codes_to_simulate: Sequence[codes.QuditCode],
    error_rates: Sequence[float] = list(np.logspace(-6, -3, 4)),
    max_shots: int = 10**5,
    max_errors: int = 100,
    distance_trials: int = 100,
    figsize: tuple[int, int] = (5, 4),
    Grid: nx.Graph = nx.grid_2d_graph(12, 24, periodic=False, create_using=None),
    X: int = 12,
    Y: int = 24,
    Grid_check: bool = False,
    starting_coord: dict = {},
    **decoding_kwargs: object,
) -> tuple[plt.Figure, plt.Axes]:
    """Use sinter to simulate memory cycles of the given codes, and plot the results.

    Args:
        codes_to_simulate: The codes we wish to simulate.
        error_rates: The i.i.d. probabilities of a depolarizing error after each gate.
        max_shots: Stop sampling the circuit after this many shots.
        max_errors: Stops the sampling process after this many errors have been seen in samples
            taken from the circuit.
        distance_trials: If the code distance is not known, estimate it with this many trials.
            The estimated distance determines the number of rounds of syndrome measurement.
        figsize: The size of the figure to produce.
        **decoding_kwargs: Arguments to pass to the decoder.

    Returns:
        The matplotlib.pyplot figure and axis.
    """
    # return run_combined_memory_experiments(
    #     codes_to_simulate, error_rates, max_shots, max_errors, distance_trials, **decoding_kwargs
    # )
    stats = run_combined_memory_experiments(
        codes_to_simulate,
        error_rates,
        max_shots,
        max_errors,
        distance_trials,
        Grid,
        X,
        Y,
        Grid_check,
        starting_coord,
        **decoding_kwargs,
    )

    figure, axis = plt.subplots(figsize=figsize)
    sinter.plot_error_rate(
        ax=axis,
        stats=stats,
        x_func=lambda stats: stats.json_metadata["prob"],
        group_func=lambda stats: stats.json_metadata["label"],
    )

    axis.axline(
        (0, 0),
        slope=1,
        color="k",
        linestyle=":",
        label=r"$p_{\mathrm{log}}=p_{\mathrm{phys}}$",
    )
    axis.loglog()
    axis.set_xlabel(r"physical error rate")
    axis.set_ylabel(r"logical error rate")
    axis.legend(loc="best")
    axis.grid(which="both")
    figure.tight_layout()

    return figure, axis


codes_to_simulate = [
    codes.BBCode(
        {x: 12, y: 6},
        x**3 + y + y**2,
        y**3 + x + x**2,
    )
]

# i = 0
# for qubit in test_qubits:
#     starting_coord[qubit] = (i // 12, i % 12)
#     i = i + 1

X = 12
Y = 24
Grid = nx.grid_2d_graph(X, Y, periodic=False, create_using=None)
Grid_check = True

# starting_coord = create_qubit_layout(test_qubits, X, Y)

# starting_coord = find_bbcode_layouts.get_best_known_layout_params(gross_code, )

error_rates = list(np.logspace(-3, -1.5, 4))
# ratio_T1toT2  = 3.26
# ratio_T1toidlehalf  = 0.0017
# ratio_T1toshuttlinghalf  = 0.004


distance = codes_to_simulate[0].get_distance(bound=100)
error_rate = 0
noise_model = circuits.DepolarizingNoiseModel(0, include_idling_error=False)

(
    initialization,
    qec_cycle,
    readout,
    measurement_record,
    detector_record,
    qubit_ids,
) = circuits.get_memory_experiment_parts(
    codes_to_simulate[0], basis=None, num_rounds=distance
)
qec_cycle = noise_model.noisy_circuit(qec_cycle)
clean_circ = remove_noise_from_circuit(qec_cycle)
qubit_list = sn.create_qubit_list(clean_circ)

# i = 0
# for qubit in test_qubits:
#     starting_coord[qubit] = (i // 12, i % 12)
#     i = i + 1


starting_coord = cql.create_qubit_layout(qubit_list, X, Y)

# starting_coord = find_bbcode_layouts.get_best_known_layout_params(gross_code, )


decoding_kwargs = dict(
    with_BP_LSD=True, max_iter=30, bp_method="ms", lsd_method="lsd_cs", lsd_order=0
)
make_combined_memory_experiment_figure(
    codes_to_simulate,
    error_rates,
    Grid=Grid,
    X=X,
    Y=Y,
    Grid_check=Grid_check,
    starting_coord=starting_coord,
    **decoding_kwargs,
)
# print(circ)
plt.show()
