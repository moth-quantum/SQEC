import stim
import networkx as nx
from sqec.modify_stim_circuit import (
    remove_noise_from_circuit,
    split_at_ticks,
    apply_custom_noise,
    reassemble_circuit,
    TWO_QUBIT_GATES,
)
import numpy as np


def create_qubit_list(circuit):
    """
    Given a circuit, it creates the list of qubits used.
    """
    qubit_list = []
    for inst in circuit:
        targets = inst.targets_copy()
        for i in range(len(targets)):
            if targets[i] not in qubit_list:
                if "rec" not in str(targets[i]):
                    qubit_list.append(targets[i])
    return qubit_list


def find_partner_qubit(circuit_tick, qubit_list):
    """
    Within a tick, it creates a dictionary that encodes which pairs of qubits interact with each other.
    If a qubit has no interaction, its dictionary entry is the string "solo".
    """
    pair = {}
    for inst in circuit_tick:
        if inst.name in TWO_QUBIT_GATES:
            targets = inst.targets_copy()
            for i in range(0, len(targets), 2):
                if targets[i] not in pair:
                    if targets[i + 1] not in pair:
                        pair[targets[i]] = targets[i + 1]
        else:
            targets = inst.targets_copy()
            for i in range(len(targets)):
                pair[targets[i]] = "solo"
    for inst in qubit_list:
        if inst not in pair:
            if inst not in pair.values():
                pair[inst] = "solo"

    return pair


def Grid_distance(coord1, coord2):
    distance = abs(coord1[0] - coord2[0]) + abs(coord1[1] - coord2[1])
    return distance


def euclidean_distance(coord1, coord2):
    distance = np.sqrt((coord1[0] - coord2[0]) ** 2 + (coord1[1] - coord2[1]) ** 2)
    return distance


def build_meeting_graph_old(coord: dict, Grid, pair, Radius, X, Y, Grid_check):
    """
    For a given constellation of qubits, it build the graph that associates to every qubit(pair) those locations on the grid that they can both reach within distance Radius.
    """
    G_R = nx.Graph()
    for ind in pair.keys():  # this buuilds two nodes for bnoth B,A and A,B - I think this makes the algo find two unique non overlapping spaces, so this might break everything since qubits may be sent to tw different places
        G_R.add_node((ind, pair[ind]))
    G_R.add_nodes_from(Grid)

    for ind in pair.keys():
        for node in Grid:
            if pair[ind] in coord.keys():
                if Grid_check:
                    if Grid_distance(coord[ind], node) <= Radius:
                        if Grid_distance(coord[pair[ind]], node) <= Radius:
                            # if (
                            #     min(
                            #         abs(coord[ind][0] - node[0]),
                            #         X - abs(coord[ind][0] - node[0]),
                            #     )
                            #     + min(
                            #         abs(coord[ind][1] - node[1]),
                            #         Y - abs(coord[ind][1] - node[1]),
                            #     )
                            #     <= Radius
                            # ):
                            # if (
                            #     min(
                            #         abs(coord[pair[ind]][0] - node[0]),
                            #         X - abs(coord[pair[ind]][0] - node[0]),
                            #     )
                            #     + min(
                            #         abs(coord[pair[ind]][1] - node[1]),
                            #         Y - abs(coord[pair[ind]][1] - node[1]),
                            #     )
                            #     <= Radius
                            # ):
                            G_R.add_edge((ind, pair[ind]), node)
                else:
                    if nx.shortest_path_length(Grid, coord[ind], node) <= Radius:
                        if (
                            nx.shortest_path_length(Grid, coord[pair[ind]], node)
                            <= Radius
                        ):
                            G_R.add_edge((ind, pair[ind]), node)
            else:
                if Grid_check:
                    if (
                        min(
                            abs(coord[ind][0] - node[0]),
                            X - abs(coord[ind][0] - node[0]),
                        )
                        + min(
                            abs(coord[ind][1] - node[1]),
                            Y - abs(coord[ind][1] - node[1]),
                        )
                        <= Radius
                    ):
                        G_R.add_edge((ind, pair[ind]), node)
                else:
                    if nx.shortest_path_length(Grid, coord[ind], node) <= Radius:
                        G_R.add_edge((ind, pair[ind]), node)

    return G_R


def build_meeting_graph(coord: dict, Grid, travelers: set, Radius, X, Y, Grid_check):
    G_R = nx.Graph()
    G_R.add_nodes_from(travelers, bipartite=0)
    G_R.add_nodes_from(Grid, bipartite=1)

    for traveler in travelers:
        for node in Grid:
            if len(traveler) == 2:  # interacting
                q1, q2 = traveler
                if Grid_check:
                    if (
                        Grid_distance(coord[q1], node) <= Radius
                        and Grid_distance(coord[q2], node) <= Radius
                    ):
                        G_R.add_edge(traveler, node)
                else:
                    if (
                        nx.shortest_path_length(Grid, coord[q1], node) <= Radius
                        and nx.shortest_path_length(Grid, coord[q2], node) <= Radius
                    ):
                        G_R.add_edge(traveler, node)
            else:  # solo
                q1 = traveler[0]
                if Grid_check:
                    if Grid_distance(coord[q1], node) <= Radius:
                        G_R.add_edge(traveler, node)
                else:
                    if nx.shortest_path_length(Grid, coord[q1], node) <= Radius:
                        G_R.add_edge(traveler, node)
    return G_R


def build_min_weight_meeting_graph(
    coord: dict, Grid, travelers: set, Radius, X: int, Y: int, Grid_check: bool
):
    """
    Given a Grid on which qubits can move, coordinates of the qubits, a radius, and pairs of qubits in the set travelers,
    we build a graph as follows:
    The vertices are the pairs of qubits in travelers (some qubits have no partner and appear as a tuple (q,)) and
    the vertices in the Grid. A traveler is connected to a node in the Grid if and only if the coordinates of all qubits
    in the traveler have distance at most Radius to the node in the Grid. We give each edge the weight of the longest distance
    between a traveler and the node in the Grid.
    """
    G_R = nx.Graph()
    G_R.add_nodes_from(travelers, bipartite=0)
    G_R.add_nodes_from(Grid, bipartite=1)

    for traveler in travelers:
        for node in Grid:
            if len(traveler) == 2:  # interacting
                q1, q2 = traveler
                if Grid_check:
                    if (
                        Grid_distance(coord[q1], node) <= Radius
                        and Grid_distance(coord[q2], node) <= Radius
                    ):
                        G_R.add_edge(
                            traveler,
                            node,
                            weight=(
                                Grid_distance(coord[q1], node)
                                + Grid_distance(coord[q2], node)
                            ),
                        )
                else:
                    if (
                        nx.shortest_path_length(Grid, coord[q1], node) <= Radius
                        and nx.shortest_path_length(Grid, coord[q2], node) <= Radius
                    ):
                        G_R.add_edge(
                            traveler,
                            node,
                            weight=(
                                nx.shortest_path_length(Grid, coord[q1], node)
                                + nx.shortest_path_length(Grid, coord[q2], node)
                            ),
                        )
            else:  # solo
                q1 = traveler[0]
                if Grid_check:
                    if Grid_distance(coord[q1], node) <= Radius:
                        G_R.add_edge(
                            traveler, node, weight=Grid_distance(coord[q1], node)
                        )
                else:
                    if nx.shortest_path_length(Grid, coord[q1], node) <= Radius:
                        G_R.add_edge(
                            traveler,
                            node,
                            weight=nx.shortest_path_length(Grid, coord[q1], node),
                        )

    return G_R


def get_min_weight_meeting_points(
    coord: dict, Grid, pair, X: int, Y: int, Grid_check: bool
):
    """
    Given the current coordinates of all qubits on the grid and their next pairing partner,
    determines meeting points for all qubit(pairs). It

    It returns a dictionary whose keys are all qubits and whose values are vertices of Grid.
    """
    travelers = set()
    for q, p in pair.items():
        if p == "solo":
            travelers.add((q,))
        else:
            ordered_pair = (q, p) if q.value < p.value else (p, q)
            travelers.add(ordered_pair)

    R = 0
    while True:
        G_R = build_min_weight_meeting_graph(
            coord, Grid, travelers, R, X, Y, Grid_check
        )
        try:
            perf_match = nx.bipartite.minimum_weight_full_matching(
                G_R, top_nodes=travelers, weight="weight"
            )
        except ValueError:
            R += 1
        else:
            # The next three lines could be replaced simply by break, since minimum_weight_full_matching only returns perfect matchings.
            if all(t in perf_match for t in travelers):
                print(f"Produced a maximal matching for radius {R}.")
                break

    meeting_points = {}
    for traveler in travelers:
        meet_node = perf_match[traveler]
        for q in traveler:
            meeting_points[q] = meet_node

    return meeting_points


def get_meeting_points(coord: dict, Grid, pair, X, Y, Grid_check):
    """
    Given the current coordinates of all qubits on the grid and their next pairing partner,
    determines meeting points for all qubit(pairs).
    It returns a dictionary whose keys are all qubits and whose values are vertices of Grid.
    """
    # remove duplicates, seems like this can cause issues with bipartate maximum matching
    travelers = set()
    for q, p in pair.items():
        if p == "solo":
            travelers.add((q,))
        else:
            ordered_pair = (q, p) if q.value < p.value else (p, q)
            travelers.add(ordered_pair)

    R = 0
    while True:
        G_R = build_meeting_graph(coord, Grid, travelers, R, X, Y, Grid_check)

        perf_match = nx.bipartite.maximum_matching(G_R, top_nodes=travelers)

        if all(t in perf_match for t in travelers):
            print(f"Produced a maximal matching for radius {R}.")
            break
        else:
            R += 1

    meeting_points = {}
    for traveler in travelers:
        meet_node = perf_match[traveler]
        for q in traveler:
            meeting_points[q] = meet_node

    return meeting_points


def get_meeting_points_old(coord: dict, Grid, pair, X, Y, Grid_check):
    """
    Given the current coordinates of all qubits on the grid and their next pairing partner,
    determines meeting points for all qubit(pairs).
    It returns a dictionary whose keys are all qubits and whose values are vertices of Grid.
    """
    R = 0
    cond = True
    while cond:
        G_R = build_meeting_graph(coord, Grid, pair, R, X, Y, Grid_check)
        perf_match = nx.bipartite.maximum_matching(
            G_R, Grid.nodes()
        )  # We could replace Grid.nodes() by pair.keys(), I think.
        print("Produced a maximal matching for radius " + str(R) + ".")
        print(perf_match)
        check1 = True  # The next few lines create a check, whether every qubit appears in an edge of the matching. If so, our matching is sufficiently large.
        for ind in pair.keys():
            check2 = False
            for nb in G_R.neighbors((ind, pair[ind])):
                check2 = (
                    check2 or (ind, nb) == perf_match[(ind, pair[ind])]
                )  # This will always return false since perf_match[(ind, pair[ind])] reutrns only the coord and not (0,(1,1)) like what you are comparing to.
            # for edge in perf_match:
            #     check2 = check2 or (ind, pair[ind]) in edge
            check1 = check1 and check2
        if check1:
            #        if nx.is_perfect_matching(G_R, perf_match): #I would like to use this function, but I think our desired matchings may not be perfect in general.
            # perf_match = list(perf_match)
            cond = False
        else:
            R = R + 1
    meeting_points = {}
    for ind in pair:
        meeting_points[ind] = perf_match[(ind, pair[ind])]
        meeting_points[pair[ind]] = perf_match[(ind, pair[ind])]
    # for edge in perf_match:
    #     for ind in pair:
    #         if (ind, pair[ind]) in edge:
    #             for i in edge:
    #                 if i != (ind, pair[ind]):
    #                     meet_up = i
    #             meeting_points[ind] = meet_up
    #             meeting_points[pair[ind]] = meet_up

    return meeting_points


def create_shuttling_errors(
    qubit_list,
    coord,
    meeting_points,
    Grid,
    p_base,
    ratio_T1toT2: float = 3.26,
    ratio_T1toidlehalf: float = 0.0017,
    ratio_T1toshuttlinghalf: float = 0.004,
):
    """
    Given a list of qubits and their travel itineraries (from coord to meeting_points), creates a dictionary shuttling_data that indicates for every qubit the following data:
    shuttling distance
    idling time
    T1 and T2 idling error probability
    shuttling and idling error probability
    total error probability
    """
    shuttling_data = {}
    shuttling_distance = {}
    idling_time = {}
    shuttling_probability = {}
    idling_probability = {}
    # idling_probabilityT1 = {}
    # idling_probabilityT2 = {}

    for qubit in qubit_list:
        shuttling_distance[qubit] = nx.shortest_path_length(
            Grid, coord[qubit], meeting_points[qubit]
        )

    tick_time = max(shuttling_distance.values())

    p_1qubit = p_base  # This will likely be a ratio in general.

    for qubit in qubit_list:
        idling_time[qubit] = tick_time - shuttling_distance[qubit]
        shuttling_probability[qubit] = 1 - (1 - p_1qubit * ratio_T1toshuttlinghalf) ** (
            2 * shuttling_distance[qubit]
        )
        # idling_probabilityT1[qubit] = 1 - (1 - p_1qubit) ** idling_time[qubit]
        # idling_probabilityT2[qubit] = (
        #     1 - (1 - p_1qubit * ratio_T1toT2) ** idling_time[qubit]
        # )
        # idling_probability[qubit] = (
        #     idling_probabilityT1[qubit] + idling_probabilityT2[qubit]
        # )
        idling_probability[qubit] = 1 - (1 - p_1qubit * ratio_T1toidlehalf) ** (
            2 * idling_time[qubit]
        )
        shuttling_data[qubit] = {
            "base": p_base,
            # "T1": idling_probabilityT1[qubit],
            # "T2": idling_probabilityT2[qubit],
            "total idling probability": idling_probability[qubit],
            "shuttling distance": shuttling_distance[qubit],
            "idling time": idling_time[qubit],
            "shuttling error probability": shuttling_probability[qubit],
            "shuttling+idling error probability": 1
            - (1 - shuttling_probability[qubit])
            * (1 - idling_probability[qubit]),  # p_base,
            # "total error probability": 1
            # - (1 - ratio_idlingtoshuttling * p_1qubit) ** (shuttling_probability[qubit])
            # * (1 - p_1qubit) ** (idling_probability[qubit]),
            "2-qubit gate probability": ratio_T1toT2 * p_1qubit,
        }

    return shuttling_data


def create_paired_shuttling_errors(shuttling_data, pair):
    """
    Given shuttling data, creates a dictionary that associates the shuttling data to pairs of qubits.
    """
    paired_shuttling_error = {}
    for qubit in shuttling_data.keys():
        if qubit in pair.keys():
            if pair[qubit] == "solo":
                paired_shuttling_error[(qubit, "solo")] = [
                    (
                        "DEPOLARIZE1",
                        shuttling_data[qubit]["shuttling+idling error probability"],
                        (qubit,),
                    )
                ]  # In the last entry of the triple: Should it be qubit or should it be 0? Check in the modify_stim_circuit file.
            else:
                paired_shuttling_error[(qubit, pair[qubit])] = [
                    (
                        "DEPOLARIZE1",
                        shuttling_data[qubit]["shuttling+idling error probability"],
                        (qubit,),
                    ),
                    (
                        "DEPOLARIZE1",
                        shuttling_data[pair[qubit]][
                            "shuttling+idling error probability"
                        ],
                        (pair[qubit],),
                    ),
                    (
                        "DEPOLARIZE2",
                        shuttling_data[qubit][
                            "2-qubit gate probability"
                        ],  # 2-qubit error.
                        (qubit, pair[qubit]),
                    ),
                ]

    return paired_shuttling_error


def add_shuttling_noise(
    ideal_circuit,
    starting_coord: dict,
    Grid,
    p_base,
    ratio_T1toT2: float = 3.26,
    ratio_T1toidlehalf: float = 0.0017,
    ratio_T1toshuttlinghalf: float = 0.004,
    Grid_check: bool = False,
):
    """
    Adds noise to an ideal circuit. 1-qubit gates and 2-qubit gates get noise added based on a noise model specified via
    the input probabilities and ratios and specified by the function create_shuttling_error.

    The noisy circuit also receives a shuttling stage in every tick where every qubit gets a noise error based on the amount of time spent shuttling and idling.
    The noise model is specified by the input probabilities and ratios and by the function create_shuttling_error.
    """

    ideal_circuit = remove_noise_from_circuit(ideal_circuit)

    qubit_list = create_qubit_list(ideal_circuit)

    tick_list = split_at_ticks(ideal_circuit)

    current_coord = starting_coord

    noisy_tick_list = []

    for tick in tick_list:
        if not (
            ("DETECTOR" in str(tick)) or ("rec" in str(tick)) or ("-" in str(tick))
        ):
            pair = find_partner_qubit(tick, qubit_list)
            meeting_points = get_meeting_points(current_coord, Grid, pair, Grid_check)
            single_shuttling_data = create_shuttling_errors(
                qubit_list,
                current_coord,
                meeting_points,
                Grid,
                p_base,
                ratio_T1toT2,
                ratio_T1toidlehalf,
                ratio_T1toshuttlinghalf,
            )
            paired_shuttling_data = create_paired_shuttling_errors(
                single_shuttling_data, pair
            )
            noisy_tick_list.append(apply_custom_noise(tick, paired_shuttling_data))
        else:
            noisy_tick_list.append(tick)
        current_coord = meeting_points
    noisy_circuit = reassemble_circuit(noisy_tick_list, insert_ticks=True)

    diagram = noisy_circuit.diagram("timeline-svg")
    with open("diagram.svg", "w") as f:
        print(diagram, file=f)

    return noisy_circuit


def determine_min_weight_shuttling_routes(
    ideal_circuit, starting_coord: dict, Grid, X: int, Y: int, Grid_check: bool
):
    """
    Takes a (noiseless) circuit, starting coordinates for all qubits, and the Grid that the qubit can move on
    and returns a dictionary, that associates to every tick in the ideal circuit a dictionary that
    associates to every qubit its location after that tick.
    These shuttling routes are chosen so that the longest travel distance is minimized and - within that - the total sum
    of travel distances is minimized.
    """
    ideal_circuit = remove_noise_from_circuit(ideal_circuit)
    qubit_list = create_qubit_list(ideal_circuit)
    tick_list = split_at_ticks(ideal_circuit)
    current_coord = starting_coord

    shuttling_routes = []  # Dictionary whose keys are numbers from 0 to number of ticks.
    shuttling_routes.append({})
    for qubit in qubit_list:
        shuttling_routes[0][qubit] = current_coord[qubit]

    for tick in tick_list:
        if not (
            ("DETECTOR" in str(tick)) or ("rec" in str(tick)) or ("-" in str(tick))
        ):
            pair = find_partner_qubit(tick, qubit_list)
            meeting_points = get_min_weight_meeting_points(
                current_coord, Grid, pair, X, Y, Grid_check
            )
            shuttling_routes_tick = {}
            for qubit in qubit_list:
                shuttling_routes_tick[qubit] = meeting_points[qubit]
            shuttling_routes.append(shuttling_routes_tick)
        current_coord = meeting_points

    return shuttling_routes


def determine_shuttling_routes(ideal_circuit, starting_coord, Grid, X, Y, Grid_check):
    """
    Takes a (noiseless) circuit, starting coordinates for all qubits, and the Grid that the qubit can move on
    and returns a dictionary, that associates to every tick in the ideal circuit a dictionary that
    associates to every qubit its location after that tick.
    The shuttling routes are chosen to minimize the largest travel distance. We do not optimize anything else.
    """
    ideal_circuit = remove_noise_from_circuit(ideal_circuit)
    qubit_list = create_qubit_list(ideal_circuit)
    tick_list = split_at_ticks(ideal_circuit)
    current_coord = starting_coord

    shuttling_routes = []  # Dictionary whose keys are numbers from 0 to number of ticks.
    shuttling_routes.append({})
    for qubit in qubit_list:
        shuttling_routes[0][qubit] = current_coord[qubit]

    for tick in tick_list:
        if not (
            ("DETECTOR" in str(tick)) or ("rec" in str(tick)) or ("-" in str(tick))
        ):
            pair = find_partner_qubit(tick, qubit_list)
            meeting_points = get_meeting_points(
                current_coord, Grid, pair, X, Y, Grid_check
            )
            shuttling_routes_tick = {}
            for qubit in qubit_list:
                shuttling_routes_tick[qubit] = meeting_points[qubit]
            shuttling_routes.append(shuttling_routes_tick)
        current_coord = meeting_points

    return shuttling_routes


def add_shuttling_noise_new(
    ideal_circuit,
    shuttling_routes,
    Grid,
    p_base,
    ratio_T1toT2: float = 3.26,
    ratio_T1toidlehalf: float = 0.0017,
    ratio_T1toshuttlinghalf: float = 0.004,
):
    """
    Adds noise to an ideal circuit. 1-qubit gates and 2-qubit gates get noise added based on a noise model specified via
    the input probabilities and ratios and specified by the function create_shuttling_error.

    The noisy circuit also receives a shuttling stage in every tick where every qubit gets a noise error based on the amount of time spent shuttling and idling.
    The noise model is specified by the input probabilities and ratios and by the function create_shuttling_error.
    """

    ideal_circuit = remove_noise_from_circuit(ideal_circuit)

    qubit_list = create_qubit_list(ideal_circuit)

    tick_list = split_at_ticks(ideal_circuit)

    current_coord = shuttling_routes[0]

    noisy_tick_list = []
    i = 1

    for tick in tick_list:
        if not (
            ("DETECTOR" in str(tick)) or ("rec" in str(tick)) or ("-" in str(tick))
        ):
            pair = find_partner_qubit(tick, qubit_list)
            # meeting_points = get_meeting_points(current_coord, Grid, pair)
            meeting_points = shuttling_routes[i]
            if "M" in str(tick):
                single_shuttling_data = create_shuttling_errors(
                    qubit_list,
                    current_coord,
                    meeting_points,
                    Grid,
                    0,
                    ratio_T1toT2,
                    ratio_T1toidlehalf,
                    ratio_T1toshuttlinghalf,
                )
            else:
                single_shuttling_data = create_shuttling_errors(
                    qubit_list,
                    current_coord,
                    meeting_points,
                    Grid,
                    p_base,
                    ratio_T1toT2,
                    ratio_T1toidlehalf,
                    ratio_T1toshuttlinghalf,
                )
            paired_shuttling_data = create_paired_shuttling_errors(
                single_shuttling_data, pair
            )
            noisy_tick_list.append(apply_custom_noise(tick, paired_shuttling_data))
            current_coord = meeting_points
            i = i + 1
        else:
            noisy_tick_list.append(tick)
    noisy_circuit = reassemble_circuit(noisy_tick_list, insert_ticks=True)

    diagram = noisy_circuit.diagram("timeline-svg")
    with open("diagram.svg", "w") as f:
        print(diagram, file=f)

    return noisy_circuit


if __name__ == "__main__":
    Grid = nx.grid_2d_graph(3, 3, periodic=False, create_using=None)

    p_base = 0.05
    ratio_T1toT2 = 1.2
    ratio_idlingtoshuttling = 2

    ideal = stim.Circuit(
        """
            H 0 1 2
            TICK
            CX 0 1
            TICK
            CX 1 2
            TICK
            M 0 1 2
        """
    )

    Grid_check = True
    test_qubits = create_qubit_list(ideal)
    starting_coord = {}
    i = 0
    for qubit in test_qubits:
        starting_coord[qubit] = (i, i)
        i = i + 1

    noisy_circuit = add_shuttling_noise(
        ideal, starting_coord, Grid, p_base, ratio_T1toT2, ratio_idlingtoshuttling
    )

    noisy_circuit.diagram("timeline-svg")
