import networkx as nx
from sqec.modify_stim_circuit import (
    remove_noise_from_circuit,
    split_at_ticks,
    apply_custom_noise,
    reassemble_circuit,
)
import Merlin.add_shuttling_noise as sn
import qldpc
import numpy as np
import sinter
from collections.abc import Sequence
from qldpc import circuits, codes, decoders
import matplotlib.pyplot as plt
import os


def get_label(
    code: codes.ClassicalCode | codes.QuditCode,
    distance_trials: bool | int = False,
) -> str:
    """Get a label for a code in a figure.

    If the code distance is not known, use a given number of trials to estimate it.
    """
    known_distance = code.get_distance_if_known()
    if isinstance(known_distance, int):
        return f"$d={known_distance}$"
    if not distance_trials:
        return f"[{len(code)}, {code.dimension}]"
    distance_estimate = code.get_distance_bound(num_trials=int(distance_trials))
    return f"[{len(code)}, {code.dimension}, d <= {distance_estimate}]"


def determine_bad_shuttling_routes(
    ideal_circuit, starting_coord, Grid, X, Y, Grid_check
):
    """
    Takes a (noiseless) circuit, starting coordinates for all qubits, and the Grid that the qubit can move on
    and returns a dictionary, that associates to every tick in the ideal circuit a dictionary that
    associates to every qubit its location after that tick.
    """
    ideal_circuit = remove_noise_from_circuit(ideal_circuit)
    qubit_list = sn.create_qubit_list(ideal_circuit)
    tick_list = split_at_ticks(ideal_circuit)
    current_coord = starting_coord

    shuttling_routes = []  # Dictionary whose keys are numbers from 0 to number of ticks.
    shuttling_routes.append({})
    for qubit in qubit_list:
        shuttling_routes[0][qubit] = current_coord[qubit]

    for tick in tick_list:
        if not (
            ("DETECTOR" in str(tick)) or ("rec" in str(tick)) or ("-" in str(tick))
        ):
            pair = sn.find_partner_qubit(tick, qubit_list)
            meeting_points = {}
            for qubit in pair.keys():
                meeting_points[qubit] = starting_coord[qubit]
                if not pair[qubit] == "solo":
                    meeting_points[pair[qubit]] = starting_coord[qubit]
            # meeting_points = sn.get_meeting_points(
            #     current_coord, Grid, pair, X, Y, Grid_check
            # )
            shuttling_routes_tick = {}
            D_max = 0
            for qubit in qubit_list:
                shuttling_routes_tick[qubit] = meeting_points[qubit]
                D_max = max(
                    D_max,
                    nx.shortest_path_length(
                        Grid, starting_coord[qubit], meeting_points[qubit]
                    ),
                )
            print(
                "The largest shuttling distance during this tick is " + str(D_max) + "."
            )
            shuttling_routes.append(shuttling_routes_tick)

    return shuttling_routes


def add_bad_shuttling_noise(
    ideal_circuit,
    shuttling_routes,
    Grid,
    p_base,
    ratio_T1toT2: float = 3.26,
    ratio_T1toidlehalf: float = 0.0017,
    ratio_T1toshuttlinghalf: float = 0.004,
):
    """
    Adds noise to an ideal circuit. 1-qubit gates and 2-qubit gates get noise added based on a noise model specified via
    the input probabilities and ratios and specified by the function create_shuttling_error.

    The noisy circuit also receives a shuttling stage in every tick where every qubit gets a noise error based on the amount of time spent shuttling and idling.
    The noise model is specified by the input probabilities and ratios and by the function create_shuttling_error.
    """

    ideal_circuit = remove_noise_from_circuit(ideal_circuit)

    qubit_list = sn.create_qubit_list(ideal_circuit)

    tick_list = split_at_ticks(ideal_circuit)

    starting_coord = shuttling_routes[0]

    noisy_tick_list = []
    i = 1

    for tick in tick_list:
        if not (
            ("DETECTOR" in str(tick)) or ("rec" in str(tick)) or ("-" in str(tick))
        ):
            pair = sn.find_partner_qubit(tick, qubit_list)
            meeting_points = shuttling_routes[i]
            if "M" in str(tick):
                single_shuttling_data = sn.create_shuttling_errors(
                    qubit_list,
                    starting_coord,
                    meeting_points,
                    Grid,
                    0,
                    ratio_T1toT2,
                    ratio_T1toidlehalf,
                    ratio_T1toshuttlinghalf,
                )
            else:
                single_shuttling_data = sn.create_shuttling_errors(
                    qubit_list,
                    starting_coord,
                    meeting_points,
                    Grid,
                    p_base,
                    ratio_T1toT2,
                    ratio_T1toidlehalf,
                    ratio_T1toshuttlinghalf,
                )
            paired_shuttling_data = sn.create_paired_shuttling_errors(
                single_shuttling_data, pair
            )
            noisy_tick_list.append(apply_custom_noise(tick, paired_shuttling_data))
            i = i + 1
        else:
            noisy_tick_list.append(tick)
    noisy_circuit = reassemble_circuit(noisy_tick_list, insert_ticks=True)

    diagram = noisy_circuit.diagram("timeline-svg")
    with open("diagram.svg", "w") as f:
        print(diagram, file=f)

    return noisy_circuit


def run_bad_combined_memory_experiments(
    codes_to_simulate: Sequence[codes.QuditCode],
    error_rates: Sequence[float] = list(np.logspace(-3, -2, 3)),
    max_shots: int = 10**5,
    max_errors: int = 100,
    distance_trials: int = 100,
    Grid: nx.Graph = nx.grid_2d_graph(12, 24, periodic=False, create_using=None),
    X: int = 12,
    Y: int = 24,
    Grid_check: bool = False,
    starting_coord: dict = {},
    ratio_T1toT2: float = 3.26,
    ratio_T1toidlehalf: float = 0.0017,
    ratio_T1toshuttlinghalf: float = 0.004,
    Distance_choice: bool = False,
    distance: int = 1,
    **decoding_kwargs: object,
) -> list[sinter.TaskStats]:
    """Use sinter to simulate memory cycles of the given codes.

    This function ...
      1. Builds a memory experiment for each code.
      2. Adds a depolarizing noise to all gates, at the provided error rates.
      2. Wraps each noisy circuit in a `sinter.Task``.
      3. Runs batched Monte Carlo sampling with `sinter.collect`.

    Args:
        codes_to_simulate: The codes we wish to simulate.
        error_rates: The i.i.d. probabilities of a depolarizing error after each gate.
        max_shots: Stop sampling the circuit after this many shots.
        max_errors: Stops the sampling process after this many errors have been seen in samples
            taken from the circuit.
        distance_trials: If the code distance is not known, estimate it with this many trials.
            The estimated distance determines the number of rounds of syndrome measurement.
        **decoding_kwargs: Arguments to pass to the decoder.

    Returns:
        A `sinter` stats object aggregating shots, errors, and metadata for downstream plotting.
    """

    #    Grid = nx.grid_2d_graph(X, Y, periodic=False, create_using=None)

    tasks = []
    custom_decoders = {}  # each code is going to need its own decoder
    for code_index, code in enumerate(codes_to_simulate):
        if not Distance_choice:
            distance = code.get_distance(bound=distance_trials)

        # Collect the components of the memory experiment.  In particular, we will need the record
        # of detectors and qubit indices.
        (
            initialization,
            qec_cycle,
            readout,
            measurement_record,
            detector_record,
            qubit_ids,
        ) = circuits.get_memory_experiment_parts(code, basis=None, num_rounds=distance)

        # Identify detectors associated with X-type and Z-type stabilizers (parity checks).
        detectors_x = detector_record.get_events(*qubit_ids.checks_x)
        detectors_z = detector_record.get_events(*qubit_ids.checks_z)

        # Build a decoder that separately decodes X and Z sectors to predict X and Z observables.
        # Here X observables are numbered 0, 1, ..., code.dimension - 1, and Z observables are
        # numbered code.dimension, code.dimension + 1, ..., code.dimension * 2 - 1.
        decoder = decoders.SubgraphSinterDecoder(
            (detectors_x, detectors_z),  # X/Z detectors
            (
                range(code.dimension),
                range(code.dimension, 2 * code.dimension),
            ),  # X/Z observables
            **decoding_kwargs,
        )
        decoder_name = f"decoder_{code_index}"
        custom_decoders[decoder_name] = decoder

        noise_model_init = qldpc.circuits.DepolarizingNoiseModel(
            0, include_idling_error=False
        )
        qec_cycle = noise_model_init.noisy_circuit(qec_cycle)
        clean_circ = remove_noise_from_circuit(qec_cycle)
        shuttling_routes = determine_bad_shuttling_routes(
            clean_circ, starting_coord, Grid, X, Y, Grid_check
        )

        print("Shuttling routes determined.")

        for prob in error_rates:
            # noise_model = qldpc.circuits.DepolarizingNoiseModel(prob, include_idling_error=False)

            noisy_circuit = (
                initialization
                + add_bad_shuttling_noise(
                    clean_circ,
                    shuttling_routes,
                    Grid,
                    prob,
                    ratio_T1toT2,
                    ratio_T1toidlehalf,
                    ratio_T1toshuttlinghalf,
                )
                + readout
            )
            # noisy_circuit = initialization + noise_model.noisy_circuit(qec_cycle) + readout
            tasks.append(
                sinter.Task(
                    circuit=noisy_circuit,
                    decoder=decoder_name,
                    json_metadata={"label": get_label(code), "prob": prob},
                )
            )

    return sinter.collect(
        num_workers=os.cpu_count() - 2,
        max_shots=max_shots,
        max_errors=max_errors,
        tasks=tasks,
        custom_decoders=custom_decoders,
    )


def make_bad_combined_memory_experiment_figure(
    codes_to_simulate: Sequence[codes.QuditCode],
    error_rates: Sequence[float] = list(np.logspace(-6, -3, 4)),
    max_shots: int = 10**5,
    max_errors: int = 100,
    distance_trials: int = 100,
    figsize: tuple[int, int] = (5, 4),
    Grid: nx.Graph = nx.grid_2d_graph(12, 24, periodic=False, create_using=None),
    X: int = 12,
    Y: int = 24,
    Grid_check: bool = False,
    starting_coord: dict = {},
    ratio_T1toT2: float = 3.26,
    ratio_T1toidlehalf: float = 0.0017,
    ratio_T1toshuttlinghalf: float = 0.004,
    Distance_choice: bool = False,
    distance: int = 1,
    **decoding_kwargs: object,
) -> tuple[plt.Figure, plt.Axes]:
    """Use sinter to simulate memory cycles of the given codes, and plot the results.

    Args:
        codes_to_simulate: The codes we wish to simulate.
        error_rates: The i.i.d. probabilities of a depolarizing error after each gate.
        max_shots: Stop sampling the circuit after this many shots.
        max_errors: Stops the sampling process after this many errors have been seen in samples
            taken from the circuit.
        distance_trials: If the code distance is not known, estimate it with this many trials.
            The estimated distance determines the number of rounds of syndrome measurement.
        figsize: The size of the figure to produce.
        **decoding_kwargs: Arguments to pass to the decoder.

    Returns:
        The matplotlib.pyplot figure and axis.
    """
    # return run_combined_memory_experiments(
    #     codes_to_simulate, error_rates, max_shots, max_errors, distance_trials, **decoding_kwargs
    # )

    if Grid_check:
        print(
            "We are assuming that the Grid is a two-dimensional square grid of size "
            + str(X)
            + " x "
            + str(Y)
            + "."
        )

    stats = run_bad_combined_memory_experiments(
        codes_to_simulate,
        error_rates,
        max_shots,
        max_errors,
        distance_trials,
        Grid,
        X,
        Y,
        Grid_check,
        starting_coord,
        ratio_T1toT2,
        ratio_T1toidlehalf,
        ratio_T1toshuttlinghalf,
        Distance_choice,
        distance,
        **decoding_kwargs,
    )

    figure, axis = plt.subplots(figsize=figsize)
    sinter.plot_error_rate(
        ax=axis,
        stats=stats,
        x_func=lambda stats: stats.json_metadata["prob"],
        group_func=lambda stats: stats.json_metadata["label"],
    )

    axis.axline(
        (0, 0),
        slope=1,
        color="k",
        linestyle=":",
        label=r"$p_{\mathrm{log}}=p_{\mathrm{phys}}$",
    )
    axis.loglog()
    axis.set_xlabel(r"physical error rate")
    axis.set_ylabel(r"logical error rate")
    axis.legend(loc="best")
    axis.grid(which="both")
    figure.tight_layout()

    return figure, axis
