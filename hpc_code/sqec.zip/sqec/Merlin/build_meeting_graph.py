# %%
import networkx as nx


# %%
# def build_meeting_graph(coord, Grid, pair, Radius):
#     G_R = nx.Graph()
#     for ind, val in enumerate(coord):
#         if (pair[ind], ind) not in G_R:
#             G_R.add_node( (ind, pair[ind]) )
#     G_R.add_nodes_from(Grid)


#     for ind, _ in enumerate(pair):
#         for node in Grid:
#             if (ind, pair[ind]) in G_R:
#                 if nx.shortest_path_length(Grid, coord[ind], node) <= Radius:
#                     if nx.shortest_path_length(Grid, coord[pair[ind]], node) <= Radius:
#                         G_R.add_edge( (ind,pair[ind]), node)


#     return G_R


# %%
def build_meeting_graph(coord, Grid, pair, Radius):
    G_R = nx.Graph()
    for ind in pair.keys():
        G_R.add_node((ind, pair[ind]))
    G_R.add_nodes_from(Grid)

    for ind in pair.keys():
        for node in Grid:
            if pair[ind] in coord.keys():
                if nx.shortest_path_length(Grid, coord[ind], node) <= Radius:
                    if nx.shortest_path_length(Grid, coord[pair[ind]], node) <= Radius:
                        G_R.add_edge((ind, pair[ind]), node)
            else:
                if nx.shortest_path_length(Grid, coord[ind], node) <= Radius:
                    G_R.add_edge((ind, pair[ind]), node)

    return G_R


# G_R = build_meeting_graph(coord,Grid,pair,1)
# print(G_R)
# nx.draw(G_R, with_labels=True, font_weight='bold')
# nx.draw(Grid, with_labels=True, font_weight='bold')

# %%
