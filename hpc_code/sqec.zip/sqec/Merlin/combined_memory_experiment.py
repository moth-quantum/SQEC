import networkx as nx
from sqec.modify_stim_circuit import (
    remove_noise_from_circuit,
)
import Merlin.add_shuttling_noise as sn
import qldpc
import numpy as np
import sinter
from collections.abc import Sequence
from qldpc import circuits, codes, decoders
import matplotlib.pyplot as plt
import os
from scipy.stats import linregress


def get_label(
    code: codes.ClassicalCode | codes.QuditCode,
    distance_trials: bool | int = False,
) -> str:
    """Get a label for a code in a figure.

    If the code distance is not known, use a given number of trials to estimate it.
    """
    known_distance = code.get_distance_if_known()
    if isinstance(known_distance, int):
        return f"$d={known_distance}$"
    if not distance_trials:
        return f"[{len(code)}, {code.dimension}]"
    distance_estimate = code.get_distance_bound(num_trials=int(distance_trials))
    return f"[{len(code)}, {code.dimension}, d <= {distance_estimate}]"


def run_combined_memory_experiments(
    codes_to_simulate: Sequence[codes.QuditCode],
    error_rates: Sequence[float] = list(np.logspace(-3, -2, 3)),
    max_shots: int = 10**5,
    max_errors: int = 100,
    distance_trials: int = 100,
    Grid: nx.Graph = nx.grid_2d_graph(12, 24, periodic=False, create_using=None),
    X: int = 12,
    Y: int = 24,
    Grid_check: bool = False,
    starting_coord: dict = {},
    ratio_T1toT2: float = 3.26,
    ratio_T1toidlehalf: float = 0.0017,
    ratio_T1toshuttlinghalf: float = 0.004,
    Distance_choice: bool = False,
    distance: int = 1,
    **decoding_kwargs: object,
) -> list[sinter.TaskStats]:
    """Use sinter to simulate memory cycles of the given codes.

    This function ...
      1. Builds a memory experiment for each code.
      2. Adds a depolarizing noise to all gates, at the provided error rates.
      2. Wraps each noisy circuit in a `sinter.Task``.
      3. Runs batched Monte Carlo sampling with `sinter.collect`.

    Args:
        codes_to_simulate: The codes we wish to simulate.
        error_rates: The i.i.d. probabilities of a depolarizing error after each gate.
        max_shots: Stop sampling the circuit after this many shots.
        max_errors: Stops the sampling process after this many errors have been seen in samples
            taken from the circuit.
        distance_trials: If the code distance is not known, estimate it with this many trials.
            The estimated distance determines the number of rounds of syndrome measurement.
        **decoding_kwargs: Arguments to pass to the decoder.

    Returns:
        A `sinter` stats object aggregating shots, errors, and metadata for downstream plotting.
    """

    #    Grid = nx.grid_2d_graph(X, Y, periodic=False, create_using=None)

    tasks = []
    custom_decoders = {}  # each code is going to need its own decoder
    for code_index, code in enumerate(codes_to_simulate):
        if not Distance_choice:
            distance = code.get_distance(bound=distance_trials)

        # Collect the components of the memory experiment.  In particular, we will need the record
        # of detectors and qubit indices.
        (
            initialization,
            qec_cycle,
            readout,
            measurement_record,
            detector_record,
            qubit_ids,
        ) = circuits.get_memory_experiment_parts(code, basis=None, num_rounds=distance)

        # Identify detectors associated with X-type and Z-type stabilizers (parity checks).
        detectors_x = detector_record.get_events(*qubit_ids.checks_x)
        detectors_z = detector_record.get_events(*qubit_ids.checks_z)

        # Build a decoder that separately decodes X and Z sectors to predict X and Z observables.
        # Here X observables are numbered 0, 1, ..., code.dimension - 1, and Z observables are
        # numbered code.dimension, code.dimension + 1, ..., code.dimension * 2 - 1.
        decoder = decoders.SubgraphSinterDecoder(
            (detectors_x, detectors_z),  # X/Z detectors
            (
                range(code.dimension),
                range(code.dimension, 2 * code.dimension),
            ),  # X/Z observables
            **decoding_kwargs,
        )
        decoder_name = f"decoder_{code_index}"
        custom_decoders[decoder_name] = decoder

        noise_model_init = qldpc.circuits.DepolarizingNoiseModel(
            0, include_idling_error=False
        )
        qec_cycle = noise_model_init.noisy_circuit(qec_cycle)
        clean_circ = remove_noise_from_circuit(qec_cycle)
        shuttling_routes = sn.determine_shuttling_routes(
            clean_circ, starting_coord, Grid, X, Y, Grid_check
        )

        print("Shuttling routes determined.")

        for prob in error_rates:
            # noise_model = qldpc.circuits.DepolarizingNoiseModel(prob, include_idling_error=False)

            # qec_cycle = noise_model.noisy_circuit(qec_cycle)
            # #return qec_cycle
            # clean_circ = remove_noise_from_circuit(qec_cycle)
            # #return clean_circ
            # test_qubits = sn.create_qubit_list(clean_circ)
            # #The next four lines create a qubit-layout for the starting coordinates. It is expected to be highly suboptimal.
            # # i = 0
            # # for qubit in test_qubits:
            # #     starting_coord[qubit] = (i // 12, i % 12)
            # #     i = i + 1

            # starting_coord = create_qubit_layout(test_qubits, X, Y)

            # shuttling_routes = sn.determine_shuttling_routes(clean_circ, starting_coord, Grid)

            noisy_circuit = (
                initialization
                + sn.add_shuttling_noise_new(
                    clean_circ,
                    shuttling_routes,
                    Grid,
                    prob,
                    ratio_T1toT2,
                    ratio_T1toidlehalf,
                    ratio_T1toshuttlinghalf,
                )
                + readout
            )
            # noisy_circuit = initialization + noise_model.noisy_circuit(qec_cycle) + readout
            tasks.append(
                sinter.Task(
                    circuit=noisy_circuit,
                    decoder=decoder_name,
                    json_metadata={"label": get_label(code), "prob": prob},
                )
            )

    return sinter.collect(
        num_workers=os.cpu_count() - 2,
        max_shots=max_shots,
        max_errors=max_errors,
        tasks=tasks,
        custom_decoders=custom_decoders,
    )


def make_combined_memory_experiment_figure(
    codes_to_simulate: Sequence[codes.QuditCode],
    error_rates: Sequence[float] = list(np.logspace(-6, -3, 4)),
    max_shots: int = 10**5,
    max_errors: int = 100,
    distance_trials: int = 100,
    figsize: tuple[int, int] = (5, 4),
    Grid: nx.Graph = nx.grid_2d_graph(12, 24, periodic=False, create_using=None),
    X: int = 12,
    Y: int = 24,
    Grid_check: bool = False,
    starting_coord: dict = {},
    ratio_T1toT2: float = 3.26,
    ratio_T1toidlehalf: float = 0.0017,
    ratio_T1toshuttlinghalf: float = 0.004,
    Distance_choice: bool = False,
    distance: int = 1,
    **decoding_kwargs: object,
) -> tuple[plt.Figure, plt.Axes]:
    """Use sinter to simulate memory cycles of the given codes, and plot the results.

    Args:
        codes_to_simulate: The codes we wish to simulate.
        error_rates: The i.i.d. probabilities of a depolarizing error after each gate.
        max_shots: Stop sampling the circuit after this many shots.
        max_errors: Stops the sampling process after this many errors have been seen in samples
            taken from the circuit.
        distance_trials: If the code distance is not known, estimate it with this many trials.
            The estimated distance determines the number of rounds of syndrome measurement.
        figsize: The size of the figure to produce.
        **decoding_kwargs: Arguments to pass to the decoder.

    Returns:
        The matplotlib.pyplot figure and axis.
    """
    # return run_combined_memory_experiments(
    #     codes_to_simulate, error_rates, max_shots, max_errors, distance_trials, **decoding_kwargs
    # )

    if Grid_check:
        print(
            "We are assuming that the Grid is a two-dimensional square grid of size "
            + str(X)
            + " x "
            + str(Y)
            + "."
        )

    stats = run_combined_memory_experiments(
        codes_to_simulate,
        error_rates,
        max_shots,
        max_errors,
        distance_trials,
        Grid,
        X,
        Y,
        Grid_check,
        starting_coord,
        ratio_T1toT2,
        ratio_T1toidlehalf,
        ratio_T1toshuttlinghalf,
        Distance_choice,
        distance,
        **decoding_kwargs,
    )

    figure, axis = plt.subplots(figsize=figsize)
    sinter.plot_error_rate(
        ax=axis,
        stats=stats,
        x_func=lambda stats: stats.json_metadata["prob"],
        group_func=lambda stats: stats.json_metadata["label"],
    )

    axis.axline(
        (0, 0),
        slope=1,
        color="k",
        linestyle=":",
        label=r"$p_{\mathrm{log}}=p_{\mathrm{phys}}$",
    )
    axis.loglog()
    axis.set_xlabel(r"physical error rate")
    axis.set_ylabel(r"logical error rate")
    axis.legend(loc="best")
    axis.grid(which="both")
    figure.tight_layout()

    return figure, axis


def give_combined_memory_experiment_data(
    codes_to_simulate: Sequence[codes.QuditCode],
    error_rates: Sequence[float] = list(np.logspace(-6, -3, 4)),
    max_shots: int = 10**5,
    max_errors: int = 100,
    distance_trials: int = 100,
    figsize: tuple[int, int] = (5, 4),
    Grid: nx.Graph = nx.grid_2d_graph(12, 24, periodic=False, create_using=None),
    X: int = 12,
    Y: int = 24,
    Grid_check: bool = False,
    starting_coord: dict = {},
    ratio_T1toT2: float = 3.26,
    ratio_T1toidlehalf: float = 0.0017,
    ratio_T1toshuttlinghalf: Sequence[float] = [0.004],
    **decoding_kwargs: object,
) -> dict:
    if not isinstance(ratio_T1toshuttlinghalf, list):
        print("Error. The input ratio_T1toshuttlinghalf needs to be a list of floats.")

    if Grid_check:
        print(
            "We are assuming that the Grid is a two-dimensional square grid of size "
            + str(X)
            + " x "
            + str(Y)
            + "."
        )

    experiment_data = {}

    for ratio_sh in ratio_T1toshuttlinghalf:
        experiment_data[ratio_sh] = {}
        stats = run_combined_memory_experiments(
            codes_to_simulate,
            error_rates,
            max_shots,
            max_errors,
            distance_trials,
            Grid,
            X,
            Y,
            Grid_check,
            starting_coord,
            ratio_T1toT2,
            ratio_T1toidlehalf,
            ratio_sh,
            **decoding_kwargs,
        )

        for stat in stats:
            logical_error_prob = stat.errors / stat.shots
            experiment_data[ratio_sh][stat.json_metadata["prob"]] = logical_error_prob

    return experiment_data


def estimate_code_distance(error_rates, logical_errors):
    """
    Estimates the slope of the linear approximation of the plot logical_errors(error_rates).
    In addition, it returns the estimated distance d_estimate of an error correction code that would cause such a slope.
    The relationship between the slope and d_estimate is given by: (d_estimate + 1) / 2  = slope.
    We also return the standard error of the linear regression.
    """
    phys_err = np.array(error_rates)
    logic_err = np.array(logical_errors)

    log_phys_err = np.log(phys_err)
    log_logic_err = np.log(logic_err)

    slope, intercept, _, _, stderr = linregress(log_phys_err, log_logic_err)

    d_estimate = 2 * slope - 1

    return d_estimate, slope, intercept, stderr


def memory_experiment_with_code_distance(
    codes_to_simulate: Sequence[codes.QuditCode],
    error_rates: Sequence[float] = list(np.logspace(-6, -3, 4)),
    max_shots: int = 10**5,
    max_errors: int = 100,
    distance_trials: int = 100,
    **decoding_kwargs: object,
):
    """
    Runs a memory experiment, plots the simulation points and plots a linear regression.

    Returns the estimated distance distance_estimate obtained from the slope of the linear regression.
    In addition returns the x- and y-axes error_rates_non_deg and logical_errors_non_deg of the simulation points as lists.
    All simulations that returned 0 logical errors are discarded.
    """

    error_rates = sorted(error_rates)
    error_rates_reversed = error_rates[::-1]
    logical_errors = []
    error_rates_non_deg = []
    logical_errors_non_deg = []

    for prob in error_rates_reversed:
        error_rate = [prob]

        collected_stats = run_combined_memory_experiments(
            codes_to_simulate,
            error_rate,
            max_shots,
            max_errors,
            distance_trials,
            **decoding_kwargs,
        )

        for stat in collected_stats:
            if stat.errors == 0:
                break

            logical_error_prob = stat.errors / (stat.shots - stat.discards)
            logical_errors.append(np.log10(logical_error_prob))

            if not (stat.errors == 0 or logical_error_prob > 0.5):
                error_rates_non_deg.append(stat.json_metadata["prob"])
                logical_errors_non_deg.append(
                    stat.errors / (stat.shots - stat.discards)
                )

    distance_estimate, slope, intercept, stderr = estimate_code_distance(
        error_rates_non_deg, logical_errors_non_deg
    )

    print(f"Slope of linear regression: {slope}")
    print(f"Estimated distance: {distance_estimate}")

    # Initialize figure
    plt.figure(figsize=(10, 10))

    # Plot the results from the simulation in loglog-scale
    plt.scatter(error_rates_non_deg, logical_errors_non_deg, label="Simulation results")

    # Plot the linear regression
    x_fit = np.linspace(min(error_rates_non_deg), max(error_rates_non_deg), 100)
    y_fit = (
        x_fit**slope * np.exp(intercept)
    )  # This corresponds to the fact that y_fit = exp( slope* log(x_fit) + intercept ) Because linearity holds for the loglog-scale, we have to take log of x_fit and then take the exponential of the linear function.
    plt.loglog(
        x_fit, y_fit, "--r", label=f"Linear Regression, d = {distance_estimate:.1f}"
    )

    # Add labels
    plt.xlabel("Physical Error Rate")
    plt.ylabel("Logical Error Rate")
    plt.title("Estimating code distance")
    plt.legend()

    # Add a grid: visible = True, which = along both axes,
    plt.grid(True, which="both", ls="-", alpha=0.5)

    plt.show()

    return distance_estimate, error_rates_non_deg, logical_errors_non_deg


class combinedMemoryExperiment:
    def __init__(
        self,
        codes_to_simulate: Sequence[codes.QuditCode],
        error_rates: Sequence[float] = list(np.logspace(-3, -2, 3)),
        max_shots: int = 10**5,
        max_errors: int = 100,
        distance_trials: int = 100,
        Grid: nx.Graph = nx.grid_2d_graph(12, 24, periodic=False, create_using=None),
        X: int = 12,
        Y: int = 24,
        Grid_check: bool = False,
        starting_coord: dict = {},
        ratio_T1toT2: float = 3.26,
        ratio_T1toidlehalf: float = 0.0017,
        ratio_T1toshuttlinghalf: float = 0.004,
    ):
        self.codes_to_simulate = codes_to_simulate
        self.error_rates = error_rates
        self.max_shots = max_shots
        self.max_errors = max_errors
        self.distance_trials = distance_trials
        self.Grid = Grid
        self.X = X
        self.Y = Y
        self.Grid_check = Grid_check
        self.starting_coord = starting_coord
        self.ratio_T1toT2 = ratio_T1toT2
        self.ratio_T1toidlehalf = ratio_T1toidlehalf
        self.ratio_T1toshuttlinghalf = ratio_T1toshuttlinghalf

    def run_combined_memory_experiments(
        self,
        **decoding_kwargs: object,
    ) -> list[sinter.TaskStats]:
        """Use sinter to simulate memory cycles of the given codes.

        This function ...
        1. Builds a memory experiment for each code.
        2. Adds a depolarizing noise to all gates, at the provided error rates.
        2. Wraps each noisy circuit in a `sinter.Task``.
        3. Runs batched Monte Carlo sampling with `sinter.collect`.

        Args:
            codes_to_simulate: The codes we wish to simulate.
            error_rates: The i.i.d. probabilities of a depolarizing error after each gate.
            max_shots: Stop sampling the circuit after this many shots.
            max_errors: Stops the sampling process after this many errors have been seen in samples
                taken from the circuit.
            distance_trials: If the code distance is not known, estimate it with this many trials.
                The estimated distance determines the number of rounds of syndrome measurement.
            **decoding_kwargs: Arguments to pass to the decoder.

        Returns:
            A `sinter` stats object aggregating shots, errors, and metadata for downstream plotting.
        """

        #    Grid = nx.grid_2d_graph(X, Y, periodic=False, create_using=None)

        self.tasks = []
        self.custom_decoders = {}  # each code is going to need its own decoder
        self.shuttling_schedules = {}
        self.circuits = {}
        for code_index, code in enumerate(self.codes_to_simulate):
            distance = code.get_distance(bound=self.distance_trials)

            # Collect the components of the memory experiment.  In particular, we will need the record
            # of detectors and qubit indices.
            (
                initialization,
                qec_cycle,
                readout,
                measurement_record,
                detector_record,
                qubit_ids,
            ) = circuits.get_memory_experiment_parts(
                code, basis=None, num_rounds=distance
            )

            # Identify detectors associated with X-type and Z-type stabilizers (parity checks).
            detectors_x = detector_record.get_events(*qubit_ids.checks_x)
            detectors_z = detector_record.get_events(*qubit_ids.checks_z)

            # Build a decoder that separately decodes X and Z sectors to predict X and Z observables.
            # Here X observables are numbered 0, 1, ..., code.dimension - 1, and Z observables are
            # numbered code.dimension, code.dimension + 1, ..., code.dimension * 2 - 1.
            decoder = decoders.SubgraphSinterDecoder(
                (detectors_x, detectors_z),  # X/Z detectors
                (
                    range(code.dimension),
                    range(code.dimension, 2 * code.dimension),
                ),  # X/Z observables
                **decoding_kwargs,
            )
            decoder_name = f"decoder_{code_index}"
            self.custom_decoders[decoder_name] = decoder

            noise_model_init = qldpc.circuits.DepolarizingNoiseModel(
                0, include_idling_error=False
            )
            qec_cycle = noise_model_init.noisy_circuit(qec_cycle)
            clean_circ = remove_noise_from_circuit(qec_cycle)
            shuttling_routes = sn.determine_shuttling_routes(
                clean_circ,
                self.starting_coord,
                self.Grid,
                self.X,
                self.Y,
                self.Grid_check,
            )
            self.circuits[code_index] = {}
            self.shuttling_schedules[code_index] = shuttling_routes
            print("Shuttling routes determined.")

            for prob in self.error_rates:
                # noise_model = qldpc.circuits.DepolarizingNoiseModel(prob, include_idling_error=False)

                # qec_cycle = noise_model.noisy_circuit(qec_cycle)
                # #return qec_cycle
                # clean_circ = remove_noise_from_circuit(qec_cycle)
                # #return clean_circ
                # test_qubits = sn.create_qubit_list(clean_circ)
                # #The next four lines create a qubit-layout for the starting coordinates. It is expected to be highly suboptimal.
                # # i = 0
                # # for qubit in test_qubits:
                # #     starting_coord[qubit] = (i // 12, i % 12)
                # #     i = i + 1

                # starting_coord = create_qubit_layout(test_qubits, X, Y)

                # shuttling_routes = sn.determine_shuttling_routes(clean_circ, starting_coord, Grid)

                noisy_circuit = (
                    initialization
                    + sn.add_shuttling_noise_new(
                        clean_circ,
                        shuttling_routes,
                        self.Grid,
                        prob,
                        self.ratio_T1toT2,
                        self.ratio_T1toidlehalf,
                        self.ratio_T1toshuttlinghalf,
                    )
                    + readout
                )
                self.circuits[code_index][prob] = noisy_circuit
                # noisy_circuit = initialization + noise_model.noisy_circuit(qec_cycle) + readout
                self.tasks.append(
                    sinter.Task(
                        circuit=noisy_circuit,
                        decoder=decoder_name,
                        json_metadata={"label": get_label(code), "prob": prob},
                    )
                )

        self.CombinedMemoryResults = sinter.collect(
            num_workers=os.cpu_count() - 2,
            max_shots=self.max_shots,
            max_errors=self.max_errors,
            tasks=self.tasks,
            custom_decoders=self.custom_decoders,
        )
        return self.CombinedMemoryResults

    def make_combined_memory_experiment_figure(
        self,
        figsize: tuple[int, int] = (5, 4),
    ) -> tuple[plt.Figure, plt.Axes]:
        """Use sinter to simulate memory cycles of the given codes, and plot the results.

        Args:
            codes_to_simulate: The codes we wish to simulate.
            error_rates: The i.i.d. probabilities of a depolarizing error after each gate.
            max_shots: Stop sampling the circuit after this many shots.
            max_errors: Stops the sampling process after this many errors have been seen in samples
                taken from the circuit.
            distance_trials: If the code distance is not known, estimate it with this many trials.
                The estimated distance determines the number of rounds of syndrome measurement.
            figsize: The size of the figure to produce.
            **decoding_kwargs: Arguments to pass to the decoder.

        Returns:
            The matplotlib.pyplot figure and axis.
        """
        # return run_combined_memory_experiments(
        #     codes_to_simulate, error_rates, max_shots, max_errors, distance_trials, **decoding_kwargs
        # )
        stats = self.CombinedMemoryResults

        figure, axis = plt.subplots(figsize=figsize)
        sinter.plot_error_rate(
            ax=axis,
            stats=stats,
            x_func=lambda stats: stats.json_metadata["prob"],
            group_func=lambda stats: stats.json_metadata["label"],
        )

        axis.axline(
            (0, 0),
            slope=1,
            color="k",
            linestyle=":",
            label=r"$p_{\mathrm{log}}=p_{\mathrm{phys}}$",
        )
        axis.loglog()
        axis.set_xlabel(r"physical error rate")
        axis.set_ylabel(r"logical error rate")
        axis.legend(loc="best")
        axis.grid(which="both")
        figure.tight_layout()

        return figure, axis
