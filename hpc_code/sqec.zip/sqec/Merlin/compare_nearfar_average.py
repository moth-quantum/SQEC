import networkx as nx
from sqec.modify_stim_circuit import (
    remove_noise_from_circuit,
)
import sqec.modify_stim_circuit as msc
import Merlin.add_shuttling_noise as sn
from qldpc import circuits, codes, decoders
import sinter
import os
import numpy as np
from sympy.abc import x, y


def create_nearfar_error_data(
    qubit_list, coord, pair, Grid, p_near, p_far, d_threshold
):
    """
    Given a list of qubits and their travel itineraries (from coord to meeting_points), creates a dictionary shuttling_data that indicates for every qubit the following data:
    shuttling distance
    idling time
    T1 and T2 idling error probability
    shuttling and idling error probability
    total error probability
    """
    pair_distance = {}
    error_probability = {}
    shuttling_data = {}

    for ind in pair.keys():
        if pair[ind] == "solo":
            pair_distance[ind] = 0
        else:
            pair_distance[ind] = nx.shortest_path_length(
                Grid, coord[ind], coord[pair[ind]]
            )
            pair_distance[pair[ind]] = nx.shortest_path_length(
                Grid, coord[ind], coord[pair[ind]]
            )

    for qubit in qubit_list:
        if pair_distance[qubit] < d_threshold:
            error_probability[qubit] = p_near
        else:
            error_probability[qubit] = p_far
        shuttling_data[qubit] = {
            "near": p_near,
            "far": p_far,
            "total error probability": error_probability[qubit],
            # "2-qubit gate error probability": p_2gate,  # ,
            # "idling probability" : p_idle #Add this line (plus relevant input), if we want to include idling.
        }

    return shuttling_data


def create_paired_nearfar_errors(shuttling_data, pair):
    """
    Given shuttling data, creates a dictionary that associates the shuttling data to pairs of qubits.
    """
    paired_shuttling_error = {}
    for qubit in shuttling_data.keys():
        if qubit in pair.keys():
            if pair[qubit] == "solo":
                paired_shuttling_error[(qubit, "solo")] = [
                    (
                        "DEPOLARIZE1",
                        0,  # shuttling_data[qubit]["total error probability"],
                        (qubit,),
                    )
                ]  # In the last entry of the triple: Should it be qubit or should it be 0? Check in the modify_stim_circuit file.
            else:
                paired_shuttling_error[(qubit, pair[qubit])] = [
                    # (
                    #     "DEPOLARIZE1",
                    #     shuttling_data[qubit]["total error probability"],
                    #     (qubit,),
                    # ),
                    # (
                    #     "DEPOLARIZE1",
                    #     shuttling_data[pair[qubit]]["total error probability"],
                    #     (pair[qubit],),
                    # ),
                    (
                        "DEPOLARIZE2",
                        shuttling_data[qubit]["total error probability"],
                        (qubit, pair[qubit]),
                    ),
                ]

    return paired_shuttling_error


def add_nearfar_shuttling_noise(
    ideal_circuit, coord: dict, Grid, p_near, p_far, d_threshold
):
    """
    Adds noise to an ideal circuit. 1-qubit gates and 2-qubit gates get noise added based on a noise model specified via
    the input probabilities and ratios and specified by the function create_shuttling_error.

    The noisy circuit also receives a shuttling stage in every tick where every qubit gets a noise error based on the amount of time spent shuttling and idling.
    The noise model is specified by the input probabilities and ratios and by the function create_shuttling_error.
    """

    noise_model = circuits.DepolarizingNoiseModel(0.001, include_idling_error=False)

    noise_circuit = noise_model.noisy_circuit(ideal_circuit)
    clean_circuit = remove_noise_from_circuit(noise_circuit)
    qubit_list = sn.create_qubit_list(clean_circuit)
    tick_list = msc.split_at_ticks(clean_circuit)

    noisy_tick_list = []

    for tick in tick_list:
        if not (
            ("DETECTOR" in str(tick)) or ("rec" in str(tick)) or ("-" in str(tick))
        ):
            pair = sn.find_partner_qubit(tick, qubit_list)
            single_shuttling_data = create_nearfar_error_data(
                qubit_list, coord, pair, Grid, p_near, p_far, d_threshold
            )
            paired_shuttling_data = create_paired_nearfar_errors(
                single_shuttling_data, pair
            )
            noisy_tick_list.append(msc.apply_custom_noise(tick, paired_shuttling_data))
        else:
            noisy_tick_list.append(tick)
    noisy_circuit = msc.reassemble_circuit(noisy_tick_list, insert_ticks=True)

    diagram = noisy_circuit.diagram("timeline-svg")
    with open("diagram.svg", "w") as f:
        print(diagram, file=f)

    return noisy_circuit


def code_to_circuit(code: codes.QuditCode, distance_trials: int = 100):
    distance = code.get_distance(bound=distance_trials)

    (
        initialization,
        qec_cycle,
        readout,
        measurement_record,
        detector_record,
        qubit_ids,
    ) = circuits.get_memory_experiment_parts(
        code, basis=None, num_rounds=distance
    )  # We can reduce the runtime here by reducing num_rounds.

    #    ideal_circuit = initialization + qec_cycle + readout

    return (
        initialization,
        qec_cycle,
        readout,
        measurement_record,
        detector_record,
        qubit_ids,
    )


def get_label(  # Taken from logical_error_rates in qldpc.
    code: codes.ClassicalCode | codes.QuditCode,
    distance_trials: bool | int = False,
) -> str:
    """Get a label for a code in a figure.

    If the code distance is not known, use a given number of trials to estimate it.
    """
    known_distance = code.get_distance_if_known()
    if isinstance(known_distance, int):
        return f"$d={known_distance}$"
    if not distance_trials:
        return f"[{len(code)}, {code.dimension}]"
    distance_estimate = code.get_distance_bound(num_trials=int(distance_trials))
    return f"[{len(code)}, {code.dimension}, d <= {distance_estimate}]"


# def y_func(stat: 'sinter.TaskStats') -> Union[float, 'sinter.Fit']:
#     result = fit_binomial(
#         num_shots=stat.shots - stat.discards,
#         num_hits=stat.errors,
#         max_likelihood_factor=highlight_max_likelihood_factor,
#     )

#     pieces = failure_units_per_shot_func(stat)
#     values = failure_values_func(stat)
#     result = Fit(
#         low=shot_error_rate_to_piece_error_rate(result.low, pieces=pieces, values=values),
#         best=shot_error_rate_to_piece_error_rate(result.best, pieces=pieces, values=values),
#         high=shot_error_rate_to_piece_error_rate(result.high, pieces=pieces, values=values),
#     )

#     if stat.errors == 0:
#         result = Fit(low=result.low, high=result.high, best=float('nan'))

#     if highlight_max_likelihood_factor == 1:
#         return result.best
#     return result


def compare_nearfar_average(
    code,
    error_rates,
    Grid,
    coord: dict,
    d_threshold,
    deg_near,
    deg_far,
    max_shots: int = 10**5,
    max_errors: int = 100,
    distance_trials: int = 100,
):
    """
    Takes a circuit, a list of pairs of error rates, and a dictionary of coordinates. For each pair, it simulates the circuit twice:
    Once with an average error rate and once where qubits with large distances have high error rate while close-by qubits have low error rate.
    It returns a comparison dictionary, which associates to every pair of error_rates a boolean value on whether average_error < nearfar_error.
    """

    comparison = {}
    # ???
    # decoder = ['bposd']
    # custom_decoders = {'bposd' : decoder[0]}

    custom_decoders = {}

    for prob in error_rates:
        (
            initialization,
            qec_cycle,
            readout,
            measurement_record,
            detector_record,
            qubit_ids,
        ) = code_to_circuit(code, distance_trials)
        noisy_nearfar_circuit = (
            initialization
            + add_nearfar_shuttling_noise(
                qec_cycle, coord, Grid, prob[0], prob[1], d_threshold
            )
            + readout
        )

        # Identify detectors associated with X-type and Z-type stabilizers (parity checks).
        detectors_x = detector_record.get_events(*qubit_ids.checks_x)
        detectors_z = detector_record.get_events(*qubit_ids.checks_z)

        # Build a decoder that separately decodes X and Z sectors to predict X and Z observables.
        # Here X observables are numbered 0, 1, ..., code.dimension - 1, and Z observables are
        # numbered code.dimension, code.dimension + 1, ..., code.dimension * 2 - 1.
        decoding_kwargs = dict(
            with_BP_LSD=True,
            max_iter=30,
            bp_method="ms",
            lsd_method="lsd_cs",
            lsd_order=0,
        )
        decoder = decoders.SubgraphSinterDecoder(
            (detectors_x, detectors_z),  # X/Z detectors
            (
                range(code.dimension),
                range(code.dimension, 2 * code.dimension),
            ),  # X/Z observables
            **decoding_kwargs,
        )
        decoder_name = f"decoder_{prob}"
        custom_decoders[decoder_name] = decoder

        task_nearfar = sinter.Task(
            circuit=noisy_nearfar_circuit,
            decoder=decoder_name,
            json_metadata={"label": get_label(code), "prob": prob},
        )

        stats_nearfar = sinter.collect(
            num_workers=os.cpu_count() - 2,
            max_shots=max_shots,
            max_errors=max_errors,
            tasks=[task_nearfar],
            decoders=decoder,
            custom_decoders=custom_decoders,
        )

        p_average = (deg_near * prob[0] + deg_far * prob[1]) / (deg_near + deg_far)

        noisy_average_circuit = (
            initialization
            + add_nearfar_shuttling_noise(
                qec_cycle, coord, Grid, p_average, p_average, d_threshold
            )
            + readout
        )

        task_average = sinter.Task(
            circuit=noisy_average_circuit,
            decoder=decoder_name,
            json_metadata={"label": get_label(code), "prob": prob},
        )

        stats_average = sinter.collect(
            num_workers=os.cpu_count() - 2,
            max_shots=max_shots,
            max_errors=max_errors,
            tasks=[task_average],
            decoders=decoder,
            custom_decoders=custom_decoders,
        )

        for stat in stats_nearfar:
            print(stat.errors, stat.shots)
            nearfar_logical_prob = stat.errors / stat.shots
            print(nearfar_logical_prob)

        for stat in stats_average:
            print(stat.errors, stat.shots)
            average_logical_prob = stat.errors / stat.shots
            print(average_logical_prob)

        comparison[prob] = (
            nearfar_logical_prob >= average_logical_prob,
            nearfar_logical_prob,
            average_logical_prob,
        )  # If it is better to have some faraway interactions and many nearby interactions than an average distance,
        # comparison will state False for this pair of nearfar probabilities.
        # If it is better to have everything at an average error rather than have some nearfar stuff, comparison will state True.

    print(comparison)

    return comparison


# Setting up the input for testing.
code = codes.BBCode(
    {x: 6, y: 6},
    x**3 + y + y**2,
    y**3 + x + x**2,
)


noise_model = circuits.DepolarizingNoiseModel(0.01, include_idling_error=False)
(
    initialization,
    ideal_circuit,
    readout,
    measurement_record,
    detector_record,
    qubit_ids,
) = code_to_circuit(code)
qec_cycle = noise_model.noisy_circuit(ideal_circuit)
clean_circ = remove_noise_from_circuit(qec_cycle)
qubit_list = sn.create_qubit_list(clean_circ)

solo_error_rates = np.logspace(-4, -2, 3)

error_rates = []
for prob1 in solo_error_rates:
    for prob2 in solo_error_rates:
        if prob2 >= prob1:
            error_rates.append((prob1, prob2))

X = 12
Y = 12

Grid = nx.grid_2d_graph(
    X,
    Y,
    periodic=False,
    create_using=None,
)


coord = {}
i = 0
for q in qubit_list:
    qubit = q  # .value
    if i % Y == 1:
        i = i - 1
    elif i % Y == 0:
        i = i + 1
    if i >= X * Y:
        i = 0
    coord[qubit] = (i // Y, i % Y)
    i = i + 2

d_threshold = 2

deg_near = 2

deg_far = 1


# Running the function that produces a comparison dictionary.
comparison = compare_nearfar_average(
    code=code,
    error_rates=error_rates,
    Grid=Grid,
    coord=coord,
    d_threshold=d_threshold,
    deg_near=deg_near,
    deg_far=deg_far,
    max_shots=10**4,
)
print(comparison)
