# import some methods from the file find_bbcode_layouts.py, which should be in the same directory as this notebook
import networkx as nx
import Merlin.BB_codes as BBcodes
import stim
import Merlin.add_shuttling_noise as sn


def get_key_data(A, B):  # Might be an unnecessary function.
    code_matrix = BBcodes.get_parity_check_matrix(A, B)
    (
        data_qubit_list,
        check_qubit_list,
        qubit_list,
        qubit_type,
    ) = BBcodes.create_qubit_list(code_matrix)
    return data_qubit_list, check_qubit_list, qubit_list, qubit_type, code_matrix


def create_qubit_layout(qubit_list, X, Y):
    """
    Places qubits from a qubit_list on an X x Y square grid based on the following principle:
    We place qubits in spaces of 2, leaving intermediate spaces for the second half of qubits in the list
    (because in the list, the data qubits come first, the ancilla come after).
    We then 'fold' and 'expand' the layout according to the paper arXiv:2404.18809.
    """

    if len(qubit_list) > X * Y:
        return

    starting_coord = {}

    m = Y // 2
    M = (X * Y) // 2

    i = 0
    for q in qubit_list:
        qubit = q  # .value
        if i % Y == 1:
            i = i - 1
        elif i % Y == 0:
            i = i + 1
        if i >= X * Y:
            i = 0
        starting_coord[qubit] = {
            "coord": (i // Y, i % Y),
            "type1": (i // m) % 2,
            "type2": i // M,
        }
        i = i + 2

    # qubit_layout = {}
    # for q in qubit_list:
    #     qubit=q.value
    #     qubit_layout[qubit] = starting_coord[qubit]['coord']
    # return qubit_layout

    i = 0
    for q in qubit_list:
        qubit = q  # .value
        (x, y) = starting_coord[qubit]["coord"]
        if x >= X // 2:
            starting_coord[qubit]["coord"] = (X - 1 - x, y)
            (x, y) = starting_coord[qubit]["coord"]
        if y >= Y // 2:
            starting_coord[qubit]["coord"] = (x, Y - 1 - y)
            (x, y) = starting_coord[qubit]["coord"]
        if qubit == 0:
            print(starting_coord[qubit]["coord"])

    for q in qubit_list:
        qubit = q  # .value
        (x, y) = starting_coord[qubit]["coord"]
        if starting_coord[qubit]["type1"] == 0:
            starting_coord[qubit]["coord"] = (2 * x, 2 * y)
        if starting_coord[qubit]["type1"] == 1:
            starting_coord[qubit]["coord"] = (2 * x, 2 * y + 1)
        (x_new, y_new) = starting_coord[qubit]["coord"]
        if starting_coord[qubit]["type2"] == 1:
            starting_coord[qubit]["coord"] = (x_new + 1, y_new)

    qubit_layout = {}
    for q in qubit_list:
        qubit = q  # .value
        qubit_layout[qubit] = starting_coord[qubit]["coord"]

    return qubit_layout


def basis_check(vec1, vec2, L, M):
    check = True
    ord1 = get_order(vec1, L, M)
    ord2 = get_order(vec2, L, M)
    for a in range(L):
        for b in range(M):
            check_aux = False
            for alpha in range(ord1):
                for beta in range(ord2):
                    if (alpha * vec1[0] + beta * vec2[0] % L == a) and (
                        alpha * vec1[1] + beta * vec2[1] % M == b
                    ):
                        check_aux = True
                        break
                if check_aux:
                    break
            check = check and check_aux
    return check


def get_order(vec, L, M):
    for i in range(1, L * M):
        if (vec[0] * i % L == 0) and (vec[1] * i % M == 0):
            return i


def order_check(vec1, vec2, L, M):
    order1 = get_order(vec1, L, M)
    order2 = get_order(vec2, L, M)
    check = order1 * order2 == L * M
    return check


def get_good_inits(L, M):
    """
    For a given pair L, M for a BB code and its qubit list with 2*L*M data qubits and 2*L*M check qubits,
    this function returns a list of all pairs (a,b) that induce 'promising' starting positions for the data qubits.

    good_inits is a list of tuples, where the entries in the tuples are integers (modulo L and M respectively).
    """
    good_inits = []

    for a in range(L):
        for c in range(L):
            for b in range(M):
                for d in range(M):
                    vec1 = (a, b)
                    vec2 = (c, d)
                    if basis_check(vec1, vec2, L, M) and order_check(vec1, vec2, L, M):
                        if (vec2, vec1) not in good_inits:
                            good_inits.append((vec1, vec2))

    return good_inits


def find_representation(coord, vec1, vec2, L, M):
    for alpha in range(get_order(vec1, L, M)):
        for beta in range(get_order(vec2, L, M)):
            if ((alpha * vec1[0] + beta * vec2[0]) % L == coord[0]) and (
                (alpha * vec1[1] + beta * vec2[1]) % M == coord[1]
            ):
                return alpha, beta


def get_promising_data_layouts(A, B, L, M):
    """
    Takes a circuit and the parameters L, M of a BB code to return a list of data-qubit-layouts that are
    promising candidates to create an optimal layout in terms of largest distance of 2-qubit gates.

    The return is a list whose entries are triples (layout, ord1, ord2). 'layout' is the dictionary that gives coordinates to the data qubits.
    'ord1' and 'ord2' indicate the size of the coordinate grid.

    Note that we assume that the monomial LR in the creation of the good initial values satisfies LR = 1. In general, LR could be chosen arbitrarily.
    This multiplies the runtime of this function by roughly L*M.
    """
    _, _, qubit_list, _, _ = get_key_data(A, B)
    good_inits = get_good_inits(L, M)

    layout_list = []

    for vec1, vec2 in good_inits:
        for a in range(L):
            for b in range(M):
                transition_vectorLR = (a, b)
                vec1T = ((L - vec1[0]) % L, (M - vec1[1]) % M)
                vec2T = ((L - vec2[0]) % L, (M - vec2[1]) % M)
                ord1 = get_order(vec1, L, M)
                ord2 = get_order(vec2, L, M)
                prelim_layout1 = {}
                prelim_layout2 = {}
                prelim_layout3 = {}
                prelim_layout4 = {}
                for i in range(L * M):
                    coordL = (i // M, i % M)
                    coordR = (
                        (i // M - transition_vectorLR[0]) % L,
                        (i % M - transition_vectorLR[1]) % M,
                    )
                    alpha, beta = find_representation(coordL, vec1, vec2, L, M)
                    gamma1, delta1 = find_representation(coordR, vec1, vec2, L, M)
                    prelim_layout1[qubit_list[i]] = (2 * alpha, 2 * beta)
                    prelim_layout1[qubit_list[i + L * M]] = (
                        2 * gamma1 + 1,
                        2 * delta1 + 1,
                    )

                    gamma2, delta2 = find_representation(coordR, vec1T, vec2T, L, M)
                    prelim_layout2[qubit_list[i]] = (2 * alpha, 2 * beta)
                    prelim_layout2[qubit_list[i + L * M]] = (
                        2 * gamma2 + 1,
                        2 * delta2 + 1,
                    )

                    gamma3, delta3 = find_representation(coordR, vec1, vec2T, L, M)
                    prelim_layout3[qubit_list[i]] = (2 * alpha, 2 * beta)
                    prelim_layout3[qubit_list[i + L * M]] = (
                        2 * gamma3 + 1,
                        2 * delta3 + 1,
                    )

                    gamma4, delta4 = find_representation(coordR, vec1T, vec2, L, M)
                    prelim_layout4[qubit_list[i]] = (2 * alpha, 2 * beta)
                    prelim_layout4[qubit_list[i + L * M]] = (
                        2 * gamma4 + 1,
                        2 * delta4 + 1,
                    )
                layout_list.append(
                    (prelim_layout1, ord1, ord2, vec1, vec2, transition_vectorLR)
                )
                layout_list.append(
                    (prelim_layout2, ord1, ord2, vec1, vec2, transition_vectorLR)
                )
                layout_list.append(
                    (prelim_layout3, ord1, ord2, vec1, vec2, transition_vectorLR)
                )
                layout_list.append(
                    (prelim_layout4, ord1, ord2, vec1, vec2, transition_vectorLR)
                )

    return layout_list


def fold_layout(layout, ord1, ord2):
    """
    Given a layout of qubits on a 2*ord1 x 2*ord2 grid, we fold the layout horizontally and vertically along the middle
    and return the resulting dictionary.
    """
    folded_layout = {}

    for qubit in layout.keys():
        coord_x = layout[qubit][0]
        coord_y = layout[qubit][1]
        if coord_x < ord1:
            if coord_y < ord2:
                folded_layout[qubit] = (2 * coord_x, 2 * coord_y)
        if coord_x >= ord1:
            if coord_y < ord2:
                folded_layout[qubit] = (2 * (2 * ord1 - 1 - coord_x) + 1, 2 * coord_y)
        if coord_x < ord1:
            if coord_y >= ord2:
                folded_layout[qubit] = (2 * coord_x, 2 * (2 * ord2 - 1 - coord_y) + 1)
        if coord_x >= ord1:
            if coord_y >= ord2:
                folded_layout[qubit] = (
                    2 * (2 * ord1 - 1 - coord_x) + 1,
                    2 * (2 * ord2 - 1 - coord_y) + 1,
                )

    return folded_layout


def free_nodes_old(Grid, data_qubit_layout: dict):
    free_nodes = {}
    for node in Grid:
        if node in data_qubit_layout.values():
            free_nodes[node] = False
        else:
            free_nodes[node] = True
    return free_nodes


def free_nodes(Grid, data_qubit_layout: dict):
    # made into set so that you don't have to loop over everything
    free_nodes = {}
    occupied_positions = set(data_qubit_layout.values())
    for node in Grid:
        free_nodes[node] = node not in occupied_positions
    return free_nodes


def build_connection_graph(
    A, B, Grid, Radius, data_qubit_layout, Grid_check, X, Y
):  # Both here and below, I shouldn't use the code, but the two triples of matrices that define the code. That is much easier to use.
    """
    For a given circuit and data-qubit layout, this function returns the graph that connects every check-qubit with all free coordinates in the Grid
    such that the check-qubit has distance at most Radius to all its neighbours in the Tanner graph.
    """
    # if Grid_check:
    #     print("We are assuming that Grid is an " + str(X) + " x " + str(Y) + " square grid.")

    connection_graph = nx.Graph()
    open_nodes = free_nodes(Grid, data_qubit_layout)

    data_qubits, check_qubits, qubit_list, qubit_type, code_matrix = get_key_data(A, B)

    neighbours = BBcodes.get_neighbours(A, B)

    # Adding the vertices to the connection graph: The check qubits and the free spots in the connection graph are added.
    for qubit in check_qubits:
        connection_graph.add_node(qubit)
    for node in Grid:
        if open_nodes[node]:
            connection_graph.add_node(node)

    for qubit in check_qubits:
        for node in Grid:
            if open_nodes[node]:
                check = True
                for dataqubit in neighbours[qubit].values():
                    if Grid_check:
                        if (
                            sn.Grid_distance(node, data_qubit_layout[dataqubit])
                            > Radius
                        ):
                            # if ( min( abs(node[0] - data_qubit_layout[dataqubit][0]), X - abs(node[0] - data_qubit_layout[dataqubit][0]) ) +
                            #     min( abs(node[1] - data_qubit_layout[dataqubit][1]), Y - abs(node[1] - data_qubit_layout[dataqubit][1]) ) ) > Radius:
                            check = False
                            break  # unecessary additional calculations
                    else:
                        if (
                            nx.shortest_path_length(
                                Grid, node, data_qubit_layout[dataqubit]
                            )
                            > Radius
                        ):
                            check = False
                if check:
                    connection_graph.add_edge(qubit, node)

    return connection_graph


def get_optimized_qubit_layout(A, B, L, M):
    """
    Takes a circuit and the parameters L, M of a BB code to return a qubit-layout
    that attempts to minimize the distance between any two qubits that are supposed to interact during the circuit.
    Grid is the underlying grid on which the optimization problem is being solved.

    First, we create a list of reasonable layouts for the data qubits on the grid. Then, we use matchings to place the ancillae in a way that
    optimizes distance for each 'reasonable layout'. We then pick the 'reasonable layout' that yields the best result.

    Note that we assume that the monomial LR in the creation of the good initial values satisfies LR = 1. In general, LR could be chosen arbitrarily.

    We currently also assume that the qubits can move along a square-grid of dimensions 2*ord1, 2*ord2.
    In principle, this code is amenable to generalization, but one has to figure out what the generalization of get_good_inits should be.
    """
    data_qubits, check_qubits, qubit_list, qubit_type, code_matrix = get_key_data(A, B)
    # good_inits = get_good_inits(L, M)
    layout_list = get_promising_data_layouts(A, B, L, M)
    qubit_layout = {}
    R_optimal = L * M
    optimal_data_layout = {}

    for layout, ord1, ord2, vec1, vec2, transition_vectorLR in layout_list:
        # for a in range(L):
        #     for b in range(M):
        #         transition_vector_LR = (a,b)
        Grid = nx.grid_2d_graph(2 * ord1, 2 * ord2, periodic=False)
        Grid_check = True
        layout_inst = fold_layout(layout, ord1, ord2)
        cond = True
        R = 1
        while cond:  # Is the 'is True' really right/necessary?
            check_qubits_layout = {}
            G_R = build_connection_graph(
                A, B, Grid, R, layout_inst, Grid_check, 2 * ord1, 2 * ord2
            )
            perf_match = nx.maximal_matching(G_R)
            check1 = True
            for qubit in check_qubits:
                check2 = False
                for edge in perf_match:
                    check2 = check2 or (qubit in edge)
                    if qubit in edge:
                        for node in edge:
                            if node != qubit:
                                check_qubits_layout[qubit] = node
                check1 = check1 and check2
            if check1:
                perf_match = list(perf_match)
                cond = False
            else:
                R = R + 1
        if R < R_optimal:
            optimal_data_layout = layout_inst
            optimal_check_layout = check_qubits_layout
            R_optimal = R
            Grid_optimal = Grid
            ord1_optimal = ord1
            ord2_optimal = ord2
            vec1_optimal = vec1
            vec2_optimal = vec2
            transition_vector_optimal = transition_vectorLR
        if R <= 29:
            print(vec1, vec2, transition_vectorLR, R)
        if (vec1 == (1, 0) and vec2 == (0, 1)) or (vec1 == (0, 1) and vec2 == (1, 0)):
            print(layout_inst | check_qubits_layout)
            print(R)

    qubit_layout = optimal_data_layout | optimal_check_layout

    print(
        "The optimal layout is on a "
        + str(2 * ord1_optimal)
        + " x "
        + str(2 * ord2_optimal)
        + " Grid."
    )
    print("The largest interaction-distance is " + str(R_optimal) + ".")

    return (
        qubit_layout,
        Grid_optimal,
        2 * ord1_optimal,
        2 * ord2_optimal,
        vec1_optimal,
        vec2_optimal,
        transition_vector_optimal,
    )


def get_optimized_qubit_layout_bipartate(A, B, L, M):
    """
    Takes a circuit and the parameters L, M of a BB code to return a qubit-layout
    that attempts to minimize the distance between any two qubits that are supposed to interact during the circuit.
    Grid is the underlying grid on which the optimization problem is being solved.

    First, we create a list of reasonable layouts for the data qubits on the grid. Then, we use matchings to place the ancillae in a way that
    optimizes distance for each 'reasonable layout'. We then pick the 'reasonable layout' that yields the best result.

    Note that we assume that the monomial LR in the creation of the good initial values satisfies LR = 1. In general, LR could be chosen arbitrarily.

    We currently also assume that the qubits can move along a square-grid of dimensions 2*ord1, 2*ord2.
    In principle, this code is amenable to generalization, but one has to figure out what the generalization of get_good_inits should be.
    """
    data_qubits, check_qubits, qubit_list, qubit_type, code_matrix = get_key_data(A, B)
    # good_inits = get_good_inits(L, M)
    layout_list = get_promising_data_layouts(A, B, L, M)
    qubit_layout = {}
    R_optimal = L * M
    optimal_data_layout = {}

    for layout, ord1, ord2, vec1, vec2, transition_vectorLR in layout_list:
        Grid = nx.grid_2d_graph(2 * ord1, 2 * ord2, periodic=False)
        Grid_check = True
        layout_inst = fold_layout(layout, ord1, ord2)

        # Binary search instead of linear search to get log complexity
        low = 1
        high = (2 * ord1) + (2 * ord2)
        best_R_for_layout = float("inf")  # traditionally you do this
        check_qubits_layout = {}

        while low <= high:
            mid = (low + high) // 2

            G_R = build_connection_graph(
                A, B, Grid, mid, layout_inst, Grid_check, 2 * ord1, 2 * ord2
            )
            perf_match = nx.bipartite.maximum_matching(G_R, top_nodes=check_qubits)

            if all(qubit in perf_match for qubit in check_qubits):
                best_R_for_layout = mid
                check_qubits_layout = {
                    qubit: perf_match[qubit] for qubit in check_qubits
                }
                optimal_data_layout = layout_inst
                optimal_check_layout = check_qubits_layout
                R_optimal = best_R_for_layout
                Grid_optimal = Grid
                ord1_optimal = ord1
                ord2_optimal = ord2
                vec1_optimal = vec1
                vec2_optimal = vec2
                transition_vector_optimal = transition_vectorLR
                high = mid - 1
            else:
                low = mid + 1
        # if best_R_for_layout <= 29:
        #     pass
        # print(vec1, vec2, transition_vectorLR, best_R_for_layout)
    qubit_layout = optimal_data_layout | optimal_check_layout

    print(
        "The optimal layout is on a "
        + str(2 * ord1_optimal)
        + " x "
        + str(2 * ord2_optimal)
        + " Grid."
    )
    print("The largest interaction-distance is " + str(R_optimal) + ".")

    return (
        qubit_layout,
        Grid_optimal,
        2 * ord1_optimal,
        2 * ord2_optimal,
        vec1_optimal,
        vec2_optimal,
        transition_vector_optimal,
    )


def translate_dictionary(qubit_layout):
    new_dict = {}
    for ind in qubit_layout.keys():
        new_dict[stim.GateTarget(ind[0])] = qubit_layout[ind]
    return new_dict
