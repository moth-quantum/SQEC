import networkx as nx


def create_shuttling_errors(
    qubit_list,
    coord,
    meeting_points,
    Grid,
    p_base,
    ratio_T1toT2,
    ratio_idlingtoshuttling,
):
    shuttling_data = {}
    shuttling_distance = {}
    idling_time = {}
    shuttling_probability = {}
    idling_probability = {}
    idling_probabilityT1 = {}
    idling_probabilityT2 = {}

    for qubit in qubit_list:
        shuttling_distance[qubit] = nx.shortest_path_length(
            Grid, coord[qubit], meeting_points[qubit]
        )

    tick_time = max(shuttling_distance)
    for qubit in qubit_list:
        idling_time[qubit] = tick_time - shuttling_distance[qubit]
        shuttling_probability[qubit] = (
            1 - (1 - p_base * ratio_idlingtoshuttling) ** shuttling_distance[qubit]
        )
        idling_probabilityT1[qubit] = 1 - (1 - p_base) ** idling_time[qubit]
        idling_probabilityT2[qubit] = (
            1 - (1 - p_base * ratio_T1toT2) ** idling_time[qubit]
        )
        idling_probability[qubit] = (
            idling_probabilityT1[qubit] + idling_probabilityT2[qubit]
        )
        shuttling_data[qubit] = {
            "T1": idling_probabilityT1[qubit],
            "T2": idling_probabilityT2[qubit],
            "total idling probability": idling_probability[qubit],
            "shuttling distance": shuttling_distance[qubit],
            "idling time": idling_time[qubit],
            "shuttling error probability": shuttling_probability[qubit],
            "total error probability": 1
            - (1 - shuttling_probability[qubit]) * (1 - idling_probability[qubit]),
        }

    return shuttling_data


def create_paired_shuttling_errors(shuttling_data, pair):
    paired_shuttling_error = {}
    for qubit in shuttling_data.keys():
        if qubit in pair.keys():
            if pair[qubit] == "solo":
                paired_shuttling_error[(qubit, "solo")] = (
                    "DEPOLARIZE1",
                    shuttling_data[qubit]["total error probability"](
                        qubit,
                    ),
                )  # In the last entry of the triple: Should it be qubit or should it be 0? Check in the modify_stim_circuit file.
            else:
                paired_shuttling_error[(qubit, pair[qubit])] = [
                    (
                        "DEPOLARIZE1",
                        shuttling_data[qubit]["total error probability"],
                        (qubit,),
                    ),
                    (
                        "DEPOLARIZE1",
                        shuttling_data[pair[qubit]]["total error probability"],
                        (pair[qubit],),
                    ),
                ]

    return paired_shuttling_error


qubit_list = [0, 1, 2, 3, 4]
coord = {0: (0, 0), 1: (0, 1), 2: (0, 2), 3: (1, 0), 4: (1, 1)}

Grid = nx.grid_2d_graph(3, 3, periodic=False, create_using=None)

meeting_points = {0: (0, 2), 1: (1, 1), 2: (0, 2), 3: (1, 1), 4: (1, 2)}


p = 0.005
rT12 = 1.2
ris = 2


create_shuttling_errors(qubit_list, coord, meeting_points, Grid, p, rT12, ris)
