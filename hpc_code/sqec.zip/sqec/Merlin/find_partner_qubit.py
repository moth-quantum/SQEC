"""
Given a tick, build a dictionary that pairs those qubits that interact with each other during this tick.
Each pair appears only once, with one qubit as the index and the other as the value.
All qubits that don't interact with another qubit are assigned the string 'solo'.
"""
import stim

ideal = stim.Circuit(
    """
    H 4 5 6 7
    CX 0 1
    CX 2 3
    M 8 9
"""
)


two_qubit_gates = {
    "CX",
}  # Add the other needed 2-qubit-gates


def create_qubit_list(circuit):  # Given a circuit, it creates the list of qubits used.
    qubit_list = []
    for inst in circuit:
        targets = inst.targets_copy()
        for i in range(len(targets)):
            if targets[i] not in qubit_list:
                qubit_list.append(targets[i])
    return qubit_list


# def initialize_coordinates(start_coord, qubit_list, Grid)
#     """
#     Initializes a dictionary of qubits with their initial position on the grid.
#     """
#     coord = {}
#     for qubit in qubit_list:
#         coord[qubit] = start_coord[qubit]
#     #This kinda does nothing at the moment, except converting start_coord into a dictionary... but the input into start_coord could just be a dictionary.
#     return coord


def find_partner_qubit(circuit_tick, qubit_list):
    pair = {}
    for inst in circuit_tick:
        if inst.name in two_qubit_gates:
            targets = inst.targets_copy()
            for i in range(0, len(targets), 2):
                if targets[i] not in pair:
                    if targets[i + 1] not in pair:
                        pair[targets[i]] = targets[i + 1]
        else:
            targets = inst.targets_copy()
            for i in range(len(targets)):
                pair[targets[i]] = "solo"
    for inst in qubit_list:
        if inst not in pair:
            if inst not in pair.values():
                pair[inst] = "solo"

    return pair


# find_partner_qubit(ideal, create_qubit_list(ideal))
