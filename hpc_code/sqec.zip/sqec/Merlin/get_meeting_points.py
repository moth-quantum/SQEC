import networkx as nx


Grid = nx.grid_2d_graph(
    12, 24, periodic=False, create_using=None
)  # Build square-grid graph of appropriate size.

coord = {}
for i in range(12):
    for j in range(24):
        coord[24 * i + j] = (i, j)

pair = {}
for i in range(0, 144, 1):
    pair[i] = 288 - i
# for i in range(0,288,2):
#     pair[i] = i+1


def build_meeting_graph(coord, Grid, pair, Radius):
    G_R = nx.Graph()
    for ind in pair.keys():
        G_R.add_node((ind, pair[ind]))
    G_R.add_nodes_from(Grid)

    for ind in pair.keys():
        for node in Grid:
            if pair[ind] in coord.keys():
                if nx.shortest_path_length(Grid, coord[ind], node) <= Radius:
                    if nx.shortest_path_length(Grid, coord[pair[ind]], node) <= Radius:
                        G_R.add_edge((ind, pair[ind]), node)
            else:
                if nx.shortest_path_length(Grid, coord[ind], node) <= Radius:
                    G_R.add_edge((ind, pair[ind]), node)

    return G_R


def get_meeting_points(coord, Grid, pair):
    R = 1
    cond = True
    while cond:
        G_R = build_meeting_graph(coord, Grid, pair, R)
        perf_match = nx.maximal_matching(G_R)
        check1 = True  # The next few lines create a check, whether every qubit appears in an edge of the matching. If so, our matching is sufficiently large.
        for ind in pair.keys():
            check2 = False
            for edge in perf_match:
                check2 = check2 or (ind, pair[ind]) in edge
            check1 = check1 and check2
        if check1:
            #        if nx.is_perfect_matching(G_R, perf_match): #I would like to use this function, but I think our desired matchings may not be perfect in general.
            perf_match = sorted(perf_match)
            cond = False
        else:
            R = R + 1
    print(perf_match)
    meeting_points = {}
    for edge in perf_match:
        for ind in pair:
            if (ind, pair[ind]) in edge:
                for i in edge:
                    if i != (ind, pair[ind]):
                        meet_up = i
                meeting_points[ind] = meet_up
                meeting_points[pair[ind]] = meet_up

    return meeting_points
