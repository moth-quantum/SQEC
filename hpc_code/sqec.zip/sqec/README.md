Start of the repo for our quantum error correction for spin qubits with shuttling and other device specific constraints 
To set up you should, in addition to installing the required packages, install pre-commit hooks and the like with 

```pip install pre-commit ruff detect-secrets```
or ```uv add pre-commit ruff detect-secrets```

as an additional step, run ```pre-commit install``` after the above packages are installed. 
