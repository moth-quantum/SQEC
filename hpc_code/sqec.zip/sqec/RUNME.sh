#!/bin/bash

echo "Starting environment setup..."

uv sync

VENV_PYTHON_DIR=$(ls -d .venv/lib/python3.* | head -n 1)
GAP_PKG_DIR="${VENV_PYTHON_DIR}/site-packages/gap/pkg/qdistrnd"

if [ ! -d "$GAP_PKG_DIR" ]; then
    echo "Downloading QDistRnd..."
    git clone https://github.com/QEC-pages/QDistRnd "$GAP_PKG_DIR"
else
    echo "QDistRnd already installed."
fi

echo "Submitting Slurm array job..."
sbatch cluster.slurm