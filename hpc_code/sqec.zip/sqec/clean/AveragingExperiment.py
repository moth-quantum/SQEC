import sinter
from clean.utils import (
    create_qubit_list,
    find_partner_qubit,
    Grid_distance,
    pair_to_travelers,
    split_at_ticks,
    apply_custom_noise,
    reassemble_circuit,
)
import clean.codes as our_codes
from qldpc import decoders
import os
import matplotlib.pyplot as plt
import MemoryExperiment as mex
import StartingCoordinates as SC
import networkx as nx
from sympy.abc import x, y


class AveragingExperiment(our_codes.BBCodes):
    def __init__(
        self, qubit_layout, p_near, p_far, weight_near, weight_far, L, M, polyA, polyB
    ):
        super().__init__(L, M, polyA, polyB)
        self.get_memory_experiment_circuit(False, 1)
        self.p_near = p_near
        self.p_far = p_far
        self.weight_near = weight_near
        self.weight_far = weight_far
        self.qubit_layout = qubit_layout
        self.qubit_list_circuit = create_qubit_list(
            self.cmex_circuit_parts[self.distance][1]
        )
        self.noisy_circuit = {"near-far": {}, "average": {}}
        self.collected_stats = {"near-far": {}, "average": {}}
        self.comparison_check = {}

    def create_near_far_errors(self, tick, threshold):
        """
        Creates a dictionary with the noise for different pairs of qubits within one tick
        """

        pair = find_partner_qubit(tick, self.qubit_list_circuit)
        travelers = pair_to_travelers(pair)
        paired_noise_data = {}
        paired_noise_error = {}

        for traveler in travelers:
            if len(traveler) > 1:
                if (
                    Grid_distance(
                        self.qubit_layout[traveler[0]], self.qubit_layout[traveler[1]]
                    )
                    > threshold
                ):  # qubits far apart
                    paired_noise_data[traveler] = self.p_far
                else:  # qubits close together
                    paired_noise_data[traveler] = self.p_near
                paired_noise_error[traveler] = [
                    ("DEPOLARIZE1", paired_noise_data[traveler], traveler)
                ]

        return paired_noise_error

    def create_average_errors(self, tick):
        """
        Creates a dictionary with the noise for different pairs of qubits within one tick
        """

        pair = find_partner_qubit(tick, self.qubit_list_circuit)
        travelers = pair_to_travelers(pair)
        paired_noise_error = {}
        average = (self.p_far * self.weight_far + self.p_near * self.weight_near) / (
            self.weight_far + self.weight_near
        )

        for traveler in travelers:
            if len(traveler) > 1:
                paired_noise_error[traveler] = [("DEPOLARIZE1", average, traveler)]

        return paired_noise_error

    def get_near_far_noisy_circuit(self, threshold):
        """
        For a given threshold and noise-free circuit, it adds noise to the 2-qubit gates based on whether
        the distance between the qubits is greater than, or at most equal to threshold.

        Returns a noisy circuit and stores it in self.noisy_circuit["near-far"][(self.p_near, self.p_far, threshold)].
        """
        tick_list = split_at_ticks(self.cmex_circuit_parts[self.distance][1])
        noisy_tick_list = []

        for tick in tick_list:
            if not (
                ("DETECTOR" in str(tick))
                or ("rec" in str(tick))
                or ("-" in str(tick) or "M" in str(tick))
            ):
                paired_noise_data = self.create_near_far_errors(tick, threshold)
                noisy_tick_list.append(apply_custom_noise(tick, paired_noise_data))
            else:
                noisy_tick_list.append(tick)

        noisy_qec_cycle = reassemble_circuit(noisy_tick_list, insert_ticks=True)
        initialization, _, readout, _, _, _ = self.cmex_circuit_parts[self.distance]
        self.noisy_circuit["near-far"][(self.p_near, self.p_far, threshold)] = (
            initialization + noisy_qec_cycle + readout
        )

        # diagram = noisy_circuit.diagram("timeline-svg")
        # with open("diagram.svg", "w") as f:
        #     print(diagram, file=f)

        return self.noisy_circuit["near-far"][(self.p_near, self.p_far, threshold)]

    def get_average_noisy_circuit(self):
        """
        For a given threshold and noise-free circuit, it adds noise to the 2-qubit gates based on whether
        the distance between the qubits is greater than, or at most equal to threshold.

        Returns a noisy circuit and stores it in self.noisy_circuit["near-far"][(self.p_near, self.p_far, threshold)].
        """
        tick_list = split_at_ticks(self.cmex_circuit_parts[self.distance][1])
        noisy_tick_list = []

        for tick in tick_list:
            if not (
                ("DETECTOR" in str(tick))
                or ("rec" in str(tick))
                or ("-" in str(tick) or "M" in str(tick))
            ):
                paired_noise_data = self.create_average_errors(tick)
                noisy_tick_list.append(apply_custom_noise(tick, paired_noise_data))
            else:
                noisy_tick_list.append(tick)

        noisy_qec_cycle = reassemble_circuit(noisy_tick_list, insert_ticks=True)
        initialization, _, readout, _, _, _ = self.cmex_circuit_parts[self.distance]
        self.noisy_circuit["average"][
            (self.p_near, self.p_far, self.weight_near, self.weight_far)
        ] = initialization + noisy_qec_cycle + readout

        # diagram = noisy_circuit.diagram("timeline-svg")
        # with open("diagram.svg", "w") as f:
        #     print(diagram, file=f)

        return self.noisy_circuit["average"][
            (self.p_near, self.p_far, self.weight_near, self.weight_far)
        ]

    def run_nfav_experiment(
        self,
        prob_list,
        weight_list,
        threshold,
        max_shots: int = 10**5,
        max_errors: int = 100,
        **decoding_kwargs,
    ):
        near_far_tasks = []
        average_tasks = []

        custom_decoders = {}  # each code is going to need its own decoder

        # Collect the components of the memory experiment.  In particular, we will need the record
        # of detectors and qubit indices.
        rounds = self.distance
        self.get_memory_experiment_circuit(False, rounds)
        (
            _,
            _,
            _,
            _,
            detector_record,
            qubit_ids,
        ) = self.cmex_circuit_parts[rounds]

        # Identify detectors associated with X-type and Z-type stabilizers (parity checks).
        detectors_x = detector_record.get_events(*qubit_ids.checks_x)
        detectors_z = detector_record.get_events(*qubit_ids.checks_z)

        # Build a decoder that separately decodes X and Z sectors to predict X and Z observables.
        # Here X observables are numbered 0, 1, ..., code.dimension - 1, and Z observables are
        # numbered code.dimension, code.dimension + 1, ..., code.dimension * 2 - 1.
        decoder = decoders.SubgraphSinterDecoder(
            (detectors_x, detectors_z),  # X/Z detectors
            (
                range(self.dimension),
                range(self.dimension, 2 * self.dimension),
            ),  # X/Z observables
            **decoding_kwargs,
        )
        decoder_name = f"decoder_{0}"  # The 0 used to be code_index. But since we don't have a list of codes anymore, we have to replace it.
        custom_decoders[decoder_name] = decoder

        for prob_pair in prob_list:
            self.p_near = prob_pair[0]
            self.p_far = prob_pair[1]
            for weight_pair in weight_list:
                self.weight_near = weight_pair[0]
                self.weight_far = weight_pair[1]
                self.get_near_far_noisy_circuit(threshold)
                self.get_average_noisy_circuit()
                near_far_tasks.append(
                    sinter.Task(
                        circuit=self.noisy_circuit["near-far"][
                            (self.p_near, self.p_far, threshold)
                        ],
                        decoder=decoder_name,
                        json_metadata={
                            "label": self.get_label(),
                            "prob": (self.p_near, self.p_far),
                            "weights": (self.weight_near, self.weight_far),
                        },
                    )
                )
                average_tasks.append(
                    sinter.Task(
                        circuit=self.noisy_circuit["average"][
                            (self.p_near, self.p_far, self.weight_near, self.weight_far)
                        ],
                        decoder=decoder_name,
                        json_metadata={
                            "label": self.get_label(),
                            "prob": (self.p_near, self.p_far),
                            "weights": (self.weight_near, self.weight_far),
                        },
                    )
                )

        print("Check in before sinter.")

        collected_near_far_stats = sinter.collect(
            num_workers=os.cpu_count() - 2,
            max_shots=max_shots,
            max_errors=max_errors,
            tasks=near_far_tasks,
            custom_decoders=custom_decoders,
        )

        collected_average_stats = sinter.collect(
            num_workers=os.cpu_count() - 2,
            max_shots=max_shots,
            max_errors=max_errors,
            tasks=average_tasks,
            custom_decoders=custom_decoders,
        )

        print("Check in after sinter.")

        self.collected_stats["near-far"][threshold] = {}
        self.collected_stats["average"][threshold] = {}
        for stat in collected_near_far_stats:
            if (
                stat.json_metadata["weights"]
                not in self.collected_stats["near-far"][threshold].keys()
            ):
                self.collected_stats["near-far"][threshold][
                    stat.json_metadata["weights"]
                ] = {}
            self.collected_stats["near-far"][threshold][stat.json_metadata["weights"]][
                stat.json_metadata["prob"]
            ] = stat
        for stat in collected_average_stats:
            if (
                stat.json_metadata["weights"]
                not in self.collected_stats["average"][threshold].keys()
            ):
                self.collected_stats["average"][threshold][
                    stat.json_metadata["weights"]
                ] = {}
            self.collected_stats["average"][threshold][stat.json_metadata["weights"]][
                stat.json_metadata["prob"]
            ] = stat

        if threshold not in self.comparison_check.keys():
            self.comparison_check[threshold] = {}

        for weight_pair in weight_list:
            if weight_pair not in self.comparison_check[threshold].keys():
                self.comparison_check[threshold][weight_pair] = {}
            for prob_pair in prob_list:
                near_far_errors = self.collected_stats["near-far"][threshold][
                    weight_pair
                ][prob_pair].errors / (
                    self.collected_stats["near-far"][threshold][weight_pair][
                        prob_pair
                    ].shots
                    - self.collected_stats["near-far"][threshold][weight_pair][
                        prob_pair
                    ].discards
                )
                average_errors = self.collected_stats["average"][threshold][
                    weight_pair
                ][prob_pair].errors / (
                    self.collected_stats["average"][threshold][weight_pair][
                        prob_pair
                    ].shots
                    - self.collected_stats["average"][threshold][weight_pair][
                        prob_pair
                    ].discards
                )
                if (
                    0 < average_errors
                    and average_errors < 1
                    and 0 < near_far_errors
                    and near_far_errors < 1
                ):  # Throw out cases where the logical error rate is degenerate (0 or 1).
                    self.comparison_check[threshold][weight_pair][prob_pair] = (
                        near_far_errors >= average_errors
                    )
                else:
                    self.comparison_check[threshold][weight_pair][prob_pair] = None

        return self.comparison_check

    def make_nfav_experiment_figure(self, threshold, weight_pair):
        """
        Creates a plot of the averaging experiments. Blue dots indicate that averaging yields a smaller error rate.
        Red dots indicate that the near-far setup yields a smaller error rate.
        """
        blue_x, blue_y = [], []
        red_x, red_y = [], []
        black_x, black_y = [], []

        # Separate coordinates based on boolean values
        for a, b in self.comparison_check[threshold][weight_pair].keys():
            if self.comparison_check[threshold][weight_pair][
                (a, b)
            ]:  # If average is better than near_far
                blue_x.append(a)
                blue_y.append(b)
            elif (
                self.comparison_check[threshold][weight_pair][(a, b)] is None
            ):  # If either average or near_far simulation has logical error rate 0 or 1.
                black_x.append(a)
                black_y.append(b)
            else:  # If average is worse than near_far
                red_x.append(a)
                red_y.append(b)

        # print(blue_x,blue_y)

        # print(red_x,red_y)

        # Plotting
        plt.figure(figsize=(8, 6))
        plt.scatter(blue_x, blue_y, color="blue", label="Averaging is better")
        # if red_x:
        plt.scatter(red_x, red_y, color="red", label="Averaging is worse")
        plt.scatter(black_x, black_y, color="black", label="Comparison n/a")

        # Because the points are logarithmically spaced, log scale is appropriate
        plt.xscale("log")
        plt.yscale("log")
        plt.xlabel("p_near")
        plt.ylabel("p_far")
        plt.title("Comparison average versus near-far")
        plt.legend()
        plt.grid(True, which="both", ls="--", alpha=0.5)
        plt.show()


# -----------TEST BEGINS--------------

if __name__ == "__main__":
    print("I have reached the beginning of the test.")

    polyA = x**3 + y + y**2
    polyB = y**3 + x + x**2
    L = 12
    M = 6
    X = 2 * L
    Y = 2 * M
    Grid = nx.grid_2d_graph(X, Y, periodic=False, create_using=None)
    Grid_check = "Squaregrid"
    decoding_kwargs = dict(
        with_BP_LSD=True, max_iter=30, bp_method="ms", lsd_method="lsd_cs", lsd_order=0
    )

    ratio_T1toT2 = 0
    # ratio_T1toT2  = 3.26
    ratio_T1toidlehalf = 0.0017
    ratio_T1toshuttlinghalf = 0.004

    p_near = 0.05
    p_far = 0.1
    weight_near = 2
    weight_far = 1
    threshold = 2

    initial_qubit_layout = SC.StartingCoordinates(L, M, polyA, polyB, Grid, X, Y)

    initial_qubit_layout.get_a_Tanner_layout()

    initial_qubit_layout.get_folded_Tanner_layout()

    # initial_qubit_layout.get_optimal_qubit_layout()
    # print(initial_qubit_layout.qubit_layouts["optimized"])

    initial_qubit_layout.get_quadrant_qubit_layout()

    initial_qubit_layout.get_random_qubit_layout()

    averaging_experiment_initial = mex.MemoryExperiment(
        Distance_choice=False,
        rounds=1,
        starting_coord=initial_qubit_layout.qubit_layouts["folded Tanner"],
        Grid=Grid,
        X=X,
        Y=Y,
        L=L,
        M=M,
        polyA=polyA,
        polyB=polyB,
        Grid_check=Grid_check,
        ratio_T1toT2=ratio_T1toT2,
        ratio_T1toidlehalf=ratio_T1toidlehalf,
        ratio_T1toshuttlinghalf=ratio_T1toshuttlinghalf,
    )

    averaging_experiment = AveragingExperiment(
        qubit_layout=initial_qubit_layout.qubit_layouts["folded Tanner"],
        p_near=p_near,
        p_far=p_far,
        weight_near=weight_near,
        weight_far=weight_far,
        L=L,
        M=M,
        polyA=polyA,
        polyB=polyB,
    )

    prob_list = [(0.1, 0.05), (0.075, 0.05)]
    weight_list = [(2, 1), (10, 9)]
    threshold = 2
    averaging_experiment.run_nfav_experiment(
        prob_list=prob_list,
        weight_list=weight_list,
        threshold=threshold,
        **decoding_kwargs,
    )
