shuttling_strategies = [
    "maximum_matching_efficient",
    "min_weight_matching_efficient",
    "total_shuttling_minimized",
]
noise_models = ["linear", "exponential", "gaussian"]
qubit_layouts = ["optimized"]
idle_list = [1, 1.8]
shuttling_list = [0.005, 0.01, 0.05, 0.1]
idle_etas = [0.5]
shuttle_etas = [0.5, 100]
t2s = [0, 1]
Grid_list = ["Squaregrid", "Octagrid"]
error_start = -3.85
error_end = -1.9
error_number = 10
error_rates = [-3.85, -1.9, 10]
round_list = [12]

# "--strategy"
# "--model"
# "--initial_layout_type"
# "--idlehalf"
# "--shuttlehalf"
# "--eta_i"
# "--eta_sh"
# "--t2"
# "--Grid_check"
# "--error_rates"
# "--rounds"

inputstring = ""

for polar in shuttle_etas:
    for Grid_check in Grid_list:
        for t2 in t2s:
            for shuttle_ratio in shuttling_list:
                for noise_model in noise_models:
                    for strategy in shuttling_strategies:
                        for layout in qubit_layouts:
                            for idle_ratio in idle_list:
                                for round in round_list:
                                    for eta_i in idle_etas:
                                        inputstring += f"--strategy {strategy} --model {noise_model} --initial_layout_type {layout} --idlehalf {idle_ratio} --shuttlehalf {shuttle_ratio} --eta_i {eta_i} --eta_sh {polar} --t2 {t2} --Grid_check {Grid_check} --error_start {error_start} --error_end {error_end} --error_number {error_number} --rounds {round}\n"

with open("arguments.txt", "w") as f:
    f.write(inputstring)
    f.close()
