import argparse
import clean.MemoryExperiment as mex
from clean.utils import build_octa_grid
import clean.StartingCoordinates as SC
from utils import NoiseConfig


import networkx as nx
from sympy.abc import x, y
import numpy as np


if __name__ == "__main__":
    parser = argparse.ArgumentParser(
        description="Run Memory Experiment for specific parameters."
    )
    parser.add_argument(
        "--strategy", type=str, required=True, help="Shuttling strategy to use."
    )
    parser.add_argument(
        "--model", type=str, required=True, help="Noise model to apply."
    )
    parser.add_argument(
        "--initial_layout_type",
        type=str,
        required=True,
        help="Type of starting qubit layout.",
    )
    parser.add_argument(
        "--idlehalf", type=float, required=True, help="Ratio of T1 to idle half."
    )
    parser.add_argument(
        "--shuttlehalf",
        type=float,
        required=True,
        help="Ratio of T1 to shuttling half.",
    )
    parser.add_argument(
        "--eta_i", type=float, required=True, help="Eta parameter for idle operations."
    )
    parser.add_argument(
        "--eta_sh",
        type=float,
        required=True,
        help="Eta parameter for shuttle and CZ operations.",
    )
    parser.add_argument(
        "--t2",
        type=float,
        required=True,
        help="Ratio for 2-qubit operations, measurement, and reset.",
    )
    parser.add_argument("--Grid_check", type=str, required=True, help="Type of Grid.")
    parser.add_argument(
        "--error_start",
        type=float,
        required=True,
        help="Error rates that we run simulation for.",
    )
    parser.add_argument(
        "--error_end",
        type=float,
        required=True,
        help="Error rates that we run simulation for.",
    )
    parser.add_argument(
        "--error_number",
        type=int,
        required=True,
        help="Error rates that we run simulation for.",
    )

    parser.add_argument(
        "--rounds",
        type=int,
        required=True,
        help="Number of syndrome extraction rounds.",
    )

    args = parser.parse_args()

    polyA = x**3 + y + y**2
    polyB = y**3 + x + x**2

    L = 12
    M = 6
    X = 2 * L
    Y = 2 * M

    if args.Grid_check == "Squaregrid":
        Grid = nx.grid_2d_graph(X, Y, periodic=False, create_using=None)
    elif args.Grid_check == "Octagrid":
        Grid = build_octa_grid(X, Y)

    error_rates = np.logspace(args.error_start, args.error_end, args.error_number)

    max_shots = 10**5
    max_errors = 100

    Distance_check = True
    rounds = 12

    decoding_kwargs = dict(
        with_BP_LSD=True, max_iter=30, bp_method="ms", lsd_method="lsd_cs", lsd_order=0
    )

    round_list = [args.rounds]

    initial_qubit_layout = SC.StartingCoordinates(
        L=12,
        M=6,
        polyA=polyA,
        polyB=polyB,
        Grid=Grid,
        X=X,
        Y=Y,
        load_file="starting_coordinates.json",
    )
    # error_rates = np.logspace(-3.85,-1.9,10)
    # idle_list = [0.0017]
    # shuttling_list = [0.004, 0.04]
    # idle_etas = [0.5]
    # shuttle_etas = [0.5, 100]
    # cz_etas = [0.5, 100]
    # cnot_etas = [0.5]
    # t2s = [0,1]
    # meas_ratios = [0,2]
    # reset_ratios = [0,2]
    # shuttling_strategies = ["maximum_matching_efficient", "min_weight_matching_efficient", "total_shuttling_minimized"]
    # noise_models = ["linear","exponential", "gaussian"]
    # qubit_layouts = ["random1", "Tanner", "folded Tanner", "optimized", "quadrants"]
    # round_list = [12]

    sweep_configs = [
        NoiseConfig(
            noise_model=args.model,
            ratio_T1toidlehalf=args.idlehalf * args.shuttlehalf,
            ratio_T1toshuttlinghalf=args.shuttlehalf,
            eta_idle=args.eta_i,
            eta_shuttle=args.eta_sh,
            eta_cz=args.eta_sh,
            eta_cnot=args.eta_i,
            ratio_2q=args.t2,
            ratio_meas=2 * args.t2,
            ratio_reset=2 * args.t2,
        )
    ]

    memory_experiment = mex.MemoryExperiment(
        Distance_choice=Distance_check,
        rounds=rounds,
        starting_coord=initial_qubit_layout.qubit_layouts[args.initial_layout_type],
        starting_coord_type=args.initial_layout_type,
        Grid=Grid,
        X=X,
        Y=Y,
        L=L,
        M=M,
        polyA=polyA,
        polyB=polyB,
        Grid_check=args.Grid_check,
        noise_config=sweep_configs[0],
    )

    memory_experiment.memory_experiment_data_sweep(
        strategy=args.strategy,
        round_list=round_list,
        error_rates=error_rates,
        noise_configs=sweep_configs,
        **decoding_kwargs,
    )

    filename = f"cluster_results/datasweep_{args.strategy}_{args.model}_idle{args.idlehalf}_shuttle{args.shuttlehalf}_polarize{args.eta_sh}_2qubits{args.t2}_grid{args.Grid_check}_errorrates{args.error_start}_{args.error_end}_{args.error_number}.json"
    memory_experiment.save_experiment(filename)
    print(f"Simulation successfully saved to {filename}.")
