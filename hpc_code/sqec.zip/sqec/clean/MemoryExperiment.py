import clean.shuttling_strategies as shut
import clean.codes as our_codes
import networkx as nx
import numpy as np
from qldpc import circuits, decoders
import sinter
import os
from collections.abc import Sequence
import matplotlib.pyplot as plt
from clean.utils import (
    create_qubit_list,
    create_BB_qubit_list,
    estimate_code_distance,
    remove_noise_from_circuit,
)
import clean.StartingCoordinates as SC
import json
from utils import serialize_state, deserialize_state, NoiseConfig


class MemoryExperiment(shut.ShuttleNoisyCircuit, our_codes.BBCodes):
    def __init__(
        self,
        polyA,
        polyB,
        Distance_choice: bool = None,
        rounds: int = None,
        starting_coord: dict = None,
        starting_coord_type: str = None,
        Grid: nx.Graph() = None,
        X: int = None,
        Y: int = None,
        L: int = None,
        M: int = None,
        Grid_check: str = None,
        noise_config: NoiseConfig = None,
        load_file: str = None,
    ):
        if load_file and os.path.exists(load_file):
            self.load_experiment(load_file)
            return

        our_codes.BBCodes.__init__(self, L, M, polyA, polyB)
        _, ideal_circuit, _, _, _, _ = self.get_memory_experiment_circuit(
            Distance_choice, rounds
        )
        _, _, qubit_list_code, _ = create_BB_qubit_list(self.pc_matrix)
        qubit_list_circuit = create_qubit_list(ideal_circuit)

        self.noise_config = noise_config if noise_config is not None else NoiseConfig()

        shut.ShuttleNoisyCircuit.__init__(
            self,
            ideal_circuit,
            qubit_list_code,
            qubit_list_circuit,
            starting_coord,
            starting_coord_type,
            Grid,
            X,
            Y,
            Grid_check,
            noise_config=self.noise_config,
            BBcheck=True,
        )

        self.noisy_cmex_circuit = {
            "maximum_matching": {},
            "min_weight_matching": {},
            "total_shuttling_minimized": {},
            "maximum_matching_efficient": {},
            "min_weight_matching_efficient": {},
        }
        self.collected_stats = {
            "maximum_matching": {},
            "min_weight_matching": {},
            "total_shuttling_minimized": {},
            "maximum_matching_efficient": {},
            "min_weight_matching_efficient": {},
        }
        self.effective_distances = {
            "maximum_matching": {},
            "min_weight_matching": {},
            "total_shuttling_minimized": {},
            "maximum_matching_efficient": {},
            "min_weight_matching_efficient": {},
        }
        self.distance = self.get_distance()
        self.phys_and_logic_errors = {
            "maximum_matching": {},
            "min_weight_matching": {},
            "total_shuttling_minimized": {},
            "maximum_matching_efficient": {},
            "min_weight_matching_efficient": {},
        }

    def get_config_key(self, config: NoiseConfig = None) -> str:
        """Generates a stable, JSON-serializable string key for any given NoiseConfig."""
        if config is None:
            config = self.noise_config
        if isinstance(
            config, dict
        ):  # In case self.noise_config is a dictionary because of a reload.
            return json.dumps(config, sort_keys=True)
        return json.dumps(config.to_dict(), sort_keys=True)

    def get_cmex_circuit_parts(self, rounds: int):
        self.get_memory_experiment_circuit(True, rounds)
        _, self.ideal_circuit, _, _, _, _ = self.cmex_circuit_parts[rounds]
        return self.cmex_circuit_parts[rounds]

    def get_noisy_cmex_circuit(
        self, strategy: str, error_rates: Sequence[float], rounds: int
    ):
        initialization, qec_cycle, readout, _, _, _ = self.cmex_circuit_parts[rounds]
        self.noisy_cmex_circuit[strategy][rounds] = {}

        noise_model = circuits.DepolarizingNoiseModel(0, include_idling_error=False)
        auxiliary_cycle = noise_model.noisy_circuit(qec_cycle)
        self.ideal_circuit = remove_noise_from_circuit(auxiliary_cycle)
        self.get_noisy_circuit(strategy, error_rates, rounds)
        for prob in error_rates:
            self.noisy_cmex_circuit[strategy][rounds][prob] = (
                initialization + self.noisy_circuit[strategy][prob] + readout
            )

        return self.noisy_cmex_circuit[strategy][rounds]

    def run_cmex(
        self,
        strategy: str,
        error_rates: Sequence[float],
        rounds: int,
        max_shots: int = 10**5,
        max_errors: int = 100,
        **decoding_kwargs: object,
    ):
        self.get_cmex_circuit_parts(rounds)
        tasks = []
        custom_decoders = {}

        (_, _, _, _, detector_record, qubit_ids) = self.cmex_circuit_parts[rounds]

        detectors_x = detector_record.get_events(*qubit_ids.checks_x)
        detectors_z = detector_record.get_events(*qubit_ids.checks_z)

        decoder = decoders.SubgraphSinterDecoder(
            (detectors_x, detectors_z),
            (range(self.dimension), range(self.dimension, 2 * self.dimension)),
            **decoding_kwargs,
        )
        decoder_name = f"decoder_{0}"
        custom_decoders[decoder_name] = decoder

        self.get_noisy_cmex_circuit(strategy, error_rates, rounds)

        for prob in error_rates:
            noisy_circuit = self.noisy_cmex_circuit[strategy][rounds][prob]
            tasks.append(
                sinter.Task(
                    circuit=noisy_circuit,
                    decoder=decoder_name,
                    json_metadata={"label": self.get_label(), "prob": prob},
                )
            )

        collected_stats = sinter.collect(
            num_workers=os.cpu_count(),
            max_shots=max_shots,
            max_errors=max_errors,
            tasks=tasks,
            custom_decoders=custom_decoders,
        )

        config_key = self.get_config_key()

        if rounds not in self.collected_stats[strategy]:
            self.collected_stats[strategy][rounds] = {}
        if config_key not in self.collected_stats[strategy][rounds]:
            self.collected_stats[strategy][rounds][config_key] = {}

        for stat in collected_stats:
            self.collected_stats[strategy][rounds][config_key][
                stat.json_metadata["prob"]
            ] = stat

        return self.collected_stats[strategy][rounds]

    def make_cmex_figure(
        self,
        strategy: str,
        error_rates,
        rounds: int,
        noise_config: NoiseConfig = None,
        figsize: tuple[int, int] = (5, 4),
        **decoding_kwargs: object,
    ) -> tuple[plt.Figure, plt.Axes]:
        """Use sinter to simulate memory cycles of the given codes, and plot the results.

        Args:
            codes_to_simulate: The codes we wish to simulate.
            error_rates: The i.i.d. probabilities of a depolarizing error after each gate.
            max_shots: Stop sampling the circuit after this many shots.
            max_errors: Stops the sampling process after this many errors have been seen in samples
                taken from the circuit.
            distance_trials: If the code distance is not known, estimate it with this many trials.
                The estimated distance determines the number of rounds of syndrome measurement.
            figsize: The size of the figure to produce.
            **decoding_kwargs: Arguments to pass to the decoder.

        Returns:
            The matplotlib.pyplot figure and axis.
        """

        if self.Grid_check == "Squaregrid":
            print(
                f"We are assuming that the Grid is a two-dimensional square grid of size {self.X} x {self.Y}."
            )

        if self.Grid_check == "Octagrid":
            print(
                f"We are assuming that the Grid is a two-dimensional octa-grid of size {self.X} x {self.Y}."
            )

        if rounds not in self.collected_stats[strategy].keys():
            print("Run .run_cmex first.")
            return

        config_key = self.get_config_key(noise_config)

        stats = []
        for prob, stat in (
            self.collected_stats[strategy][rounds].get(config_key, {}).items()
        ):
            if stat.errors != 0:
                stats.append(stat)

        figure, axis = plt.subplots(figsize=figsize)
        sinter.plot_error_rate(
            ax=axis,
            stats=stats,
            x_func=lambda stats: stats.json_metadata["prob"],
            group_func=lambda stats: stats.json_metadata["label"],
        )

        axis.axline(
            (0, 0),
            slope=1,
            color="k",
            linestyle=":",
            label=r"$p_{\mathrm{log}}=p_{\mathrm{phys}}$",
        )
        axis.loglog()
        axis.set_xlabel(r"physical error rate")
        axis.set_ylabel(r"logical error rate")
        axis.legend(loc="best")
        axis.grid(which="both")
        figure.tight_layout()

        return figure, axis

    def get_effective_code_distance(
        self,
        strategy,
        rounds,
        noise_config: NoiseConfig = None,
        **decoding_kwargs: object,
    ):
        """
        Runs a memory experiment, plots the simulation points and plots a linear regression.

        Returns the estimated distance distance_estimate obtained from the slope of the linear regression.
        In addition returns the x- and y-axes error_rates_non_deg and logical_errors_non_deg of the simulation points as lists.
        All simulations that returned 0 logical errors are discarded.
        """

        error_rates_non_deg = []
        logical_errors_non_deg = []
        config_key = self.get_config_key(noise_config)

        for prob, stat in (
            self.collected_stats[strategy][rounds].get(config_key, {}).items()
        ):
            logical_error_prob = stat.errors / (stat.shots - stat.discards)
            if not (stat.errors == 0 or logical_error_prob > 0.5):
                error_rates_non_deg.append(stat.json_metadata["prob"])
                logical_errors_non_deg.append(
                    stat.errors / (stat.shots - stat.discards)
                )

        if len(error_rates_non_deg) == 0:
            print("Logical error probability is degenerate for all error rates.")
            return
        if len(error_rates_non_deg) == 1:
            print(
                "Only one error rate yields a non-degenerate logical error probability. Linear regression cannot be done."
            )
            return

        if rounds not in self.phys_and_logic_errors[strategy]:
            self.phys_and_logic_errors[strategy][rounds] = {}
        self.phys_and_logic_errors[strategy][rounds][config_key] = list(
            zip(error_rates_non_deg, logical_errors_non_deg)
        )

        distance_estimate, slope, intercept, stderr = estimate_code_distance(
            error_rates_non_deg, logical_errors_non_deg
        )

        if rounds not in self.effective_distances[strategy]:
            self.effective_distances[strategy][rounds] = {}
        self.effective_distances[strategy][rounds][config_key] = distance_estimate

        print(f"Slope of linear regression: {slope}")
        print(f"Estimated distance: {distance_estimate}")
        # Initialize figure
        plt.figure(figsize=(10, 10))

        # Plot the results from the simulation in loglog-scale
        plt.scatter(
            error_rates_non_deg, logical_errors_non_deg, label="Simulation results"
        )

        # Plot the linear regression
        x_fit = np.linspace(min(error_rates_non_deg), max(error_rates_non_deg), 100)
        y_fit = (
            x_fit**slope * np.exp(intercept)
        )  # This corresponds to the fact that y_fit = exp( slope* log(x_fit) + intercept ) Because linearity holds for the loglog-scale, we have to take log of x_fit and then take the exponential of the linear function.
        plt.loglog(
            x_fit, y_fit, "--r", label=f"Linear Regression, d = {distance_estimate:.1f}"
        )

        # Add labels
        plt.xlabel("Physical Error Rate")
        plt.ylabel("Logical Error Rate")
        plt.title("Estimating code distance")
        plt.legend()

        # Add a grid: visible = True, which = along both axes,
        plt.grid(True, which="both", ls="-", alpha=0.5)

        plt.show()

        return distance_estimate, error_rates_non_deg, logical_errors_non_deg

    def memory_experiment_data_sweep(
        self,
        strategy: str,
        round_list: list,
        error_rates: Sequence[float],
        noise_configs: list[
            NoiseConfig
        ],  # Replaced dictionary sweep with list of Configs
        **decoding_kwargs: object,
    ) -> dict:
        if self.Grid_check == "Squaregrid":
            print(
                f"We are assuming that the Grid is a two-dimensional square grid of size {self.X} x {self.Y}."
            )
        if self.Grid_check == "Octagrid":
            print(
                f"We are assuming that the Grid is a two-dimensional octa-grid of size {self.X} x {self.Y}."
            )

        for rounds in round_list:
            self.get_cmex_circuit_parts(rounds)
            if rounds not in self.shuttling_routes[strategy]:
                self.get_shuttling_routes(strategy, rounds)
                print(
                    f"Finished shuttling calculations for {rounds} rounds of syndrome extraction."
                )

            if rounds not in self.phys_and_logic_errors[strategy]:
                self.phys_and_logic_errors[strategy][rounds] = {}

            for config in noise_configs:
                # Assign config and dynamically track runs using the key
                self.noise_config = config
                config_key = self.get_config_key(config)

                self.run_cmex(strategy, error_rates, rounds, **decoding_kwargs)
                print(f"Finished simulation for noise configuration:\n {config_key}.")

                stats = self.collected_stats[strategy][rounds][config_key]
                self.phys_and_logic_errors[strategy][rounds][config_key] = {}

                for prob, stat in stats.items():
                    logical_error_prob = (
                        stat.errors / (stat.shots - stat.discards)
                        if stat.shots - stat.discards > 0
                        else 0.0
                    )
                    self.phys_and_logic_errors[strategy][rounds][config_key][prob] = {
                        "physical error probability": prob,
                        "logical error probability": logical_error_prob,
                    }

        return self.collected_stats

    def save_experiment(self, filepath: str):
        """Saves the current instance state to a JSON file."""
        print("saving")
        state = {k: v for k, v in self.__dict__.items() if not k.startswith("__")}

        serialized_state = serialize_state(state)

        os.makedirs(os.path.dirname(os.path.abspath(filepath)) or ".", exist_ok=True)
        with open(filepath, "w") as f:
            json.dump(serialized_state, f, indent=4)
        print(f"Experiment data saved in: {filepath}")

    def load_experiment(self, filepath: str):
        """Loads and reconstructs the instance from a JSON file."""
        print("loading")
        with open(filepath, "r") as f:
            serialized_state = json.load(f)

        state = deserialize_state(serialized_state)

        for k, v in state.items():
            setattr(self, k, v)


# -------------TEST------------------


if __name__ == "__main__":
    import clean.shuttling_strategies as shut
    import clean.codes as our_codes
    import clean.MemoryExperiment as mex

    import networkx as nx
    from sqec.modify_stim_circuit import (
        remove_noise_from_circuit,
    )
    from sympy.abc import x, y
    import numpy as np
    from collections.abc import Sequence
    from qldpc import circuits, decoders

    print("I have reached the beginning of the test.")

    # Initiate BB-code
    polyA = x**3 + y + y**2
    polyB = y**3 + x + x**2

    L = 12
    M = 6
    X = 2 * L
    Y = 2 * M

    Grid = nx.grid_2d_graph(X, Y, periodic=False, create_using=None)
    Grid_check = "Squaregrid"

    max_shots = 10**5
    max_errors = 100

    # Choose error rates
    error_rates = list(np.logspace(-2, -1.25, 4))
    # ratio_T1toT2  = 3.26
    ratio_T1toidlehalf = 0.0017
    ratio_T1toshuttlinghalf = 0.004

    # Decide the number of rounds.
    Distance_check = True  # If True, we choose the number of rounds.
    rounds = 2

    decoding_kwargs = dict(
        with_BP_LSD=True, max_iter=30, bp_method="ms", lsd_method="lsd_cs", lsd_order=0
    )

    # Produce starting coordinates fast.
    initial_coordinates = SC.StartingCoordinates(L, M, polyA, polyB, Grid, X, Y)
    initial_coordinates.get_folded_Tanner_layout()
    initial_coordinates.set_starting_coordinates("Tanner")
    starting_coord_type = "Tanner"

    # Tanner_layout_init = BBcodes.get_qubit_coordinates(
    #     qubit_list_code, qubit_type, L, M
    # )
    # Tanner_layout = cql.translate_dictionary(Tanner_layout_init)

    # Produce optimized starting coordinates.
    # optimized_layout_init, Grid, X1, Y1, _, _, _ = cql.get_optimized_qubit_layout_bipartate(
    #     A, B, L, M
    # )
    # optimized_layout = cql.translate_dictionary(optimized_layout_init)

    memory_experiment = mex.MemoryExperiment(
        Distance_choice=Distance_check,
        rounds=rounds,
        starting_coord=initial_coordinates.starting_coordinates,
        starting_coord_type=starting_coord_type,
        Grid=Grid,
        X=X,
        Y=Y,
        L=L,
        M=M,
        polyA=polyA,
        polyB=polyB,
        Grid_check=Grid_check,
        ratio_T1toidlehalf=ratio_T1toidlehalf,
        ratio_T1toshuttlinghalf=ratio_T1toshuttlinghalf,
    )

    error_rates = list(np.logspace(-2, -1.25, 2))
    dist = memory_experiment.get_distance()
    round_list = [2, dist]
    ratio_dict = {"T2": [0, 3.26], "idling": [0.017], "shuttling": [0.04]}

    memory_experiment.memory_experiment_data_sweep(
        "maximum_matching_efficient",
        round_list,
        error_rates,
        ratio_dict,
        **decoding_kwargs,
    )

#     memory_experiment.get_shuttling_routes("min_weight_matching_efficient")
#     # memory_experiment.get_cmex_circuit_parts(rounds=rounds)

#     memory_experiment.run_cmex(
#         "min_weight_matching_efficient", error_rates=error_rates, rounds=rounds
#     )

#     memory_experiment.get_effective_code_distance(
#         "min_weight_matching", 2, **decoding_kwargs
#     )
#     print(memory_experiment.effective_distances["min_weight_matching"])
#     memory_experiment.save_experiment("experiments_data/bbcode_run_1.json")
#     restored_experiment = mex.MemoryExperiment(
#         load_file="experiments_data/bbcode_run_1.json"
#     )

#     # It immediately has all the compiled distances, logic errors, and collected sinter stats!
#     print(restored_experiment.effective_distances["min_weight_matching"])
# #     # memory_experiment.make_cmex_figure("min_weight_matching",
# #     #                                       error_rates=error_rates,
# #     #                                       rounds=rounds,
# #     #                                       max_shots=max_shots,
# #     #                                       max_errors=max_errors,
# #     #                                       **decoding_kwargs)
