# %%
from clean.utils import (
    create_BB_qubit_list,
    create_Tanner_layout,
    translate_dictionary,
    fold_layout,
    get_optimized_qubit_layout,
    serialize_state,
    deserialize_state,
)
import clean.codes as our_codes
import sympy
import networkx as nx
import random
import matplotlib.pyplot as plt
import os
import json
from sympy.abc import x, y
import numpy as np


class StartingCoordinates(our_codes.BBCodes):
    """
    A class that contains a variety of qubit layouts that can serve as starting coordinates for a circuit. Those that
    are expected to be bad can be used in a variety of cases. The optimized ones are optimized for syndrome extraction circuits.
    This class assumes that the qubits can move on a square grid.
    """

    def __init__(
        self,
        L: int = None,
        M: int = None,
        polyA: sympy.Basic = None,
        polyB: sympy.Basic = None,
        Grid: nx.Graph() = None,
        X: int = None,
        Y: int = None,
        load_file: str = None,
    ):
        if load_file and os.path.exists(load_file):
            self.load_experiment(load_file)
            return

        super().__init__(L, M, polyA, polyB)
        _, _, self.qubit_list_code, _ = create_BB_qubit_list(self.pc_matrix)
        self.Grid = Grid
        self.X = X
        self.Y = Y
        self.qubit_layouts = {
            "Tanner": {},
            "folded Tanner": {},
            "optimized": {},
            "quadrants": {},
        }  # All qubit_layouts have qubit_list_circuit as their keys and are translated via translate_dictionary.
        self.optimized_layout_data = None
        self.starting_coordinates = {}

    def set_starting_coordinates(self, strategy):
        self.starting_coordinates = self.qubit_layouts[strategy]
        return

    def get_a_Tanner_layout(self):
        qubit_layout = create_Tanner_layout(self.qubit_list_code, self.L, self.M)
        self.qubit_layouts["Tanner"] = translate_dictionary(qubit_layout)

        return self.qubit_layouts["Tanner"]

    def get_folded_Tanner_layout(self):
        """
        Places qubits from a qubit_list on an X x Y square grid based on the following principle:
        We place qubits in spaces of 2, leaving intermediate spaces for the second half of qubits in the list
        (because in the list, the data qubits come first, the ancilla come after).
        We then 'fold' and 'expand' the layout according to the paper arXiv:2404.18809.
        """

        if len(self.qubit_layouts["Tanner"]) == 0:
            self.get_a_Tanner_layout()

        self.qubit_layouts["folded Tanner"] = fold_layout(
            self.qubit_layouts["Tanner"], self.L, self.M
        )

        return self.qubit_layouts["folded Tanner"]

    def get_optimal_qubit_layout(self):
        """
        Produces a qubit layout that aims to minimize the largest distance interaction in the syndrome extraction circuit.
        The method used is the one given in arXiv:2404.18809v2.
        """
        (
            qubit_layout,
            Grid_optimal,
            ord1_optimal,
            ord2_optimal,
            vec1_optimal,
            vec2_optimal,
            transition_vector_optimal,
        ) = get_optimized_qubit_layout(
            self.A,
            self.B,
            self.L,
            self.M,
            self.check_qubit_list,
            self.qubit_list_code,
            self.neighbours,
        )
        self.qubit_layouts["optimized"] = translate_dictionary(qubit_layout)
        self.optimized_layout_data = (
            Grid_optimal,
            ord1_optimal,
            ord2_optimal,
            vec1_optimal,
            vec2_optimal,
            transition_vector_optimal,
        )

        return self.qubit_layouts["optimized"]

    def get_quadrant_qubit_layout(self):
        """
        Produces a qubit layout that places the L, R, X, Z qubits in separate quadrants of an X x Y square grid.
        The purpose of this layout is to get non-optimal largest interaction distances in the syndrome extraction circuit.
        """

        qubit_layout = {}

        for qubit in self.qubit_list_code:
            if qubit[0] < self.L * self.M:  # Placing L qubits.
                qubit_layout[qubit] = ((qubit[0] // self.M) % self.L, qubit[0] % self.M)
            if (
                self.L * self.M <= qubit[0] and qubit[0] < 2 * self.L * self.M
            ):  # Placing R qubits.
                qubit_layout[qubit] = (
                    (qubit[0] // self.M) % self.L,
                    qubit[0] % self.M + self.M,
                )
            if (
                2 * self.L * self.M <= qubit[0] and qubit[0] < 3 * self.L * self.M
            ):  # Placing X qubits.
                qubit_layout[qubit] = (
                    (qubit[0] // self.M) % self.L + self.L,
                    qubit[0] % self.M,
                )
            if 3 * self.L * self.M <= qubit[0]:  # Placing Z qubits.
                qubit_layout[qubit] = (
                    (qubit[0] // self.M) % self.L + self.L,
                    qubit[0] % self.M + self.M,
                )

        self.qubit_layouts["quadrants"] = translate_dictionary(qubit_layout)
        return self.qubit_layouts["quadrants"]

    def get_random_qubit_layout(self, n):
        """
        Produces a qubit layout that randomly places the qubits in qubit_list_code on an X x Y square grid.
        """

        qubit_layout = {}
        # coordinates = []
        indices = []
        for i in range(self.X * self.Y):
            indices.append(i)
            # coordinates.append((i % self.Y, (i//self.Y) % self.X ))
        random.shuffle(indices)

        for qubit in self.qubit_list_code:
            qubit_layout[qubit] = (
                (indices[qubit[0]] // self.Y) % self.X,
                indices[qubit[0]] % self.Y,
            )

        self.qubit_layouts[f"random{n}"] = translate_dictionary(qubit_layout)
        return self.qubit_layouts[f"random{n}"]

    def draw_layout(self, strategy: str):
        """
        Draws the qubit layout of a given strategy.
        """
        fig = plt.figure(figsize=(12, 12))
        ax = fig.add_subplot(111)

        X_coord = []
        Y_coord = []
        for qubit in self.qubit_layouts[strategy].keys():
            coords = self.qubit_layouts[strategy][qubit]
            X_coord.append(coords[0])
            Y_coord.append(coords[1])
            ax.annotate(
                f'{getattr(qubit, "value", qubit)}',
                xy=(coords[0], coords[1]),
                xytext=(5, 5),
                textcoords="offset points",
            )

        # Plot data
        ax.scatter(X_coord, Y_coord, color="red", label="Coordinates")

        ax.grid()
        plt.show()

    def save_experiment(self, filepath: str):
        """Saves the current instance state to a JSON file."""
        print("saving")
        state = {k: v for k, v in self.__dict__.items() if not k.startswith("__")}

        serialized_state = serialize_state(state)

        os.makedirs(os.path.dirname(os.path.abspath(filepath)) or ".", exist_ok=True)
        with open(filepath, "w") as f:
            json.dump(serialized_state, f, indent=4)
        print(f"Experiment data saved in: {filepath}")

    def load_experiment(self, filepath: str):
        """Loads and reconstructs the instance from a JSON file."""
        print("loading")
        with open(filepath, "r") as f:
            serialized_state = json.load(f)

        state = deserialize_state(serialized_state)

        for k, v in state.items():
            setattr(self, k, v)


if __name__ == "__main__":
    # Initiate BB-code
    polyA = x**3 + y + y**2
    polyB = y**3 + x + x**2

    L = 12
    M = 6
    X = 2 * L
    Y = 2 * M

    Grid = nx.grid_2d_graph(X, Y, periodic=False, create_using=None)
    Grid_check = "Squaregrid"

    max_shots = 10**5
    max_errors = 100

    # Choose error rates
    error_rates = list(np.logspace(-3.75, -3, 4))
    p_base = 0.1
    ratio_T1toT2 = 0
    # ratio_T1toT2  = 3.26
    ratio_T1toidlehalf = 0.0017
    ratio_T1toshuttlinghalf = 0.004

    # Decide the number of rounds.
    Distance_check = True  # If True, we choose the number of rounds.
    rounds = 2

    decoding_kwargs = dict(
        with_BP_LSD=True, max_iter=30, bp_method="ms", lsd_method="lsd_cs", lsd_order=0
    )

    initial_qubit_layout = StartingCoordinates(L, M, polyA, polyB, Grid, X, Y)

    # initial_qubit_layout.get_a_Tanner_layout()
    # print(initial_qubit_layout.qubit_layouts["Tanner"])

    # initial_qubit_layout.get_folded_Tanner_layout()
    # print(initial_qubit_layout.qubit_layouts["folded Tanner"])

    initial_qubit_layout.get_optimal_qubit_layout()
    print(initial_qubit_layout.qubit_layouts["optimized"])

    # initial_qubit_layout.get_quadrant_qubit_layout()
    # print(initial_qubit_layout.qubit_layouts["quadrants"])

    # initial_qubit_layout.get_random_qubit_layout(1)
    # print(initial_qubit_layout.qubit_layouts["random1"])
