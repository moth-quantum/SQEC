import stim
import networkx as nx
from clean.utils import (
    create_BB_qubit_list,
    get_qubit_coordinates,
    transpose_list,
    build_matrix_list,
    get_parity_check_matrix,
    get_dimension,
    remove_noise_from_circuit,
)
from qldpc import circuits, codes
from sympy.abc import x, y
import sympy


class BBCodes:
    def __init__(self, L: int, M: int, polyA: sympy.Basic, polyB: sympy.Basic):
        self.L = L
        self.M = M
        self.polyA = polyA
        self.polyB = polyB
        self.A = build_matrix_list(L, M, polyA)
        self.B = build_matrix_list(L, M, polyB)
        self.pc_matrix = get_parity_check_matrix(self.A, self.B)
        (
            data_qubit_list,
            check_qubit_list,
            qubit_list,
            qubit_type,
        ) = create_BB_qubit_list(self.pc_matrix)
        self.data_qubit_list = data_qubit_list
        self.check_qubit_list = check_qubit_list
        self.qubit_list = qubit_list
        self.qubit_type = qubit_type
        self.neighbours = self.get_neighbours()
        self.Tanner_graph = nx.Graph()
        self.layout = get_qubit_coordinates(self.qubit_list, self.qubit_type, L, M)
        self.qec_cycles = {}
        self.distance = self.get_distance()
        self.cmex_circuit_parts = {}  # Keys of this dictionary are the numbers of rounds of the syndrome extraction.
        self.dimension = get_dimension(self.A, self.B)

    def get_distance(self):
        code = codes.BBCode(
            {x: self.L, y: self.M},
            self.polyA,
            self.polyB,
        )
        distance_trials = 100
        self.distance = code.get_distance(bound=distance_trials)

        return self.distance

    def get_label(self):
        n = len(self.pc_matrix[0])
        k = self.dimension
        d = self.distance
        return f"[{n}, {k}, d <= {d}]"

    def get_neighbours(self):
        """
        Takes the BB code and returns a dictionary 'neighbours' that associates to every
        qubit q a dictionary that provides the A1, A2, A3, B1, B2, B3 neighbours of q.
        """

        A_t = transpose_list(self.A)
        B_t = transpose_list(self.B)
        neighbours = {}
        for data_qubit in self.data_qubit_list:
            neighbours[data_qubit] = {}
        for check_qubit in self.check_qubit_list:
            neighbours[check_qubit] = {}
        for data_qubit in self.data_qubit_list:
            if (
                self.qubit_type[data_qubit] == "L"
            ):  # For L-qubits, the A-matrices indicate the X-checks and the B-matrices indicate the Z-checks
                for check_qubit in self.check_qubit_list:
                    if check_qubit[0] < len(self.data_qubit_list) + len(self.A[0]):
                        if (
                            self.A[0][check_qubit[0] - len(self.data_qubit_list)][
                                data_qubit[0] % len(self.A[0])
                            ]
                            == 1
                        ):
                            neighbours[data_qubit]["A1"] = check_qubit
                            neighbours[check_qubit]["A1"] = data_qubit
                        if (
                            self.A[1][check_qubit[0] - len(self.data_qubit_list)][
                                data_qubit[0] % len(self.A[0])
                            ]
                            == 1
                        ):
                            neighbours[data_qubit]["A2"] = check_qubit
                            neighbours[check_qubit]["A2"] = data_qubit
                        if (
                            self.A[2][check_qubit[0] - len(self.data_qubit_list)][
                                data_qubit[0] % len(self.A[0])
                            ]
                            == 1
                        ):
                            neighbours[data_qubit]["A3"] = check_qubit
                            neighbours[check_qubit]["A3"] = data_qubit
                    if check_qubit[0] >= len(self.data_qubit_list) + len(self.A[0]):
                        if (
                            B_t[0][
                                check_qubit[0]
                                - len(self.data_qubit_list)
                                - len(self.A[0])
                            ][data_qubit[0] % len(self.A[0])]
                            == 1
                        ):
                            neighbours[data_qubit]["B1"] = check_qubit
                            neighbours[check_qubit]["B1"] = data_qubit
                        if (
                            B_t[1][
                                check_qubit[0]
                                - len(self.data_qubit_list)
                                - len(self.A[0])
                            ][data_qubit[0] % len(self.A[0])]
                            == 1
                        ):
                            neighbours[data_qubit]["B2"] = check_qubit
                            neighbours[check_qubit]["B2"] = data_qubit
                        if (
                            B_t[2][
                                check_qubit[0]
                                - len(self.data_qubit_list)
                                - len(self.A[0])
                            ][data_qubit[0] % len(self.A[0])]
                            == 1
                        ):
                            neighbours[data_qubit]["B3"] = check_qubit
                            neighbours[check_qubit]["B3"] = data_qubit

            if (
                self.qubit_type[data_qubit] == "R"
            ):  # For R-qubits, the A-matrices indicate the Z-checks and the B-matrices indicate the X-checks
                for check_qubit in self.check_qubit_list:
                    if check_qubit[0] >= len(self.data_qubit_list) + len(self.A[0]):
                        if (
                            A_t[0][
                                check_qubit[0]
                                - len(self.data_qubit_list)
                                - len(self.A[0])
                            ][data_qubit[0] % len(self.A[0])]
                            == 1
                        ):
                            neighbours[data_qubit]["A1"] = check_qubit
                            neighbours[check_qubit]["A1"] = data_qubit
                        if (
                            A_t[1][
                                check_qubit[0]
                                - len(self.data_qubit_list)
                                - len(self.A[0])
                            ][data_qubit[0] % len(self.A[0])]
                            == 1
                        ):
                            neighbours[data_qubit]["A2"] = check_qubit
                            neighbours[check_qubit]["A2"] = data_qubit
                        if (
                            A_t[2][
                                check_qubit[0]
                                - len(self.data_qubit_list)
                                - len(self.A[0])
                            ][data_qubit[0] % len(self.A[0])]
                            == 1
                        ):
                            neighbours[data_qubit]["A3"] = check_qubit
                            neighbours[check_qubit]["A3"] = data_qubit
                    if check_qubit[0] < len(self.data_qubit_list) + len(self.A[0]):
                        if (
                            self.B[0][check_qubit[0] - len(self.data_qubit_list)][
                                data_qubit[0] % len(self.A[0])
                            ]
                            == 1
                        ):
                            neighbours[data_qubit]["B1"] = check_qubit
                            neighbours[check_qubit]["B1"] = data_qubit
                        if (
                            self.B[1][check_qubit[0] - len(self.data_qubit_list)][
                                data_qubit[0] % len(self.A[0])
                            ]
                            == 1
                        ):
                            neighbours[data_qubit]["B2"] = check_qubit
                            neighbours[check_qubit]["B2"] = data_qubit
                        if (
                            self.B[2][check_qubit[0] - len(self.data_qubit_list)][
                                data_qubit[0] % len(self.A[0])
                            ]
                            == 1
                        ):
                            neighbours[data_qubit]["B3"] = check_qubit
                            neighbours[check_qubit]["B3"] = data_qubit

        return neighbours

    def build_Tanner_graph(self):
        Tanner_graph = nx.Graph()
        for qubit in self.qubit_list:
            Tanner_graph.add_node(qubit)
        for qubit in self.qubit_list:
            for neighbour in self.neighbours[qubit].values():
                Tanner_graph.add_edge(qubit, neighbour)

        self.Tanner_graph = Tanner_graph
        return Tanner_graph

    def get_qec_cycle(self, distance, strategy):
        qec_cycle = stim.Circuit()
        """
        Build the middle part of the syndrome extraction circuit.

        Args:
            A and B are two lists of three matrices each. They indicate the six matrices that go into building the code_matrix of the associated BB-code.

            'strategy' is a sequence of pairs (a,b) where a, b are in 1, 2, 3, 4, 5, 6. The first element of the tuple indicates
            which of their matrices the L-qubits do in this TICK (A1, A2, A3, B1t, B2t, B3t),
            the second element indicates which matrix the R-qubits do in this TICK (B1, B2, B3, A1t, A2t, A3t).

            For the BB codes with the special Tannergraph layout, 1 stands for the identity, 2 stands for x and y respectively,
            while 3 stands for the factor that can vary.

            WARNING: This function inserts ticks assuming that for each tuple in 'strategy', we task the L-qubits to do one type of check and R-qubits to do the other type.
            Formally, this means that each tuple (a,b) in strategy needs to satisfy a // 3 != b // 3.
        """

        for i in range(distance):  # Number of syndrome extraction rounds we do.
            # Add resets/initializations (per round) here.
            for step in strategy:
                Lcolour, Rcolour = step
                for qubit in self.data_qubit_list:
                    if self.qubit_type[qubit] == "L":
                        if Lcolour < 4:  # These are the X-checks
                            qec_cycle.append(
                                "CX",
                                [qubit[0], self.neighbours[qubit][f"A{Lcolour}"][0]],
                            )
                        elif Lcolour > 3:  # These are the Z-checks
                            qec_cycle.append(
                                "CX",
                                [
                                    self.neighbours[qubit][f"B{Lcolour - 3}"][0],
                                    qubit[0],
                                ],
                            )
                    if self.qubit_type[qubit] == "R":
                        if Rcolour < 4:  # These are the X-checks
                            qec_cycle.append(
                                "CX",
                                [qubit[0], self.neighbours[qubit][f"B{Rcolour}"][0]],
                            )
                        if Rcolour > 3:  # These are the Z-checks
                            qec_cycle.append(
                                "CX",
                                [
                                    self.neighbours[qubit][f"A{Rcolour - 3}"][0],
                                    qubit[0],
                                ],
                            )
                qec_cycle.append("TICK")

            # Add the measurements (per round) here.

        self.qec_cycles[distance, strategy] = qec_cycle
        return qec_cycle

    def get_memory_experiment_circuit(self, Distance_choice: bool, rounds: int):
        """
        Builds the circuit of a memory experiment for a given code. It returns the circuit
        in three parts: initialization, qec_cycle, readout.

        If Distance_choice == False, the number of rounds in the syndrome extractino is equal to the distance.
        If Distance_choice ==True, the number of rounds is determined from the input.
        """
        code = codes.BBCode(
            {x: self.L, y: self.M},
            self.polyA,
            self.polyB,
        )

        if not Distance_choice:
            rounds = self.distance

        # Collect the components of the memory experiment.  In particular, we will need the record
        # of detectors and qubit indices.
        (
            initialization,
            qec_cycle,
            readout,
            measurement_record,
            detector_record,
            qubit_ids,
        ) = circuits.get_memory_experiment_parts(code, basis=None, num_rounds=rounds)

        noise_model = circuits.DepolarizingNoiseModel(0, include_idling_error=False)
        qec_cycle = noise_model.noisy_circuit(qec_cycle)
        clean_circ = remove_noise_from_circuit(qec_cycle)

        self.cmex_circuit_parts[rounds] = (
            initialization,
            clean_circ,
            readout,
            measurement_record,
            detector_record,
            qubit_ids,
        )

        return (
            initialization,
            clean_circ,
            readout,
            measurement_record,
            detector_record,
            qubit_ids,
        )

    # def prepare_input_circuit(self, Distance_choice: bool, rounds: int):
    #     """
    #     Prepares the syndrome extraction circuit of a memory experiment for the given BB-code.
    #     The number of syndrome extraction cycles is determined as follows:
    #         If Distance_choice is True, it is given by rounds.
    #         If Distance_choice is False, it is given by self.distance,
    #         which is an estimate of the theoretical distance of the BB-code.
    #     """

    #     code = codes.BBCode(
    #         {x: self.L, y: self.M},
    #         self.polyA,
    #         self.polyB,
    #     )

    #     if not Distance_choice:
    #         rounds = self.distance()

    #     # Collect the components of the memory experiment.  In particular, we will need the record
    #     # of detectors and qubit indices.
    #     (
    #         _,
    #         qec_cycle,
    #         _,
    #         _,
    #         _,
    #         _,
    #     ) = circuits.get_memory_experiment_parts(code, basis=None, num_rounds=rounds)

    #     noise_model = circuits.DepolarizingNoiseModel(0, include_idling_error=False)

    #     qec_cycle = noise_model.noisy_circuit(qec_cycle)
    #     clean_circ = remove_noise_from_circuit(qec_cycle)

    #     return clean_circ


class Codes:
    def __init__(self, pc_matrix):
        self.matrix = pc_matrix
        self.qubits = []
        self.neighbours = {}
        self.Tanner_graph = nx.Graph()

    def get_qubits(self):
        qubits = []
        data_qubits = []
        check_qubits = []
        for i in range(len(self.matrix[0])):
            data_qubits.append((i, "data"))
        for j in range(len(self.matrix)):
            check_qubits.append((j + len(self.matrix[0]), "check"))
        qubits = data_qubits + check_qubits

        self.data_qubits = data_qubits
        self.check_qubits = check_qubits
        self.qubits = qubits

        return qubits

    def find_neighbours(self):
        """Builds a dictionary that associates to every qubit its set of neighbours."""
        neighbours = {}
        for qubit in self.qubits:
            neighbours[qubit] = set()
        for data_qubit in self.data_qubits:
            for check_qubit in self.check_qubits:
                if self.matrix[check_qubit[0]][data_qubit[0]] == 1:
                    neighbours[data_qubit].add(check_qubit)
                    neighbours[check_qubit].add(data_qubit)

        self.neighbours = neighbours
        return self.neighbours

    def build_Tanner_graph(self):
        Tanner_graph = nx.Graph()
        for qubit in self.qubits:
            Tanner_graph.add_node(qubit)
        for qubit in self.qubits:
            for neighbour in self.neighbours[qubit].values():
                Tanner_graph.add_edge(qubit, neighbour)

        self.Tanner_graph = Tanner_graph
        return Tanner_graph
