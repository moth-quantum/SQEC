import clean.MemoryExperiment as mex
from clean.utils import NoiseConfig
import clean.StartingCoordinates as SC
import os


import networkx as nx
from sympy.abc import x, y
import numpy as np
import Merlin.BB_codes as BBcodes


# Initiate BB-code
polyA = x**3 + y + y**2
polyB = y**3 + x + x**2


L = 12
M = 6
X = 2 * L
Y = 2 * M

A = []
B = []

A.append(BBcodes.create_x_matrix(3, L, M))
A.append(BBcodes.create_y_matrix(1, L, M))
A.append(BBcodes.create_y_matrix(2, L, M))

B.append(BBcodes.create_y_matrix(3, L, M))
B.append(BBcodes.create_x_matrix(1, L, M))
B.append(BBcodes.create_x_matrix(3, L, M))

Grid = nx.grid_2d_graph(X, Y, periodic=False, create_using=None)
Grid_check = "Squaregrid"


max_shots = 10**5
max_errors = 100

# Choose error rates
error_rates = list(np.logspace(-3.75, -3, 4))
p_base = 0.1
ratio_T1toT2 = 0
# ratio_T1toT2  = 3.26
ratio_T1toidlehalf = 0.0017
ratio_T1toshuttlinghalf = 0.004


# Decide the number of rounds.
Distance_check = True  # If True, we choose the number of rounds.
rounds = 12


decoding_kwargs = dict(
    with_BP_LSD=True, max_iter=30, bp_method="ms", lsd_method="lsd_cs", lsd_order=0
)


initial_qubit_layout = SC.StartingCoordinates(L, M, polyA, polyB, Grid, X, Y)

initial_qubit_layout.get_a_Tanner_layout()

Tanner_layout = initial_qubit_layout.qubit_layouts["Tanner"]

load_file = "clean/code_test.json"

print(os.path.exists(load_file))

noise_config = NoiseConfig(
    noise_model="gaussian",
    ratio_T1toidlehalf=ratio_T1toidlehalf,
    ratio_T1toshuttlinghalf=ratio_T1toshuttlinghalf,
    eta_idle=0.5,
    eta_shuttle=100,
    eta_cz=100,
    eta_cnot=0.5,
    ratio_2q=1,
    ratio_meas=2 * 1,
    ratio_reset=2 * 1,
)

memory_experiment = mex.MemoryExperiment(
    Distance_choice=Distance_check,
    rounds=rounds,
    starting_coord=Tanner_layout,
    starting_coord_type="folded Tanner",
    Grid=Grid,
    X=X,
    Y=Y,
    L=L,
    M=M,
    polyA=polyA,
    polyB=polyB,
    Grid_check=Grid_check,
    noise_config=noise_config,
    load_file=load_file,
)


# memory_experiment.run_cmex(strategy="min_weight_matching_efficient", error_rates=error_rates, rounds=rounds, **decoding_kwargs)

print("checkpoint")

memory_experiment.make_cmex_figure(
    strategy="min_weight_matching_efficient",
    error_rates=error_rates,
    rounds=rounds,
    noise_config=noise_config,
)

print("Figure done")

# memory_experiment.get_effective_code_distance(strategy="min_weight_matching_efficient",
#                                              rounds = rounds,
#                                              **decoding_kwargs
#                                              )
