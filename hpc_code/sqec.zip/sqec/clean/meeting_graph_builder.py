import networkx as nx
from clean.utils import Grid_distance, octa_grid_distance


def build_meeting_graph(coord: dict, Grid, travelers: set, Radius, X, Y, Grid_check):
    G_R = nx.Graph()
    G_R.add_nodes_from(travelers, bipartite=0)
    G_R.add_nodes_from(Grid, bipartite=1)

    for traveler in travelers:
        for node in Grid:
            if len(traveler) == 2:  # interacting
                q1, q2 = traveler
                if Grid_check == "Squaregrid":  # Condition if Grid is squaregrid
                    if (
                        Grid_distance(coord[q1], node) <= Radius
                        and Grid_distance(coord[q2], node) <= Radius
                    ):
                        G_R.add_edge(traveler, node)
                elif Grid_check == "Octagrid":  # Condition if Grid is octagrid
                    if (
                        octa_grid_distance(coord[q1], node) <= Radius
                        and octa_grid_distance(coord[q2], node) <= Radius
                    ):
                        G_R.add_edge(traveler, node)
                else:  # Condition if Grid is not a grid with special distance function.
                    if (
                        nx.shortest_path_length(Grid, coord[q1], node) <= Radius
                        and nx.shortest_path_length(Grid, coord[q2], node) <= Radius
                    ):
                        G_R.add_edge(traveler, node)
            else:  # solo
                q1 = traveler[0]
                if Grid_check == "Squaregrid":
                    if Grid_distance(coord[q1], node) <= Radius:
                        G_R.add_edge(traveler, node)
                elif Grid_check == "Octagrid":
                    if octa_grid_distance(coord[q1], node) <= Radius:
                        G_R.add_edge(traveler, node)
                else:
                    if nx.shortest_path_length(Grid, coord[q1], node) <= Radius:
                        G_R.add_edge(traveler, node)
    return G_R


def build_min_weight_meeting_graph(
    coord: dict, Grid, travelers: set, Radius, X: int, Y: int, Grid_check: str
):
    """
    Given a Grid on which qubits can move, coordinates of the qubits, a radius, and pairs of qubits in the set travelers,
    we build a graph as follows:
    The vertices are the pairs of qubits in travelers (some qubits have no partner and appear as a tuple (q,)) and
    the vertices in the Grid. A traveler is connected to a node in the Grid if and only if the coordinates of all qubits
    in the traveler have distance at most Radius to the node in the Grid. We give each edge the weight of the longest distance
    between a traveler and the node in the Grid.
    """
    G_R = nx.Graph()
    G_R.add_nodes_from(travelers, bipartite=0)
    G_R.add_nodes_from(Grid, bipartite=1)

    for traveler in travelers:
        for node in Grid:
            if len(traveler) == 2:  # interacting
                q1, q2 = traveler
                if Grid_check == "Squaregrid":  # Condition if Grid is squaregrid
                    if (
                        Grid_distance(coord[q1], node) <= Radius
                        and Grid_distance(coord[q2], node) <= Radius
                    ):
                        G_R.add_edge(
                            traveler,
                            node,
                            weight=(
                                Grid_distance(coord[q1], node)
                                + Grid_distance(coord[q2], node)
                            ),
                        )
                elif Grid_check == "Octagrid":  # Condition if Grid is octagrid
                    if (
                        octa_grid_distance(coord[q1], node) <= Radius
                        and octa_grid_distance(coord[q2], node) <= Radius
                    ):
                        G_R.add_edge(
                            traveler,
                            node,
                            weight=(
                                octa_grid_distance(coord[q1], node)
                                + octa_grid_distance(coord[q2], node)
                            ),
                        )
                else:  # Condition if Grid is not a grid with special distance function.
                    if (
                        nx.shortest_path_length(Grid, coord[q1], node) <= Radius
                        and nx.shortest_path_length(Grid, coord[q2], node) <= Radius
                    ):
                        G_R.add_edge(
                            traveler,
                            node,
                            weight=(
                                nx.shortest_path_length(Grid, coord[q1], node)
                                + nx.shortest_path_length(Grid, coord[q2], node)
                            ),
                        )
            else:  # solo
                q1 = traveler[0]
                if Grid_check == "Squaregrid":  # Condition if Grid is squaregrid
                    if Grid_distance(coord[q1], node) <= Radius:
                        G_R.add_edge(
                            traveler, node, weight=Grid_distance(coord[q1], node)
                        )
                elif Grid_check == "Octagrid":  # Condition if Grid is octagrid
                    if octa_grid_distance(coord[q1], node) <= Radius:
                        G_R.add_edge(
                            traveler, node, weight=octa_grid_distance(coord[q1], node)
                        )
                else:  # Condition if Grid is not a grid with special distance function.
                    if nx.shortest_path_length(Grid, coord[q1], node) <= Radius:
                        G_R.add_edge(
                            traveler,
                            node,
                            weight=nx.shortest_path_length(Grid, coord[q1], node),
                        )

    return G_R


def expand_meeting_graph(
    coord: dict, Grid, travelers: set, Radius, X, Y, Grid_check, G_small
):
    G_R = G_small

    for traveler in travelers:
        for node in Grid:
            if (traveler, node) not in G_R.edges:
                if len(traveler) == 2:  # interacting
                    q1, q2 = traveler
                    if Grid_check == "Squaregrid":  # Condition if Grid is squaregrid
                        if (
                            Grid_distance(coord[q1], node) <= Radius
                            and Grid_distance(coord[q2], node) <= Radius
                        ):
                            G_R.add_edge(traveler, node)
                    elif Grid_check == "Octagrid":  # Condition if Grid is octagrid
                        if (
                            octa_grid_distance(coord[q1], node) <= Radius
                            and octa_grid_distance(coord[q2], node) <= Radius
                        ):
                            G_R.add_edge(traveler, node)
                    else:  # Condition if Grid is not a grid with special distance function.
                        if (
                            nx.shortest_path_length(Grid, coord[q1], node) <= Radius
                            and nx.shortest_path_length(Grid, coord[q2], node) <= Radius
                        ):
                            G_R.add_edge(traveler, node)
                else:  # solo
                    q1 = traveler[0]
                    if Grid_check == "Squaregrid":  # Condition if Grid is squaregrid
                        if Grid_distance(coord[q1], node) <= Radius:
                            G_R.add_edge(traveler, node)
                    elif Grid_check == "Octagrid":  # Condition if Grid is octagrid
                        if octa_grid_distance(coord[q1], node) <= Radius:
                            G_R.add_edge(traveler, node)
                    else:  # Condition if Grid is not a grid with special distance function.
                        if nx.shortest_path_length(Grid, coord[q1], node) <= Radius:
                            G_R.add_edge(traveler, node)
    return G_R


def expand_min_weight_meeting_graph(
    coord: dict,
    Grid,
    travelers: set,
    Radius: int,
    X: int,
    Y: int,
    Grid_check: str,
    G_small,
):
    G_R = G_small

    for traveler in travelers:
        for node in Grid:
            if (traveler, node) not in G_R.edges:
                if len(traveler) == 2:  # interacting
                    q1, q2 = traveler
                    if Grid_check == "Squaregrid":  # Condition if Grid is squaregrid
                        if (
                            Grid_distance(coord[q1], node) <= Radius
                            and Grid_distance(coord[q2], node) <= Radius
                        ):
                            G_R.add_edge(
                                traveler,
                                node,
                                weight=(
                                    Grid_distance(coord[q1], node)
                                    + Grid_distance(coord[q2], node)
                                ),
                            )
                    elif Grid_check == "Octagrid":  # Condition if Grid is octagrid
                        if (
                            octa_grid_distance(coord[q1], node) <= Radius
                            and octa_grid_distance(coord[q2], node) <= Radius
                        ):
                            G_R.add_edge(
                                traveler,
                                node,
                                weight=(
                                    octa_grid_distance(coord[q1], node)
                                    + octa_grid_distance(coord[q2], node)
                                ),
                            )
                    else:  # Condition if Grid is not a grid with special distance function.
                        if (
                            nx.shortest_path_length(Grid, coord[q1], node) <= Radius
                            and nx.shortest_path_length(Grid, coord[q2], node) <= Radius
                        ):
                            G_R.add_edge(
                                traveler,
                                node,
                                weight=(
                                    nx.shortest_path_length(Grid, coord[q1], node)
                                    + nx.shortest_path_length(Grid, coord[q2], node)
                                ),
                            )
                else:  # solo
                    q1 = traveler[0]
                    if Grid_check == "Squaregrid":  # Condition if Grid is squaregrid
                        if Grid_distance(coord[q1], node) <= Radius:
                            G_R.add_edge(
                                traveler, node, weight=Grid_distance(coord[q1], node)
                            )
                    elif Grid_check == "Octagrid":  # Condition if Grid is octagrid
                        if octa_grid_distance(coord[q1], node) <= Radius:
                            G_R.add_edge(
                                traveler,
                                node,
                                weight=octa_grid_distance(coord[q1], node),
                            )
                    else:  # Condition if Grid is not a grid with special distance function.
                        if nx.shortest_path_length(Grid, coord[q1], node) <= Radius:
                            G_R.add_edge(
                                traveler,
                                node,
                                weight=nx.shortest_path_length(Grid, coord[q1], node),
                            )

    return G_R
