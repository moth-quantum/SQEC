# %%
import os
import json
import pandas as pd
from utils import deserialize_state


def experiments_to_dataframe(
    folder_path: str, output_filename: str = "compiled_results.csv"
) -> pd.DataFrame:
    """
    Reads JSON experiment files in a directory and compiles them into a Pandas DataFrame.
    If a compiled database already exists, it loads it and ONLY processes newly added JSON files.
    """
    output_filepath = os.path.join(folder_path, output_filename)

    existing_df = None
    processed_experiments = set()

    if os.path.exists(output_filepath):
        existing_df = pd.read_csv(output_filepath)
        if "experiment_id" in existing_df.columns:
            processed_experiments = set(existing_df["experiment_id"].unique())
        print(
            f"Loaded existing database with {len(processed_experiments)} experiments."
        )

    rows = []
    new_files_count = 0

    for filename in os.listdir(folder_path):
        if not filename.endswith(".json"):
            continue

        exp_id = filename.replace(".json", "")
        if exp_id in processed_experiments:
            continue

        new_files_count += 1
        filepath = os.path.join(folder_path, filename)

        with open(filepath, "r") as f:
            serialized_state = json.load(f)
        state = deserialize_state(serialized_state)

        initial_layout = state.get("starting_coord_type", "unknown")
        L = state.get("L")
        M = state.get("M")
        X = state.get("X")
        Y = state.get("Y")
        distance = state.get("distance")

        collected_stats = state.get("collected_stats", {})

        for strategy, strategy_data in collected_stats.items():
            for rounds, rounds_data in strategy_data.items():
                for config_key, probs_data in rounds_data.items():
                    try:
                        config_dict = json.loads(config_key)
                    except (json.JSONDecodeError, TypeError):
                        print(f"Might be loading a bad json {filename}: {config_key}")
                        continue

                    noise_model_str = config_dict.get("noise_model", "linear")
                    t_2q = config_dict.get("t_2q", 1.0)
                    t_meas = config_dict.get("t_meas", 1.0)
                    t_1q = config_dict.get("t_1q", 0.1)
                    ratio_2q = config_dict.get("ratio_2q", 10.0)

                    eta_idle = config_dict.get("eta_idle", 0.5)
                    eta_shuttle = config_dict.get("eta_shuttle", 0.5)
                    eta_cz = config_dict.get("eta_cz", 0.5)
                    eta_cnot = config_dict.get("eta_cnot", 0.5)

                    shuttle_bias_dir = config_dict.get("shuttle_bias_dir", "Z")
                    gate_bias_dir = config_dict.get("gate_bias_dir", "Z")

                    ratio_meas = config_dict.get("ratio_meas", 20.0)
                    ratio_reset = config_dict.get("ratio_reset", 20.0)

                    ratio_idling = config_dict.get("ratio_T1toidlehalf", 0.0017)
                    ratio_shuttling = config_dict.get("ratio_T1toshuttlinghalf", 0.004)

                    for prob, stat in probs_data.items():
                        valid_shots = stat.shots - stat.discards
                        logical_error_rate = (
                            stat.errors / valid_shots if valid_shots > 0 else 0.0
                        )

                        rows.append(
                            {
                                "experiment_id": exp_id,
                                "Initial Layout": initial_layout,
                                "L": L,
                                "M": M,
                                "X": X,
                                "Y": Y,
                                "Code Distance": distance,
                                "Strategy": strategy,
                                "Rounds": rounds,
                                # Error Rates and Ratios
                                "Physical Error Rate": prob,
                                "Logical Error Rate": logical_error_rate,
                                "2 Qubit Gate Error": ratio_2q,
                                "Idling Error Ratio": ratio_idling,
                                "Shuttling Error Ratio": ratio_shuttling,
                                "Measurement Error Ratio": ratio_meas,
                                "Reset Error Ratio": ratio_reset,
                                # Noise Model Settings
                                "Noise Model": noise_model_str,
                                "t_2q": t_2q,
                                "t_meas": t_meas,
                                "t_1q": t_1q,
                                "Eta Idling": eta_idle,
                                "Eta Shuttling": eta_shuttle,
                                "Eta CZ": eta_cz,
                                "Eta CNOT": eta_cnot,
                                "Shuttle Bias Dir": shuttle_bias_dir,
                                "Gate Bias Dir": gate_bias_dir,
                                # Sinter Stats
                                "errors": stat.errors,
                                "shots": stat.shots,
                                "discards": stat.discards,
                            }
                        )

    new_df = pd.DataFrame(rows)

    if existing_df is not None:
        if not new_df.empty:
            final_df = pd.concat([existing_df, new_df], ignore_index=True)
            print(f"Added {new_files_count} new experiments.")
        else:
            final_df = existing_df
            print("No new experiments found. Returning existing database.")
    else:
        final_df = new_df
        print(f"Created new database with {new_files_count} experiments.")

    if not final_df.empty and new_files_count:
        final_df = final_df.sort_values(
            by=["experiment_id", "Strategy", "Physical Error Rate"]
        )
        final_df.to_csv(output_filepath, index=False)
        print(f"Data saved to {output_filepath}")

    return final_df


if __name__ == "__main__":
    import matplotlib.pyplot as plt
    import seaborn as sns

    df = experiments_to_dataframe(".")

    sns.set_theme(style="whitegrid")

    g = sns.relplot(
        data=df,  # [
        #     (df["2 Qubit Gate Error"] == 0)
        #     & (df["Idling Error Ratio"] == 0.0017)
        #     & (df["Noise Model"].isin(["linear", "gaussian"]))
        # ],
        kind="line",
        x="Physical Error Rate",
        y="Logical Error Rate",
        hue="Noise Model",  # Perfect for comparing 'linear' vs 'gaussian'
        style="2 Qubit Gate Error",  # Can now easily distinguish bias vs no bias
        col="Rounds",
        markers=True,
        dashes=True,
        linewidth=2,
        markersize=8,
        height=5,
        aspect=1.2,
    )

    g.set(xscale="log", yscale="log")

    min_p = df["Physical Error Rate"].min()
    max_p = df["Physical Error Rate"].max()

    for ax in g.axes.flat:
        ax.plot(
            [min_p, max_p],
            [min_p, max_p],
            "k:",
            alpha=0.7,
            label="$p_{log} = p_{phys}$",
        )
        ax.grid(True, which="both", ls="-", alpha=0.5)

    g.set_axis_labels("Physical Error Rate ($p_{base}$)", "Logical Error Rate")
    plt.legend(bbox_to_anchor=(1.05, 0.9), loc="upper left")
    plt.tight_layout()
    plt.show()

# %%
