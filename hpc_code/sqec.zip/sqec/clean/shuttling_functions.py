import networkx as nx
import math
from utils import MEASUREMENT_GATES, RESET_GATES, TWO_QUBIT_GATES, SINGLE_QUBIT_GATES


def create_shuttling_errors(
    qubit_list,
    coord,
    meeting_points,
    Grid,
    p_base,
    ratio_T1toidlehalf: float = 0.0017,
    ratio_T1toshuttlinghalf: float = 0.004,
    noise_model: str = "linear",
    eta_idle: float = 100.0,
    eta_shuttle: float = 100.0,
    shuttle_bias_dir: str = "Z",
    gate_types: dict = None,
    t_2q: float = 1.0,
    t_meas: float = 1.0,
    t_1q: float = 0.1,
    ratio_2q: float = 10.0,
    ratio_meas: float = 20.0,
    ratio_reset: float = 20.0,
    precomputed_distances: dict = None,  # NEW PARAMETER
):
    if gate_types is None:
        gate_types = {}

    shuttling_data = {}

    # Bypass nx.shortest_path_length if distances are already cached
    if precomputed_distances is not None:
        shuttling_distance = precomputed_distances
    else:
        shuttling_distance = {}
        for qubit in qubit_list:
            shuttling_distance[qubit] = nx.shortest_path_length(
                Grid, coord[qubit], meeting_points[qubit]
            )

    idling_time = {}
    tick_shuttle_time = max(shuttling_distance.values()) if shuttling_distance else 0

    gate_names = set(gate_types.values())
    if any(g in TWO_QUBIT_GATES for g in gate_names):
        tick_gate_time = t_2q
    elif any(g in MEASUREMENT_GATES or g in RESET_GATES for g in gate_names):
        tick_gate_time = t_meas
    elif any(g in SINGLE_QUBIT_GATES and g != "I" for g in gate_names):
        tick_gate_time = t_1q
    else:
        tick_gate_time = t_1q

    active_qubits = set()
    for qubits, gate in gate_types.items():
        if gate != "I":
            if isinstance(qubits, tuple):
                for q in qubits:
                    if q != "solo":
                        active_qubits.add(q)
            else:
                active_qubits.add(qubits)

    for qubit in qubit_list:
        base_idle = tick_shuttle_time - shuttling_distance[qubit]

        if qubit not in active_qubits:
            idling_time[qubit] = base_idle + tick_gate_time
        else:
            idling_time[qubit] = base_idle

        shuttling_tuple = apply_decay_and_bias(
            p_total_ref=p_base * ratio_T1toshuttlinghalf * 2,
            t=shuttling_distance[qubit],
            t_ref=1.0,
            eta=eta_shuttle,
            bias_dir=shuttle_bias_dir,
            model=noise_model,
        )

        idling_tuple = apply_decay_and_bias(
            p_total_ref=p_base * ratio_T1toidlehalf * 2,
            t=idling_time[qubit],
            t_ref=1.0,
            eta=eta_idle,
            bias_dir="Z",
            model=noise_model,
        )

        combined_tuple = (
            1 - (1 - shuttling_tuple[0]) * (1 - idling_tuple[0]),
            1 - (1 - shuttling_tuple[1]) * (1 - idling_tuple[1]),
            1 - (1 - shuttling_tuple[2]) * (1 - idling_tuple[2]),
        )

        shuttling_data[qubit] = {
            "combined_1q_probs": combined_tuple,
            "p_2q": ratio_2q * p_base,
            "p_measure": ratio_meas * p_base,
            "p_reset": ratio_reset * p_base,
        }

    return shuttling_data


def generate_biased_2q_probs(p_2q: float, eta: float, bias_dir: str = "Z"):
    """
    Generates the 15-term Pauli channel array for a biased 2-qubit gate.
    Constructed via the tensor product of two identical 1Q biased channels.
    """
    e_1q = 1.0 - math.sqrt(max(0.0, 1.0 - p_2q))

    p_perp = e_1q / (2 * (1 + eta))
    p_dom = e_1q * (eta / (1 + eta))

    if bias_dir == "Z":
        P_1q = [1.0 - e_1q, p_perp, p_perp, p_dom]  # I, X, Y, Z
    elif bias_dir == "X":
        P_1q = [1.0 - e_1q, p_dom, p_perp, p_perp]  # I, X, Y, Z
    else:  # Y-bias
        P_1q = [1.0 - e_1q, p_perp, p_dom, p_perp]  # I, X, Y, Z

    probs = []
    for i in range(4):
        for j in range(4):
            if i == 0 and j == 0:
                continue
            probs.append(P_1q[i] * P_1q[j])

    return probs


def create_paired_shuttling_errors(
    shuttling_data,
    travelers,
    gate_types,
    p_base,
    eta_cz=0.5,
    eta_cnot=0.5,
    gate_bias_dir="Z",
):
    paired_shuttling_error = {}

    def format_1q_noise(p_tuple, q):
        if math.isclose(p_tuple[0], p_tuple[1], abs_tol=1e-12) and math.isclose(
            p_tuple[1], p_tuple[2], abs_tol=1e-12
        ):
            return ("DEPOLARIZE1", sum(p_tuple), (q,))
        return ("PAULI_CHANNEL_1", p_tuple, (q,))

    for pair in travelers:
        noise_before = []
        noise_after = []

        if len(pair) == 2:
            q0, q1 = pair[0], pair[1]

            if not (q0.is_qubit_target and q1.is_qubit_target):  # just a safety check
                continue

            gate = gate_types.get(pair, "CX")

            p_tuple_q0 = shuttling_data[q0]["combined_1q_probs"]
            p_tuple_q1 = shuttling_data[q1]["combined_1q_probs"]

            # Single qubit (idling + shuttling) noise
            noise_before.append(format_1q_noise(p_tuple_q0, q0))
            noise_before.append(format_1q_noise(p_tuple_q1, q1))

            # 2Q Gate noise
            p_2q = shuttling_data[q0]["p_2q"]

            if gate == "CZ":
                if eta_cz == 0.5:
                    noise_after.append(("DEPOLARIZE2", p_2q, pair))
                else:
                    cz_probs = generate_biased_2q_probs(p_2q, eta_cz, gate_bias_dir)
                    noise_after.append(("PAULI_CHANNEL_2", cz_probs, pair))
            else:
                if eta_cnot == 0.5:
                    noise_after.append(("DEPOLARIZE2", p_2q, pair))
                else:
                    cx_probs = generate_biased_2q_probs(p_2q, eta_cnot, gate_bias_dir)
                    noise_after.append(("PAULI_CHANNEL_2", cx_probs, pair))

        else:
            q = pair[0]

            if not q.is_qubit_target:
                continue

            gate = gate_types.get((q, "solo"), "I")

            p_tuple_q = shuttling_data[q]["combined_1q_probs"]

            # BEFORE: Single qubit (Idling + Shuttling) noise
            if gate not in RESET_GATES:
                noise_before.append(format_1q_noise(p_tuple_q, q))

            if gate in MEASUREMENT_GATES:
                noise_before.append(("X_ERROR", shuttling_data[q]["p_measure"], (q,)))
            elif gate in RESET_GATES:
                p_r = shuttling_data[q]["p_reset"]
                noise_after.append(("PAULI_CHANNEL_1", (p_r / 2, 0.0, p_r / 2), (q,)))

        #  dictionary with explicit timing
        paired_shuttling_error[pair] = {"before": noise_before, "after": noise_after}

    return paired_shuttling_error


def apply_decay_and_bias(
    p_total_ref: float, t: float, t_ref: float, eta: float, bias_dir: str, model: str
):
    """Maps a reference total error to exact Pauli tuples using Linear, Exponential, or Gaussian decay."""
    if t <= 0 or p_total_ref <= 0:
        return (0.0, 0.0, 0.0)

    # base discrete rates at reference time
    p_transverse = p_total_ref / (2 * (1 + eta))
    p_dominant = p_total_ref * (eta / (1 + eta))

    if bias_dir == "Z":
        pX_ref, pY_ref, pZ_ref = p_transverse, p_transverse, p_dominant
    elif bias_dir == "X":
        pX_ref, pY_ref, pZ_ref = p_dominant, p_transverse, p_transverse
    else:  # Y-bias
        pX_ref, pY_ref, pZ_ref = p_transverse, p_dominant, p_transverse

    if model == "linear":
        scale = t / t_ref
        return (
            min(1.0, pX_ref * scale),
            min(1.0, pY_ref * scale),
            min(1.0, pZ_ref * scale),
        )

    c_X_ref = max(1e-12, 1.0 - 2.0 * (pY_ref + pZ_ref))
    c_Y_ref = max(1e-12, 1.0 - 2.0 * (pX_ref + pZ_ref))
    c_Z_ref = max(1e-12, 1.0 - 2.0 * (pX_ref + pY_ref))

    scale = (t / t_ref) if model == "exponential" else ((t / t_ref) ** 2)

    c_X_t = math.pow(c_X_ref, scale)
    c_Y_t = math.pow(c_Y_ref, scale)
    c_Z_t = math.pow(c_Z_ref, scale)

    p_X = max(0.0, 0.25 * (1 + c_X_t - c_Y_t - c_Z_t))
    p_Y = max(0.0, 0.25 * (1 - c_X_t + c_Y_t - c_Z_t))
    p_Z = max(0.0, 0.25 * (1 - c_X_t - c_Y_t + c_Z_t))

    return (p_X, p_Y, p_Z)


# def determine_shuttling_routes(ideal_circuit, starting_coord, Grid, X, Y, Grid_check):
#     """
#     Takes a (noiseless) circuit, starting coordinates for all qubits, and the Grid that the qubit can move on
#     and returns a dictionary, that associates to every tick in the ideal circuit a dictionary that
#     associates to every qubit its location after that tick.
#     The shuttling routes are chosen to minimize the largest travel distance. We do not optimize anything else.
#     """
#     ideal_circuit = remove_noise_from_circuit(ideal_circuit)
#     qubit_list = create_qubit_list(ideal_circuit)
#     tick_list = split_at_ticks(ideal_circuit)
#     current_coord = starting_coord

#     shuttling_routes = []  # Dictionary whose keys are numbers from 0 to number of ticks.
#     shuttling_routes.append({})
#     for qubit in qubit_list:
#         shuttling_routes[0][qubit] = current_coord[qubit]

#     for tick in tick_list:
#         if not (
#             ("DETECTOR" in str(tick)) or ("rec" in str(tick)) or ("-" in str(tick))
#         ):
#             pair = find_partner_qubit(tick, qubit_list)
#             meeting_points = get_meeting_points(
#                 current_coord, Grid, pair, X, Y, Grid_check
#             )
#             shuttling_routes_tick = {}
#             for qubit in qubit_list:
#                 shuttling_routes_tick[qubit] = meeting_points[qubit]
#             shuttling_routes.append(shuttling_routes_tick)
#         current_coord = meeting_points

#     return shuttling_routes
