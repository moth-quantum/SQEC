import networkx as nx
from PIL import Image, ImageDraw, ImageFont
import math
from collections.abc import Sequence


from clean.utils import (
    find_partner_qubit,
    pair_to_travelers,
    apply_custom_noise,
    remove_noise_from_circuit,
    split_at_ticks,
    reassemble_circuit,
    TWO_QUBIT_GATES,
    SINGLE_QUBIT_GATES,
    MEASUREMENT_GATES,
    RESET_GATES,
    NoiseConfig,
)
from clean.meeting_graph_builder import (
    build_meeting_graph,
    build_min_weight_meeting_graph,
    expand_meeting_graph,
    expand_min_weight_meeting_graph,
)
from clean.shuttling_functions import (
    create_shuttling_errors,
    create_paired_shuttling_errors,
)


class MeetingGraph:
    def __init__(
        self,
        coord: dict,
        Grid: nx.Graph,
        travelers: set,
        X: int,
        Y: int,
        Grid_check: str,
    ):
        self.coord = coord
        self.Grid = Grid
        self.travelers = travelers
        self.X = X
        self.Y = Y
        self.Grid_check = Grid_check
        self.meeting_graphs = {}
        self.meeting_graph_building_strategies = {
            "maximum_matching": self.max_match_strategy,
            "min_weight_matching": self.minimize_all_travel_distances_strategy,
            "total_shuttling_minimized": self.minimize_all_travel_distances_strategy,
            "maximum_matching_efficient": self.max_match_strategy_new,
            "min_weight_matching_efficient": self.min_weight_strategy_new,
        }
        self.meeting_graph_expanding_strategies = {
            "maximum_matching_efficient": self.max_match_expansion,
            "min_weight_matching_efficient": self.min_weight_expansion,
        }

    def max_match_strategy(self, radius):
        G_R = build_meeting_graph(
            self.coord,
            self.Grid,
            self.travelers,
            radius,
            self.X,
            self.Y,
            self.Grid_check,
        )
        self.meeting_graphs["maximum_matching"] = G_R
        return G_R

    def max_match_strategy_new(self, radius):
        G_R = build_meeting_graph(
            self.coord,
            self.Grid,
            self.travelers,
            radius,
            self.X,
            self.Y,
            self.Grid_check,
        )
        self.meeting_graphs["maximum_matching_efficient"] = G_R
        return G_R

    def minimize_all_travel_distances_strategy(self, radius):
        G_R = build_min_weight_meeting_graph(
            self.coord,
            self.Grid,
            self.travelers,
            radius,
            self.X,
            self.Y,
            self.Grid_check,
        )
        self.meeting_graphs["min_weight_matching"] = G_R
        return G_R

    def min_weight_strategy_new(self, radius):
        G_R = build_min_weight_meeting_graph(
            self.coord,
            self.Grid,
            self.travelers,
            radius,
            self.X,
            self.Y,
            self.Grid_check,
        )
        self.meeting_graphs["min_weight_matching_efficient"] = G_R
        return G_R

    def max_match_expansion(self, radius, G_small):
        G_R = expand_meeting_graph(
            self.coord,
            self.Grid,
            self.travelers,
            radius,
            self.X,
            self.Y,
            self.Grid_check,
            G_small,
        )
        self.meeting_graphs["maximum_matching_efficient"] = G_R
        return G_R

    def min_weight_expansion(self, radius, G_small):
        G_R = expand_min_weight_meeting_graph(
            self.coord,
            self.Grid,
            self.travelers,
            radius,
            self.X,
            self.Y,
            self.Grid_check,
            G_small,
        )
        self.meeting_graphs["min_weight_matching_efficient"] = G_R
        return G_R


class MeetingPoints(MeetingGraph):
    def __init__(
        self,
        coord: dict,
        Grid: nx.Graph,
        travelers: set,
        X: int,
        Y: int,
        Grid_check: str,
    ):
        super().__init__(coord, Grid, travelers, X, Y, Grid_check)
        self.perfect_matching_strategy = {
            "maximum_matching": self.maximum_matching,
            "min_weight_matching": self.min_weight_matching,
            "total_shuttling_minimized": self.total_shuttling_minimized,
            "maximum_matching_efficient": self.maximum_matching_new,
            "min_weight_matching_efficient": self.min_weight_matching_new,
        }
        self.matchings = {}
        self.meeting_points = {}

    def get_meeting_points(self, strategy: str):
        self.meeting_points[strategy] = {}
        for traveler in self.travelers:
            meet_node = self.matchings[strategy]["matching"][traveler]
            for q in traveler:
                self.meeting_points[strategy][q] = meet_node
        return self.meeting_points[strategy]

    def maximum_matching(self):
        """
        Given the current coordinates of all qubits on the grid and their next pairing partner,
        determines meeting points for all qubit(pairs).

        It returns a dictionary whose keys are all qubits and whose values are vertices of Grid.
        Calling this method will define both self_matchings["maximum_matching"] and self.meeting_points["maximum_matching"]
        """
        # remove duplicates, seems like this can cause issues with bipartate maximum matching
        self.matchings["maximum_matching"] = {
            "largest_travel_distance": None,
            "matching": None,
        }
        R = 0
        while True:
            G_R = self.meeting_graph_building_strategies["maximum_matching"](R)

            self.matchings["maximum_matching"][
                "matching"
            ] = nx.bipartite.maximum_matching(G_R, top_nodes=self.travelers)

            if all(
                t in self.matchings["maximum_matching"]["matching"]
                for t in self.travelers
            ):
                self.matchings["maximum_matching"]["largest_travel_distance"] = R
                print(f"Produced a maximal matching for radius {R}.")
                break
            else:
                R += 1
        return self.get_meeting_points("maximum_matching")

    def maximum_matching_new(self):
        """
        Given the current coordinates of all qubits on the grid and their next pairing partner,
        determines meeting points for all qubit(pairs).

        It returns a dictionary whose keys are all qubits and whose values are vertices of Grid.
        Calling this method will define both self_matchings["maximum_matching"] and self.meeting_points["maximum_matching"]
        """
        # remove duplicates, seems like this can cause issues with bipartate maximum matching
        self.matchings["maximum_matching_efficient"] = {
            "largest_travel_distance": None,
            "matching": None,
        }
        R = 0
        G_R = self.meeting_graph_building_strategies["maximum_matching_efficient"](
            R
        )  # Build the first meeting graph.
        while True:
            self.matchings["maximum_matching_efficient"][
                "matching"
            ] = nx.bipartite.maximum_matching(G_R, top_nodes=self.travelers)

            if all(
                t in self.matchings["maximum_matching_efficient"]["matching"]
                for t in self.travelers
            ):
                self.matchings["maximum_matching_efficient"][
                    "largest_travel_distance"
                ] = R
                print(f"Produced a maximal matching for radius {R}.")
                break
            else:
                R += 1
                G_R = self.meeting_graph_expanding_strategies[
                    "maximum_matching_efficient"
                ](R, G_R)  # Add edges to G_R to turn it into the new meeting graph.
        return self.get_meeting_points("maximum_matching_efficient")

    def min_weight_matching(self):
        """
        Given the current coordinates of all qubits on the grid and their next pairing partner,
        determines meeting points for all qubit(pairs). It minimizes the largest travel distance
        and - within that - minimizes the total sum of travel distance by all qubits.

        It returns a dictionary whose keys are all qubits and whose values are vertices of Grid.
        Calling this method will define both self_matchings["min_weight_matching"] and self.meeting_points["min_weight_matching"]
        """
        self.matchings["min_weight_matching"] = {
            "largest_travel_distance": None,
            "matching": None,
        }
        R = 0
        while True:
            G_R = self.meeting_graph_building_strategies["min_weight_matching"](R)
            try:
                # self.matchings["min_weight_matching"][
                #     "matching"
                # ]
                self.matchings["min_weight_matching"][
                    "matching"
                ] = nx.bipartite.minimum_weight_full_matching(
                    G_R, top_nodes=self.travelers, weight="weight"
                )
            except ValueError:
                R += 1
            else:
                # The next three lines could be replaced simply by break, since minimum_weight_full_matching only returns perfect matchings.
                if all(
                    t in self.matchings["min_weight_matching"]["matching"]
                    for t in self.travelers
                ):
                    self.matchings["min_weight_matching"]["largest_travel_distance"] = R
                    print(f"Produced a maximal matching for radius {R}.")
                    break
        return self.get_meeting_points("min_weight_matching")

    def min_weight_matching_new(self):
        """
        Given the current coordinates of all qubits on the grid and their next pairing partner,
        determines meeting points for all qubit(pairs). It minimizes the largest travel distance
        and - within that - minimizes the total sum of travel distance by all qubits.

        It returns a dictionary whose keys are all qubits and whose values are vertices of Grid.
        Calling this method will define both self_matchings["min_weight_matching"] and self.meeting_points["min_weight_matching"]
        """
        self.matchings["min_weight_matching_efficient"] = {
            "largest_travel_distance": None,
            "matching": None,
        }
        R = 0
        G_R = self.meeting_graph_building_strategies["min_weight_matching_efficient"](
            R
        )  # Build the first meeting graph.
        while True:
            try:
                # self.matchings["min_weight_matching"][
                #     "matching"
                # ]
                self.matchings["min_weight_matching_efficient"][
                    "matching"
                ] = nx.bipartite.minimum_weight_full_matching(
                    G_R, top_nodes=self.travelers, weight="weight"
                )
            except ValueError:
                R += 1
                G_R = self.meeting_graph_expanding_strategies[
                    "min_weight_matching_efficient"
                ](R, G_R)  # Add edges to G_R to make it the new meeting graph.
            else:
                # The next three lines could be replaced simply by break, since minimum_weight_full_matching only returns perfect matchings.
                if all(
                    t in self.matchings["min_weight_matching_efficient"]["matching"]
                    for t in self.travelers
                ):
                    self.matchings["min_weight_matching_efficient"][
                        "largest_travel_distance"
                    ] = R
                    print(f"Produced a maximal matching for radius {R}.")
                    break
        return self.get_meeting_points("min_weight_matching_efficient")

    def total_shuttling_minimized(self):
        """
        Given the current coordinates of all qubits on the grid and their next pairing partner,
        determines meeting points for all qubit(pairs). It minimizes the total sum of travel distance by all qubits.

        It returns a dictionary whose keys are all qubits and whose values are vertices of Grid.
        Calling this method will define both self_matchings["total_shuttling_minimized"] and self.meeting_points["total_shuttling_minimized"]
        """
        self.matchings["total_shuttling_minimized"] = {
            "largest_travel_distance": None,
            "matching": None,
        }
        R = nx.diameter(self.Grid)
        G_R = self.meeting_graph_building_strategies["total_shuttling_minimized"](R)

        self.matchings["total_shuttling_minimized"][
            "matching"
        ] = nx.bipartite.minimum_weight_full_matching(
            G_R, top_nodes=self.travelers, weight="weight"
        )

        if not all(
            t in self.matchings["total_shuttling_minimized"]["matching"]
            for t in self.travelers
        ):
            print("Creation of full matching failed.")

        return self.get_meeting_points("total_shuttling_minimized")

    def get_meeting_points_for_strategy(self, strategy: str):
        """Calling this method defines self.matchings and self.meeting_points for the strategy in the input."""
        self.perfect_matching_strategy[strategy]()

        return self.meeting_points[strategy]


# I believe this class has become redundant. It is now fully integrated in the class ShuttlingRoutes.
# class ShuttlingNoise(MeetingPoints):
#     def __init__(
#         self,
#         qubit_list: list,
#         coord: dict,
#         Grid: nx.Graph,
#         travelers: set,
#         X: int,
#         Y: int,
#         Grid_check: str,
#         p_base: float,
#         ratio_T1toidlehalf: float = 0.0017,
#         ratio_T1toshuttlinghalf: float = 0.004,
#     ):
#         super().__init__(coord, Grid, travelers, X, Y, Grid_check)
#         self.qubit_list = qubit_list
#         self.p_base = p_base
#         self.ratioidling = ratio_T1toidlehalf
#         self.ratioshuttling = ratio_T1toshuttlinghalf
#         self.shuttling_data = {}
#         self.noise = {}

#     def get_shuttling_data(self, strategy: str):
#         self.get_meeting_points_for_strategy(strategy)
#         self.shuttling_data = create_shuttling_errors(
#             self.qubit_list,
#             self.coord,
#             self.meeting_points,
#             self.Grid,
#             self.p_base,
#             self.ratioT2,
#             self.ratioidling,
#             self.ratioshuttling,
#         )
#         return self.shuttling_data

#     def get_noise_gates(self):
#         self.noise = create_paired_shuttling_errors(self.shuttling_data, self.travelers)
#         return self.noise


class ShuttlingRoutes:
    def __init__(
        self,
        ideal_circuit,
        qubit_list_code: list,
        qubit_list_circuit: list,
        starting_coord: dict,
        starting_coord_type: str,
        Grid: nx.Graph,
        X: int,
        Y: int,
        Grid_check: str,
        noise_config: NoiseConfig = None,
        BBcheck: bool = False,
    ):
        self.ideal_circuit = remove_noise_from_circuit(ideal_circuit)
        self.qubit_list_code = qubit_list_code
        self.qubit_list_circuit = qubit_list_circuit
        self.starting_coord = starting_coord
        self.starting_coord_type = starting_coord_type
        self.Grid = Grid
        self.X = X
        self.Y = Y
        self.Grid_check = Grid_check
        self.BBcheck = BBcheck
        self.noise_config = noise_config if noise_config is not None else NoiseConfig()

        self.shuttling_routes = {
            "maximum_matching": {},
            "min_weight_matching": {},
            "total_shuttling_minimized": {},
            "maximum_matching_efficient": {},
            "min_weight_matching_efficient": {},
        }
        self.noise_list = {
            "maximum_matching": {},
            "min_weight_matching": {},
            "total_shuttling_minimized": {},
            "maximum_matching_efficient": {},
            "min_weight_matching_efficient": {},
        }
        self.noisy_circuit = {
            "maximum_matching": {},
            "min_weight_matching": {},
            "total_shuttling_minimized": {},
            "maximum_matching_efficient": {},
            "min_weight_matching_efficient": {},
        }

    def get_shuttling_routes(self, strategy: str, rounds):
        """
        Returns a list of dictionaries. The i-th dictionary indicates the coordinates of every qubit after the i-th tick.
        The list of dictionaries goes into self.shuttling_routes for the corresponding strategy.
        This method is used within the method get_shuttling_noise. Only call this method on its own if only the shuttling routes are desired.
        """
        ideal_circuit = self.ideal_circuit
        tick_list = split_at_ticks(ideal_circuit)
        current_coord = self.starting_coord
        self.shuttling_routes[strategy][rounds] = []

        shuttling_routes_start = {}
        for qubit in self.qubit_list_circuit:
            shuttling_routes_start[qubit] = self.starting_coord[qubit]
        self.shuttling_routes[strategy][rounds].append(shuttling_routes_start)

        for tick in tick_list:
            if not (
                ("DETECTOR" in str(tick)) or ("rec" in str(tick)) or ("-" in str(tick))
            ):
                # check if any 2-qubit gates exist in this tick to avoid phantom error
                has_2q_gate = any(inst.name in TWO_QUBIT_GATES for inst in tick)

                if not has_2q_gate:
                    shuttling_routes_tick = current_coord.copy()
                else:
                    pair = find_partner_qubit(tick, self.qubit_list_circuit)
                    travelers = pair_to_travelers(pair)
                    meet_points = MeetingPoints(
                        current_coord,
                        self.Grid,
                        travelers,
                        self.X,
                        self.Y,
                        self.Grid_check,
                    )
                    meet_points.get_meeting_points_for_strategy(strategy)
                    shuttling_routes_tick = {}
                    for qubit in self.qubit_list_circuit:
                        shuttling_routes_tick[qubit] = meet_points.meeting_points[
                            strategy
                        ][qubit]

                self.shuttling_routes[strategy][rounds].append(shuttling_routes_tick)
                current_coord = shuttling_routes_tick

        print("Shuttling routes determined.")
        return self.shuttling_routes

    def make_animation(
        self,
        strategy: str,
        rounds: int,
        color_dict=None,
        filename="shuttling_animation_pro.gif",
        fps=15,
        frames_between_ticks=20,
        pause_frames=5,
        cell_size=60,  # Pixels per grid square
    ):
        """Method that takes a list of shuttling routes (list of dicts of qubits to coordinates;
        given in self.shuttling_routes[strategy]) and creates an animation of the shuttling process
        which highlights interactions between qubits when they occur.

        Args:
            strategy: determines the shuttling routes self.shuttling_routes[strategy]
            X (int): X grid points
            Y (int): Y grid points
            color_dict (dict[int:colorstring], optional): dictionary of qubits to colors. Defaults to None.
            filename (str, optional): filename. Defaults to "shuttling_animation_pro.gif".
            fps (int, optional): frames per second - playback speed. Defaults to 15.
            frames_between_ticks (int, optional): smoothness of animation if higher. Defaults to 20.
            pause_frames (int, optional): how many frames for the interaction animation. Defaults to 5.
            cell_size (int, optional): resolution in pixels per cell. Defaults to 60.

        Returns:
            None: writes a file with the animation
        """
        if len(self.shuttling_routes[strategy][rounds]) < 2:
            print("Not enough frames to animate.")
            return

        ### CONSTRUCT COLOR DICT
        if self.BBcheck:
            color_dict = {}
            for q in self.qubit_list_code:
                if q[1] == "L":
                    color_dict[q[0]] = (34, 113, 178)  # "blue"
                elif q[1] == "R":
                    color_dict[q[0]] = (230, 159, 0)  # "orange"
                elif q[1] == "X":
                    color_dict[q[0]] = (213, 94, 0)  # "crimson"
                elif q[1] == "Z":
                    color_dict[q[0]] = (53, 155, 115)  # "forestgreen"

        if not self.BBcheck:
            qubits = list(self.shuttling_routes[strategy][rounds][0].keys())
            color_dict = {q: "dodgerblue" for q in qubits}

        # Now we store exactly WHICH qubits are meeting WHERE
        interacting_groups_per_tick = []
        for route in self.shuttling_routes[strategy][rounds]:
            coord_to_qs = {}
            for q, pos in route.items():
                coord_to_qs.setdefault(pos, []).append(q)

            # Keep only locations where 2 or more qubits are present
            interacting = {pos: qs for pos, qs in coord_to_qs.items() if len(qs) > 1}
            interacting_groups_per_tick.append(interacting)

        # Helper: Determine the visual offset for a qubit at a specific tick
        def get_offset(q, tick_idx):
            if tick_idx >= len(interacting_groups_per_tick):
                return 0.0, 0.0

            interactions = interacting_groups_per_tick[tick_idx]
            for pos, qs in interactions.items():
                if q in qs:
                    if len(qs) == 2:
                        # If it's a pair, push one left (-0.22) and one right (+0.22)
                        idx = qs.index(q)
                        return (-0.22 if idx == 0 else 0.22), 0.0
                    else:
                        # Fallback for >2 qubits: arrange in a circle
                        idx = qs.index(q)
                        angle = 2 * math.pi * idx / len(qs)
                        return 0.22 * math.cos(angle), 0.22 * math.sin(angle)
            # Solo qubit, no offset
            return 0.0, 0.0

        img_width = self.X * cell_size
        img_height = self.Y * cell_size
        base_img = Image.new("RGB", (img_width, img_height), "white")
        draw_base = ImageDraw.Draw(base_img)

        for x in range(self.X):
            px = int((x + 0.5) * cell_size)
            draw_base.line([(px, 0), (px, img_height)], fill="lightgray", width=1)
        for y in range(self.Y):
            py = int((y + 0.5) * cell_size)
            draw_base.line([(0, py), (img_width, py)], fill="lightgray", width=1)

        try:
            font = ImageFont.truetype("arial.ttf", 14)
        except IOError:
            try:
                font = ImageFont.load_default(size=14)
            except TypeError:
                font = ImageFont.load_default()

        def to_pixels(cx, cy):
            px = int((cx + 0.5) * cell_size)
            py = int(img_height - (cy + 0.5) * cell_size)
            return px, py

        total_expected = (len(self.shuttling_routes[strategy][rounds]) - 1) * (
            frames_between_ticks + pause_frames
        )
        print(f"Generating frames (Expected: {total_expected} frames)")
        frames = []

        for tick_idx in range(len(self.shuttling_routes[strategy][rounds]) - 1):
            current_coord = self.shuttling_routes[strategy][rounds][tick_idx]
            next_coord = self.shuttling_routes[strategy][rounds][tick_idx + 1]

            # movement
            for sub_frame in range(frames_between_ticks):
                img = base_img.copy()
                draw = ImageDraw.Draw(img)
                progress = sub_frame / frames_between_ticks

                for q in self.qubit_list_circuit:
                    x1, y1 = current_coord[q]
                    x2, y2 = next_coord[q]

                    # Manhattan route - not reflective of real route
                    if progress < 0.5:
                        p_x = progress * 2
                        base_x = x1 + (x2 - x1) * p_x
                        base_y = y1
                    else:
                        p_y = (progress - 0.5) * 2
                        base_x = x2
                        base_y = y1 + (y2 - y1) * p_y

                    #  offset to show both cells
                    off1_x, off1_y = get_offset(q, tick_idx)
                    off2_x, off2_y = get_offset(q, tick_idx + 1)

                    cur_off_x = off1_x + (off2_x - off1_x) * progress
                    cur_off_y = off1_y + (off2_y - off1_y) * progress

                    px, py = to_pixels(base_x + cur_off_x, base_y + cur_off_y)

                    # Draw main dot
                    r = cell_size * 0.22
                    q_val = getattr(q, "value", q)
                    draw.ellipse(
                        [px - r, py - r, px + r, py + r],
                        fill=color_dict.get(q_val, "dodgerblue"),
                    )

                    # Draw label

                    draw.text(
                        (px, py), str(q_val), fill="white", font=font, anchor="mm"
                    )

                frames.append(img)

            # Interaction Phase
            for sub_frame in range(pause_frames):
                img = base_img.copy()
                draw = ImageDraw.Draw(img)

                interactions = interacting_groups_per_tick[tick_idx + 1]
                for pos, qs in interactions.items():
                    px, py = to_pixels(pos[0], pos[1])
                    blink_color = "gold" if sub_frame % 2 == 0 else "darkorange"

                    if len(qs) == 2:
                        r_x = cell_size * 0.48  # Wide enough to cover both
                        r_y = cell_size * 0.30  # Standard height
                        draw.rounded_rectangle(
                            [px - r_x, py - r_y, px + r_x, py + r_y],
                            radius=int(cell_size * 0.3),
                            outline=blink_color,
                            width=3,
                        )
                    else:
                        # Draw a big circle if > 2 qubits (failsafe)
                        r = cell_size * 0.45
                        draw.ellipse(
                            [px - r, py - r, px + r, py + r],
                            outline=blink_color,
                            width=3,
                        )

                # 2. Draw the Qubits on top
                for q in self.qubit_list_circuit:
                    base_x, base_y = next_coord[q]
                    off_x, off_y = get_offset(q, tick_idx + 1)

                    px, py = to_pixels(base_x + off_x, base_y + off_y)

                    r = cell_size * 0.22
                    q_val = getattr(q, "value", q)
                    draw.ellipse(
                        [px - r, py - r, px + r, py + r],
                        fill=color_dict.get(q_val, "dodgerblue"),
                    )

                    draw.text(
                        (px, py), str(q_val), fill="white", font=font, anchor="mm"
                    )

                frames.append(img)

        frame_duration = int(1000 / fps)
        frames[0].save(
            filename,
            save_all=True,
            append_images=frames[1:],
            duration=frame_duration,
            loop=0,
        )
        print(f"Animation successfully saved to {filename}!")

    def _get_or_compute_structure(self, strategy: str, rounds: int, tick_list: list):
        """Parses the circuit and caches graph distances, structural pairings, and gate types per tick."""
        if not hasattr(self, "precomputed_structure"):
            self.precomputed_structure = {
                k: {}
                for k in [
                    "maximum_matching",
                    "min_weight_matching",
                    "total_shuttling_minimized",
                    "maximum_matching_efficient",
                    "min_weight_matching_efficient",
                ]
            }

        if rounds in self.precomputed_structure[strategy]:
            return self.precomputed_structure[strategy][rounds]

        structure = []
        i = 0
        for tick in tick_list:
            if not (
                ("DETECTOR" in str(tick)) or ("rec" in str(tick)) or ("-" in str(tick))
            ):
                pair = find_partner_qubit(tick, self.qubit_list_circuit)
                travelers = pair_to_travelers(pair)

                gate_types = {}
                for inst in tick:
                    targets = inst.targets_copy()
                    if inst.name in TWO_QUBIT_GATES:
                        for j in range(0, len(targets), 2):
                            if (
                                targets[j].is_qubit_target
                                and targets[j + 1].is_qubit_target
                            ):
                                t1, t2 = targets[j], targets[j + 1]
                                gate_types[(t1, t2)] = inst.name
                                gate_types[(t2, t1)] = inst.name
                    else:
                        for t in targets:
                            if t.is_qubit_target:
                                gate_types[(t, "solo")] = inst.name

                coord = self.shuttling_routes[strategy][rounds][i]
                meeting_points = self.shuttling_routes[strategy][rounds][i + 1]

                distances = {}
                for qubit in self.qubit_list_circuit:
                    distances[qubit] = nx.shortest_path_length(
                        self.Grid, coord[qubit], meeting_points[qubit]
                    )

                structure.append(
                    {
                        "type": "active_tick",
                        "travelers": travelers,
                        "gate_types": gate_types,
                        "distances": distances,
                    }
                )
                i += 1
            else:
                gate_types = {}
                has_physical_gate = False
                for inst in tick:
                    if (
                        inst.name in TWO_QUBIT_GATES
                        or inst.name in SINGLE_QUBIT_GATES
                        or inst.name in MEASUREMENT_GATES
                        or inst.name in RESET_GATES
                    ):
                        has_physical_gate = True
                        targets = inst.targets_copy()
                        if inst.name in TWO_QUBIT_GATES:
                            for j in range(0, len(targets), 2):
                                if (
                                    targets[j].is_qubit_target
                                    and targets[j + 1].is_qubit_target
                                ):
                                    t1, t2 = targets[j], targets[j + 1]
                                    gate_types[(t1, t2)] = inst.name
                                    gate_types[(t2, t1)] = inst.name
                        else:
                            for t in targets:
                                if t.is_qubit_target:
                                    gate_types[(t, "solo")] = inst.name

                if not has_physical_gate:
                    structure.append({"type": "virtual_tick"})
                else:
                    pair = find_partner_qubit(tick, self.qubit_list_circuit)
                    travelers = pair_to_travelers(pair)
                    distances = {
                        q: 0 for q in self.qubit_list_circuit
                    }  # Stationary tick

                    structure.append(
                        {
                            "type": "stationary_tick",
                            "travelers": travelers,
                            "gate_types": gate_types,
                            "distances": distances,
                        }
                    )

        self.precomputed_structure[strategy][rounds] = structure
        return structure

    def get_shuttling_noise(self, strategy: str, error_rates: Sequence[float], rounds):
        ideal_circuit = remove_noise_from_circuit(self.ideal_circuit)
        tick_list = split_at_ticks(ideal_circuit)

        for prob in error_rates:
            self.noise_list[strategy][prob] = []
            i = 0
            for tick in tick_list:
                if not (
                    ("DETECTOR" in str(tick))
                    or ("rec" in str(tick))
                    or ("-" in str(tick))
                ):
                    pair = find_partner_qubit(tick, self.qubit_list_circuit)
                    travelers = pair_to_travelers(pair)
                    gate_types = {}
                    for inst in tick:
                        targets = inst.targets_copy()
                        if inst.name in TWO_QUBIT_GATES:
                            for j in range(0, len(targets), 2):
                                if (
                                    targets[j].is_qubit_target
                                    and targets[j + 1].is_qubit_target
                                ):
                                    t1, t2 = targets[j], targets[j + 1]
                                    gate_types[(t1, t2)] = inst.name
                                    gate_types[(t2, t1)] = inst.name
                        else:
                            for t in targets:
                                if t.is_qubit_target:
                                    gate_types[(t, "solo")] = inst.name

                    # Use properties from noise_config instead of standalone attributes
                    shuttling_data = create_shuttling_errors(
                        self.qubit_list_circuit,
                        self.shuttling_routes[strategy][rounds][i],
                        self.shuttling_routes[strategy][rounds][i + 1],
                        self.Grid,
                        prob,
                        self.noise_config.ratio_T1toidlehalf,
                        self.noise_config.ratio_T1toshuttlinghalf,
                        noise_model=self.noise_config.noise_model,
                        eta_idle=self.noise_config.eta_idle,
                        eta_shuttle=self.noise_config.eta_shuttle,
                        shuttle_bias_dir=self.noise_config.shuttle_bias_dir,
                        gate_types=gate_types,
                        t_2q=self.noise_config.t_2q,
                        t_meas=self.noise_config.t_meas,
                        t_1q=self.noise_config.t_1q,
                        ratio_2q=self.noise_config.ratio_2q,
                        ratio_meas=self.noise_config.ratio_meas,
                        ratio_reset=self.noise_config.ratio_reset,
                    )

                    pair_noise_data = create_paired_shuttling_errors(
                        shuttling_data,
                        travelers,
                        gate_types,
                        prob,
                        self.noise_config.eta_cz,
                        self.noise_config.eta_cnot,
                        self.noise_config.gate_bias_dir,
                    )
                    self.noise_list[strategy][prob].append(
                        apply_custom_noise(tick, pair_noise_data)
                    )
                    i += 1
                else:
                    gate_types = {}
                    has_physical_gate = False
                    for inst in tick:
                        if (
                            inst.name in TWO_QUBIT_GATES
                            or inst.name in SINGLE_QUBIT_GATES
                            or inst.name in MEASUREMENT_GATES
                            or inst.name in RESET_GATES
                        ):
                            has_physical_gate = True
                            targets = inst.targets_copy()
                            if inst.name in TWO_QUBIT_GATES:
                                for j in range(0, len(targets), 2):
                                    if (
                                        targets[j].is_qubit_target
                                        and targets[j + 1].is_qubit_target
                                    ):
                                        t1, t2 = targets[j], targets[j + 1]
                                        gate_types[(t1, t2)] = inst.name
                                        gate_types[(t2, t1)] = inst.name
                            else:
                                for t in targets:
                                    if t.is_qubit_target:
                                        gate_types[(t, "solo")] = inst.name

                    if not has_physical_gate:
                        self.noise_list[strategy][prob].append(tick)
                    else:
                        pair = find_partner_qubit(tick, self.qubit_list_circuit)
                        travelers = pair_to_travelers(pair)
                        stationary_coords = self.shuttling_routes[strategy][rounds][i]

                        shuttling_data = create_shuttling_errors(
                            self.qubit_list_circuit,
                            stationary_coords,
                            stationary_coords,
                            self.Grid,
                            prob,
                            self.noise_config.ratio_T1toidlehalf,
                            self.noise_config.ratio_T1toshuttlinghalf,
                            noise_model=self.noise_config.noise_model,
                            eta_idle=self.noise_config.eta_idle,
                            eta_shuttle=self.noise_config.eta_shuttle,
                            shuttle_bias_dir=self.noise_config.shuttle_bias_dir,
                            gate_types=gate_types,
                            t_2q=self.noise_config.t_2q,
                            t_meas=self.noise_config.t_meas,
                            t_1q=self.noise_config.t_1q,
                            ratio_2q=self.noise_config.ratio_2q,
                            ratio_meas=self.noise_config.ratio_meas,
                            ratio_reset=self.noise_config.ratio_reset,
                        )

                        pair_noise_data = create_paired_shuttling_errors(
                            shuttling_data,
                            travelers,
                            gate_types,
                            prob,
                            self.noise_config.eta_cz,
                            self.noise_config.eta_cnot,
                            self.noise_config.gate_bias_dir,
                        )
                        self.noise_list[strategy][prob].append(
                            apply_custom_noise(tick, pair_noise_data)
                        )

            self.noisy_circuit[strategy][prob] = reassemble_circuit(
                self.noise_list[strategy][prob], insert_ticks=True
            )
        return self.noisy_circuit[strategy]


# This class might be redundant now as well...
class ShuttleNoisyCircuit(ShuttlingRoutes):
    def __init__(
        self,
        ideal_circuit,
        qubit_list_code: list,
        qubit_list_circuit: list,
        starting_coord: dict,
        starting_coord_type: str,
        Grid: nx.Graph(),
        X: int,
        Y: int,
        Grid_check: str,
        noise_config: NoiseConfig = None,
        BBcheck: bool = False,
    ):
        super().__init__(
            ideal_circuit,
            qubit_list_code,
            qubit_list_circuit,
            starting_coord,
            starting_coord_type,
            Grid,
            X,
            Y,
            Grid_check,
            noise_config,
            BBcheck,
        )
        self.ideal_circuit = remove_noise_from_circuit(ideal_circuit)

    def get_noisy_circuit(self, strategy: str, error_rates, rounds: int):
        """
        For a given strategy, this method builds the corresponding noisy
        syndrome extraction circuit. The circuit is placed in self.noisy_circuit[strategy]
        Existing strategies are: "min_weight_matching" and "maximum_matching"
        """
        self.get_shuttling_noise(strategy, error_rates, rounds)
        return self.noisy_circuit[strategy]
