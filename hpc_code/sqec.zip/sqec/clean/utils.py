import stim
import networkx as nx
import numpy as np
from qldpc import codes
from sympy import Poly
import sympy
from scipy.stats import linregress
import sinter
from dataclasses import dataclass, asdict
import math


@dataclass
class NoiseConfig:
    """what this does
    noise_model can be linear, exponential or gaussian
    t_2q is the time of a 2 qubit gate 0 to turn off
    t_meas is the time for measurmenent 0 to turn off
    t_1q is the time for a 1 qubit gate 0 to turn off
    eta_idle is the bias of the idling error, 0.5 is depolarizing error (and minimum),  0.5 is what is used in paper
    eta_shuttle is the bias of the shuttling error, 0.5 is depolarizing error (and minimum), 100 is what is used in paper
    eta_cz is the CZ gate error bias, 0.5 is depolarizing error (and minimum), 100 is what is used in paper
    eta_cnot is the bias of the CNOT error, 0.5 is depolarizing error (and minimum), 0.5 is what is used in paper
    shuttle_bias_dir is the direction of the bias for shuttling and idling noise, can be X, Y or Z - Z in paper
    gate_bias_dir is the direction of the bias for gate noise, can be X, Y or Z - Z in paper
    ratio_2q is the ratio between the 2 qubit gate error and the 1 qubit gate error - related to physical error
    ratio_meas is the ratio between the measurement error and the 1 qubit gate error - related to physical error
    ratio_reset is the ratio between the reset error and the 1 qubit gate error - related to physical error
    """

    noise_model: str = "linear"
    ratio_T1toidlehalf: float = 0.0017
    ratio_T1toshuttlinghalf: float = 0.004
    t_2q: float = 1.0
    t_meas: float = 1.0
    t_1q: float = 0.1
    eta_idle: float = 0.5
    eta_shuttle: float = 0.5
    eta_cz: float = 0.5
    eta_cnot: float = 0.5
    shuttle_bias_dir: str = "Z"
    gate_bias_dir: str = "Z"
    ratio_2q: float = 10.0
    ratio_meas: float = 20.0
    ratio_reset: float = 20.0

    def to_dict(self):
        return asdict(self)


TWO_QUBIT_GATES = {
    "CX",
    "CY",
    "CZ",
    "ISWAP",
    "SWAP",
    "XCX",
    "XCY",
    "XCZ",
    "YCX",
    "YCY",
    "YCZ",
    "ZCX",
    "ZCY",
    "ZCZ",
    "SQRT_XX",
    "SQRT_XX_DAG",
    "SQRT_YY",
    "SQRT_YY_DAG",
    "SQRT_ZZ",
    "SQRT_ZZ_DAG",
    "DEPOLARIZE2",
    "MXX",
    "MYY",
    "MZZ",
}
MEASUREMENT_GATES = {"M", "MX", "MY", "MZ"}
RESET_GATES = {"R", "RX", "RY", "RZ"}
SINGLE_QUBIT_GATES = {
    "I",
    "X",
    "Y",
    "Z",
    "C_NXYZ",
    "C_NZYX",
    "C_XNYZ",
    "C_XYNZ",
    "C_XYZ",
    "C_ZNYX",
    "C_ZYNX",
    "C_ZYX",
    "H",
    "H_NXY",
    "H_NXZ",
    "H_NYZ",
    "H_XY",
    "H_XZ",
    "H_YZ",
    "S",
    "SQRT_X",
    "SQRT_X_DAG",
    "SQRT_Y",
    "SQRT_Y_DAG",
    "SQRT_Z",
    "SQRT_Z_DAG",
    "S_DAG",
}

NOISE_GATES_SINGLE = {
    "DEPOLARIZE1",
    "E",
    "HERALDED_ERASE",
    "HERALDED_PAULI_CHANNEL_1",
    "I_ERROR",
    "PAULI_CHANNEL_1",
    "X_ERROR",
    "Y_ERROR",
    "Z_ERROR",
}

NOISE_GATES_MULTIPLE = {
    "CORRELATED_ERROR",
    "DEPOLARIZE2",
    "ELSE_CORRELATED_ERROR",
    "II_ERROR",
    "PAULI_CHANNEL_2",
}


def create_qubit_list(circuit: stim.Circuit) -> list:
    """
    Given a circuit, it creates the list of qubits used.
    """
    qubit_list = []
    for inst in circuit:
        targets = inst.targets_copy()
        for i in range(len(targets)):
            if targets[i] not in qubit_list:
                if "rec" not in str(targets[i]):
                    qubit_list.append(targets[i])
    return qubit_list


def Grid_distance(coord1, coord2):
    distance = abs(coord1[0] - coord2[0]) + abs(coord1[1] - coord2[1])
    return distance


def euclidean_distance(coord1, coord2):
    distance = np.sqrt((coord1[0] - coord2[0]) ** 2 + (coord1[1] - coord2[1]) ** 2)
    return distance


def build_octa_grid(X, Y):
    """
    Builds a square-grid graph of dimensions X x Y and adds the two diagonal edges into each square.
    """
    Octa_Grid = nx.grid_2d_graph(X, Y, periodic=False, create_using=None)

    for x in range(0, X - 1):
        for y in range(0, Y - 1):
            Octa_Grid.add_edge((x, y), (x + 1, y + 1))
        for y in range(1, Y):
            Octa_Grid.add_edge((x, y), (x + 1, y - 1))
    return Octa_Grid


def octa_grid_distance(v, w):
    """
    Computes the distance between two vertices in an octa-grid graph, assuming that
    the diagonal edges have length sqrt(2) and the square-edges have length 1.
    """
    if abs(v[0] - w[0]) > abs(v[1] - w[1]):
        distance = abs(v[1] - w[1]) * math.sqrt(2) + abs(v[0] - w[0]) - abs(v[1] - w[1])
    else:
        distance = abs(v[0] - w[0]) * math.sqrt(2) + abs(v[1] - w[1]) - abs(v[0] - w[0])
    return distance


def find_partner_qubit(circuit_tick: stim.Circuit, qubit_list: list):
    """
    Within a tick, it creates a dictionary that encodes which pairs of qubits interact with each other.
    If a qubit has no interaction, its dictionary entry is the string "solo".
    """
    pair = {}
    for inst in circuit_tick:
        if inst.name in TWO_QUBIT_GATES:
            targets = inst.targets_copy()
            for i in range(0, len(targets), 2):
                # Ensure we only pair actual physical qubits
                if targets[i].is_qubit_target and targets[i + 1].is_qubit_target:
                    if targets[i] not in pair:
                        if targets[i + 1] not in pair:
                            pair[targets[i]] = targets[i + 1]
        else:
            targets = inst.targets_copy()
            for i in range(len(targets)):
                # Ignore classical targets like rec[-1]
                if targets[i].is_qubit_target:
                    pair[targets[i]] = "solo"

    for inst in qubit_list:
        if inst not in pair:
            if inst not in pair.values():
                pair[inst] = "solo"

    return pair


def pair_to_travelers(pair: dict) -> set:
    travelers = set()
    for q, p in pair.items():
        if p == "solo":
            travelers.add((q,))
        else:
            ordered_pair = (q, p)  # if q.value < p.value else (p, q)
            travelers.add(ordered_pair)

    return travelers


def get_neighbours_from_circuit(circuit: stim.Circuit, qubit_list_circuit: list):
    neighbours = {}
    for qubit in qubit_list_circuit:
        neighbours[qubit] = set()
    for inst in circuit:
        if inst.name in TWO_QUBIT_GATES:
            targets = inst.targets_copy()
            for i in range(0, len(targets), 2):
                neighbours[targets[i]].add(targets[i + 1])
                neighbours[targets[i + 1]].add(targets[i])

    return neighbours


def apply_custom_noise(ideal_circuit: stim.Circuit, noise_map: dict) -> stim.Circuit:
    """
    Takes an ideal circuit and applies custom noise based on the qubit pair or solo qubit.
    Shuttling/idling/measurement noise is prepended; gate/reset noise is appended.
    Noise gates with 0.0 probability are completely ignored.
    """

    def is_zero_noise(noise_args):
        if isinstance(noise_args, (list, tuple)):
            return all(p == 0.0 for p in noise_args)
        return noise_args == 0.0

    noisy_circuit = stim.Circuit()

    for inst in ideal_circuit:
        is_1q_gate = (
            inst.name in SINGLE_QUBIT_GATES
            or inst.name in MEASUREMENT_GATES
            or inst.name in RESET_GATES
        )

        if inst.name not in TWO_QUBIT_GATES and not is_1q_gate:
            noisy_circuit.append(inst)
            continue

        targets = inst.targets_copy()

        # --- TWO QUBIT GATES ---
        if inst.name in TWO_QUBIT_GATES:
            for i in range(0, len(targets), 2):
                t1, t2 = targets[i], targets[i + 1]  # FIXED: Kept as GateTarget objects

                # Check both orientations in case the routing graph inverted the tuple
                noise_def = noise_map.pop((t1, t2), None)
                if noise_def is None:
                    noise_def = noise_map.pop((t2, t1), None)

                # 1. Apply BEFORE noise (Shuttling / Idling)
                if noise_def is not None:
                    for noise_entry in noise_def.get("before", []):
                        noise_gate, noise_args, noise_qubits = noise_entry
                        if not is_zero_noise(noise_args):
                            noisy_circuit.append(noise_gate, noise_qubits, noise_args)

                # 2. Apply the actual 2Q gate
                noisy_circuit.append(inst.name, [t1, t2], inst.gate_args_copy())

                # 3. Apply AFTER noise (Gate Error)
                if noise_def is not None:
                    for noise_entry in noise_def.get("after", []):
                        noise_gate, noise_args, noise_qubits = noise_entry
                        if not is_zero_noise(noise_args):
                            noisy_circuit.append(noise_gate, noise_qubits, noise_args)

        # --- SINGLE QUBIT, MEASUREMENT, AND RESET GATES ---
        elif is_1q_gate:
            for i in range(0, len(targets)):
                t1 = targets[i]  # FIXED: Kept as GateTarget object
                noise_def = noise_map.pop((t1,), None)

                # 1. Apply BEFORE noise (Shuttling / Idling / Measurement Error)
                if noise_def is not None:
                    for noise_entry in noise_def.get("before", []):
                        noise_gate, noise_args, noise_qubits = noise_entry
                        if not is_zero_noise(noise_args):
                            noisy_circuit.append(noise_gate, noise_qubits, noise_args)

                # 2. Apply the actual 1Q / Measure / Reset gate
                noisy_circuit.append(inst.name, [t1], inst.gate_args_copy())

                # 3. Apply AFTER noise (Gate / Reset Error)
                if noise_def is not None:
                    for noise_entry in noise_def.get("after", []):
                        noise_gate, noise_args, noise_qubits = noise_entry
                        if not is_zero_noise(noise_args):
                            noisy_circuit.append(noise_gate, noise_qubits, noise_args)

    # Catch any remaining decoupled noise in the map
    for entry in list(noise_map.keys()):
        if noise_map[entry] is not None:
            leftovers = noise_map[entry].get("before", []) + noise_map[entry].get(
                "after", []
            )
            for noise_entry in leftovers:
                noise_gate, noise_args, noise_qubits = noise_entry
                if not is_zero_noise(noise_args):
                    noisy_circuit.append(noise_gate, noise_qubits, noise_args)

    return noisy_circuit


def remove_noise_from_circuit(
    noisy_circuit: stim.Circuit,
    noise_gates: set = NOISE_GATES_SINGLE.union(NOISE_GATES_MULTIPLE),
) -> stim.Circuit:
    """
    Removes specified noise gates from a circuit, leaving ticks.

    :param noisy_circuit: The stim.Circuit containing noise.
    :param noise_gates: A set of gate names to remove from the circuit.
    :return: A new stim.Circuit with the specified noise gates removed.
    """
    noisy_circuit = noisy_circuit.flattened()
    cleaned_circuit = stim.Circuit()

    for inst in noisy_circuit:
        if inst.name not in noise_gates:
            cleaned_circuit.append(
                inst.name, inst.targets_copy(), inst.gate_args_copy()
            )

    return cleaned_circuit


def insert_ticks_greedily(circuit: stim.Circuit) -> stim.Circuit:
    """
    Takes a STIM circuit and adds TICK commands by greedily
    grouping unpacked instructions into parallel time slices.
    """
    flat_circuit = circuit.flattened()
    ticked_circuit = stim.Circuit()
    current_layer = stim.Circuit()
    busy_qubits = set()

    #  annotations/gates that shouldn't be blindly chunked
    NO_SPLIT_GATES = {
        "DETECTOR",
        "OBSERVABLE_INCLUDE",
        "QUBIT_COORDS",
        "SHIFT_COORDS",
        "MPP",
        "SPP",
        "CORRELATED_ERROR",
        "ELSE_CORRELATED_ERROR",
        "E",
    }

    for inst in flat_circuit:
        if inst.name == "TICK":
            if len(current_layer) > 0:
                ticked_circuit += current_layer
                ticked_circuit.append("TICK")
                current_layer = stim.Circuit()
                busy_qubits.clear()
            else:
                ticked_circuit.append("TICK")
            continue

        targets = inst.targets_copy()
        args = inst.gate_args_copy()

        # Determine the target chunk size based on the gate type
        if inst.name in TWO_QUBIT_GATES:
            chunk_size = 2
        elif inst.name in NO_SPLIT_GATES:
            chunk_size = max(1, len(targets))  # Keep whole
        else:
            chunk_size = 1

        # Process targets in chunks (1-by-1, 2-by-2, etc.)
        for i in range(0, len(targets), chunk_size):
            chunk = targets[i : i + chunk_size]

            # Identify qubit targets (not record targets, etc.)
            op_qubits = {t.value for t in chunk if t.is_qubit_target}

            # Collision check for this specific micro-operation
            if not op_qubits.isdisjoint(busy_qubits):
                ticked_circuit += current_layer
                ticked_circuit.append("TICK")
                current_layer = stim.Circuit()
                busy_qubits.clear()

            current_layer.append(inst.name, chunk, args)
            busy_qubits.update(op_qubits)

    if len(current_layer) > 0:
        ticked_circuit += current_layer

    return ticked_circuit


def split_at_ticks(circuit: stim.Circuit) -> list[stim.Circuit]:
    """
    Splits a STIM circuit into a list of circuits based on TICK instructions.
    The TICK instructions are consumed/removed in the output list.
    """
    parts = []
    current_part = stim.Circuit()

    for inst in circuit:
        if inst.name == "TICK":
            parts.append(current_part)
            current_part = stim.Circuit()
        else:
            current_part.append(inst)

    parts.append(current_part)

    return parts


def reassemble_circuit(parts: list[stim.Circuit], insert_ticks=True) -> stim.Circuit:
    """
    Takes a list of STIM circuits and reassembles them into a single
    circuit, inserting a TICK between each part.
    """
    reassembled = stim.Circuit()

    for i, part in enumerate(parts):
        reassembled += part
        if (i < len(parts) - 1) and insert_ticks:
            reassembled.append("TICK")  # adding ticks back in for ease of use

    return reassembled


# ------------------------MEMORYEXPERIMENT AND CODES--------------------------


def build_matrix_list(L: int, M: int, poly: sympy.Basic):
    p = Poly(poly)  # Because poly is sympy.Basic and .monoms is a method of Poly.
    monom = p.monoms()
    A = []
    for i in range(3):
        a, b = monom[i]
        Mat1 = np.array(create_x_matrix(a, L, M))
        Mat2 = np.array(create_y_matrix(b, L, M))
        Mat = np.matmul(Mat1, Mat2)
        A.append(Mat.tolist())
    return A


def create_x_matrix(exponent: int, L: int, M: int):
    matrix = []

    for row in range(L * M):
        vect = []
        for block in range(L):
            if ((row // M) + exponent) % L == block:
                for j in range(M):
                    if j == row % M:
                        vect.append(1)
                    else:
                        vect.append(0)
            else:
                vect = vect + [0] * M
        matrix.append(vect)

    return matrix


def create_y_matrix(exponent: int, L: int, M: int):
    matrix = []
    for row in range(L * M):
        vect = []
        for block in range(L):
            if (row // M) == block:
                for j in range(M):
                    if j == (row % M + exponent) % M:
                        vect.append(1)
                    else:
                        vect.append(0)
            else:
                vect = vect + [0] * M
        matrix.append(vect)

    return matrix


def get_parity_check_matrix(A, B):
    """
    Given two lists of three matrices each, we define the parity check matrix of the associated BB code.
    Note that the output is the two check-matrices H_X and H_Z stacked on top of each other
    (i.e. the number of columns is equal to the number of data qubits).
    """
    # Defines the two matrices A and B
    A_full = []
    B_full = []
    for i in range(len(A[0])):
        rowA = []
        rowB = []
        for j in range(len(A[0][0])):
            rowA.append(A[0][i][j] + A[1][i][j] + A[2][i][j])
            rowB.append(B[0][i][j] + B[1][i][j] + B[2][i][j])

        A_full.append(rowA)
        B_full.append(rowB)

    # Defines the transpose of the two matrices above
    A_transposed = []
    for j in range(len(A_full)):
        vect = []
        for i in range(len(A_full[0])):
            vect.append(A_full[i][j])
        A_transposed.append(vect)

    B_transposed = []
    for j in range(len(B_full)):
        vect = []
        for i in range(len(B_full[0])):
            vect.append(B_full[i][j])
        B_transposed.append(vect)

    # Defines the full parity check matrix.
    X_checks = []
    Z_checks = []

    for i in range(len(A_full)):
        X_checks.append(A_full[i] + B_full[i])
        Z_checks.append(A_transposed[i] + B_transposed[i])

    code_matrix = X_checks + Z_checks

    return code_matrix


def get_dimension(A, B):
    """Computes the dimension - number of encoded logical qubits - for the BB code of the pair A, B."""

    A_full = []
    for i in range(len(A[0])):
        rowA = []
        for j in range(len(A[0][0])):
            rowA.append(A[0][i][j] + A[1][i][j] + A[2][i][j])
        A_full.append(rowA)

    A_array = np.array(A_full)
    rank = int(np.linalg.matrix_rank(A_array))
    dimension = 2 * len(A_full[0]) - 2 * rank
    return dimension


def transpose(matrix):
    transposed_matrix = []
    for j in range(len(matrix[0])):
        vect = []
        for i in range(len(matrix)):
            vect.append(matrix[i][j])
        transposed_matrix.append(vect)

    return transposed_matrix


def transpose_list(matrix_list):
    transposed_list = []
    for A in matrix_list:
        transposed_list.append(transpose(A))

    return transposed_list


def create_BB_qubit_list(code_matrix):
    rows = len(code_matrix)
    columns = len(code_matrix[0])
    data_qubit_list = []
    check_qubit_list = []
    qubit_type = {}
    for i in range(columns):
        if i < columns // 2:
            data_qubit_list.append((i, "L"))
            qubit_type[(i, "L")] = "L"
        else:
            data_qubit_list.append((i, "R"))
            qubit_type[(i, "R")] = "R"

    for i in range(rows):
        if i < rows // 2:
            check_qubit_list.append((rows + i, "X"))
            qubit_type[(rows + i, "X")] = "X"

        else:
            check_qubit_list.append((rows + i, "Z"))
            qubit_type[(rows + i, "Z")] = "Z"

    qubit_list = data_qubit_list + check_qubit_list

    return data_qubit_list, check_qubit_list, qubit_list, qubit_type


# The following function creates a layout for the Tanner-graph. This layout contains several constants that are chosen specifically for the Gross code. It works for the rest, but may not be standard.
def get_qubit_coordinates(qubit_list: list, qubit_type: dict, L: int, M: int):
    i = 0
    qubit_coordinates = {}
    for qubit in qubit_list:
        if qubit_type[qubit] == "L":
            qubit_coordinates[qubit] = (
                2 * ((i // M) % L),
                (2 * (i % M) + 6 * (i // M)) % (2 * M),
            )
        if qubit_type[qubit] == "R":
            qubit_coordinates[qubit] = (
                2 * ((i // M) % L) + 1,
                (2 * (i % M) + 9 + 6 * (i // M)) % (2 * M),
            )
        if qubit_type[qubit] == "Z":
            qubit_coordinates[qubit] = (
                2 * ((i // M) % L) + 1,
                (2 * (i % M) + 6 + 6 * (i // M)) % (2 * M),
            )
        if qubit_type[qubit] == "X":
            qubit_coordinates[qubit] = (
                2 * ((i // M) % L),
                (2 * (i % M) + 3 + 6 * (i // M)) % (2 * M),
            )
        i = i + 1

    return qubit_coordinates


def get_label(
    code: codes.ClassicalCode | codes.QuditCode,
    distance_trials: bool | int = False,
) -> str:
    """Get a label for a code in a figure.

    If the code distance is not known, use a given number of trials to estimate it.
    """
    known_distance = code.get_distance_if_known()
    if isinstance(known_distance, int):
        return f"$d={known_distance}$"
    if not distance_trials:
        return f"[{len(code)}, {code.dimension}]"
    distance_estimate = code.get_distance_bound(num_trials=int(distance_trials))
    return f"[{len(code)}, {code.dimension}, d <= {distance_estimate}]"


def estimate_code_distance(error_rates, logical_errors):
    """
    Estimates the slope of the linear approximation of the plot logical_errors(error_rates).
    In addition, it returns the estimated distance d_estimate of an error correction code that would cause such a slope.
    The relationship between the slope and d_estimate is given by: (d_estimate + 1) / 2  = slope.
    We also return the standard error of the linear regression.
    """
    phys_err = np.array(error_rates)
    logic_err = np.array(logical_errors)

    log_phys_err = np.log(phys_err)
    log_logic_err = np.log(logic_err)

    slope, intercept, _, _, stderr = linregress(log_phys_err, log_logic_err)

    d_estimate = 2 * slope - 1

    return d_estimate, slope, intercept, stderr


# --------------------------STARTINGCOORDINATES-----------------------------


def translate_dictionary(qubit_layout):
    new_dict = {}
    for ind in qubit_layout.keys():
        new_dict[stim.GateTarget(ind[0])] = qubit_layout[ind]
    return new_dict


def fold_layout(layout, ord1, ord2):
    """
    Given a layout of qubits on a 2*ord1 x 2*ord2 grid, we fold the layout horizontally and vertically along the middle
    and return the resulting dictionary.

    Args:
        layout is a dictionary, its keys are the qubits and its values are pairs of integers.
    """
    folded_layout = {}

    for qubit in layout.keys():
        coord_x = layout[qubit][0]
        coord_y = layout[qubit][1]
        if coord_x < ord1:
            if coord_y < ord2:
                folded_layout[qubit] = (2 * coord_x, 2 * coord_y)
        if coord_x >= ord1:
            if coord_y < ord2:
                folded_layout[qubit] = (2 * (2 * ord1 - 1 - coord_x) + 1, 2 * coord_y)
        if coord_x < ord1:
            if coord_y >= ord2:
                folded_layout[qubit] = (2 * coord_x, 2 * (2 * ord2 - 1 - coord_y) + 1)
        if coord_x >= ord1:
            if coord_y >= ord2:
                folded_layout[qubit] = (
                    2 * (2 * ord1 - 1 - coord_x) + 1,
                    2 * (2 * ord2 - 1 - coord_y) + 1,
                )

    return folded_layout


def create_Tanner_layout(qubit_list, L, M):
    """
    Places qubits from a qubit_list on an 2*L x 2*M square grid based on the following principle:
    We place qubits in spaces of 2, leaving intermediate spaces for the second half of qubits in the list
    (because in the list, the data qubits come first, the ancilla come after).

    If polyA and polyB contain the terms y+y**2 and x+x**2 respectively,
    this yields a (non-unique) Tanner-graph layout.

    Args:
        qubit_list: A list of qubits that is produced from the basic ingredients of a BB-code. Specifically, the qubits are integers from 0 to 4*L*M.
    """

    X = 2 * L
    Y = 2 * M

    if len(qubit_list) > X * Y:
        print(f"Qubits do not fit on a Grid with dimensions {X} and {Y}.")
        return

    qubit_layout = {}

    for qubit in qubit_list:
        if qubit[0] < L * M:  # Placing the L-qubits.
            qubit_layout[qubit] = ((2 * (qubit[0] // M)) % X, (2 * qubit[0]) % Y)
        if L * M <= qubit[0] and qubit[0] < 2 * L * M:  # Placing the R-qubits.
            qubit_aux = qubit[0] % (L * M)  # R-qubits start at L*M.
            qubit_layout[qubit] = (
                ((2 * (qubit_aux // M)) - 3) % X,
                ((2 * qubit_aux) + 3) % Y,
            )
        if 2 * L * M <= qubit[0] and qubit[0] < 3 * L * M:  # Placing the X-checks.
            qubit_aux = qubit[0] % (L * M)
            qubit_layout[qubit] = (
                (2 * (qubit_aux // M)) % X,
                ((2 * qubit_aux) + 3) % Y,
            )
        if 3 * L * M <= qubit[0]:  # Placing the Z-checks
            qubit_aux = qubit[0] % (L * M)
            qubit_layout[qubit] = ((2 * (qubit_aux // M) - 3) % X, (2 * qubit_aux) % Y)

    return qubit_layout


def basis_check(vec1, vec2, L, M):
    check = True
    ord1 = get_order(vec1, L, M)
    ord2 = get_order(vec2, L, M)
    for a in range(L):
        for b in range(M):
            check_aux = False
            for alpha in range(ord1):
                for beta in range(ord2):
                    if (alpha * vec1[0] + beta * vec2[0] % L == a) and (
                        alpha * vec1[1] + beta * vec2[1] % M == b
                    ):
                        check_aux = True
                        break
                if check_aux:
                    break
            check = check and check_aux
    return check


def get_order(vec, L, M):
    for i in range(1, L * M):
        if (vec[0] * i % L == 0) and (vec[1] * i % M == 0):
            return i


def order_check(vec1, vec2, L, M):
    order1 = get_order(vec1, L, M)
    order2 = get_order(vec2, L, M)
    check = order1 * order2 == L * M
    return check


def get_good_inits(L, M):
    """
    For a given pair L, M for a BB code and its qubit list with 2*L*M data qubits and 2*L*M check qubits,
    this function returns a list of all pairs (a,b) that induce 'promising' starting positions for the data qubits.

    good_inits is a list of tuples, where the entries in the tuples are integers (modulo L and M respectively).
    """
    good_inits = []

    for a in range(L):
        for c in range(L):
            for b in range(M):
                for d in range(M):
                    vec1 = (a, b)
                    vec2 = (c, d)
                    if basis_check(vec1, vec2, L, M) and order_check(vec1, vec2, L, M):
                        if (vec2, vec1) not in good_inits:
                            good_inits.append((vec1, vec2))

    return good_inits


def find_representation(coord, vec1, vec2, L, M):
    for alpha in range(get_order(vec1, L, M)):
        for beta in range(get_order(vec2, L, M)):
            if ((alpha * vec1[0] + beta * vec2[0]) % L == coord[0]) and (
                (alpha * vec1[1] + beta * vec2[1]) % M == coord[1]
            ):
                return alpha, beta


def get_promising_data_layouts(A, B, L, M, qubit_list_code):
    """
    Takes a circuit and the parameters L, M of a BB code to return a list of data-qubit-layouts that are
    promising candidates to create an optimal layout in terms of largest distance of 2-qubit gates.

    The return is a list whose entries are triples (layout, ord1, ord2). 'layout' is the dictionary that gives coordinates to the data qubits.
    'ord1' and 'ord2' indicate the size of the coordinate grid.

    Note that we assume that the monomial LR in the creation of the good initial values satisfies LR = 1. In general, LR could be chosen arbitrarily.
    This multiplies the runtime of this function by roughly L*M.
    """

    good_inits = get_good_inits(L, M)

    layout_list = []

    for vec1, vec2 in good_inits:
        for a in range(L):
            for b in range(M):
                transition_vectorLR = (a, b)
                vec1T = ((L - vec1[0]) % L, (M - vec1[1]) % M)
                vec2T = ((L - vec2[0]) % L, (M - vec2[1]) % M)
                ord1 = get_order(vec1, L, M)
                ord2 = get_order(vec2, L, M)
                prelim_layout1 = {}
                prelim_layout2 = {}
                prelim_layout3 = {}
                prelim_layout4 = {}
                for i in range(L * M):
                    coordL = (i // M, i % M)
                    coordR = (
                        (i // M - transition_vectorLR[0]) % L,
                        (i % M - transition_vectorLR[1]) % M,
                    )
                    alpha, beta = find_representation(coordL, vec1, vec2, L, M)
                    gamma1, delta1 = find_representation(coordR, vec1, vec2, L, M)
                    prelim_layout1[qubit_list_code[i]] = (2 * alpha, 2 * beta)
                    prelim_layout1[qubit_list_code[i + L * M]] = (
                        2 * gamma1 + 1,
                        2 * delta1 + 1,
                    )

                    gamma2, delta2 = find_representation(coordR, vec1T, vec2T, L, M)
                    prelim_layout2[qubit_list_code[i]] = (2 * alpha, 2 * beta)
                    prelim_layout2[qubit_list_code[i + L * M]] = (
                        2 * gamma2 + 1,
                        2 * delta2 + 1,
                    )

                    gamma3, delta3 = find_representation(coordR, vec1, vec2T, L, M)
                    prelim_layout3[qubit_list_code[i]] = (2 * alpha, 2 * beta)
                    prelim_layout3[qubit_list_code[i + L * M]] = (
                        2 * gamma3 + 1,
                        2 * delta3 + 1,
                    )

                    gamma4, delta4 = find_representation(coordR, vec1T, vec2, L, M)
                    prelim_layout4[qubit_list_code[i]] = (2 * alpha, 2 * beta)
                    prelim_layout4[qubit_list_code[i + L * M]] = (
                        2 * gamma4 + 1,
                        2 * delta4 + 1,
                    )
                layout_list.append(
                    (prelim_layout1, ord1, ord2, vec1, vec2, transition_vectorLR)
                )
                layout_list.append(
                    (prelim_layout2, ord1, ord2, vec1, vec2, transition_vectorLR)
                )
                layout_list.append(
                    (prelim_layout3, ord1, ord2, vec1, vec2, transition_vectorLR)
                )
                layout_list.append(
                    (prelim_layout4, ord1, ord2, vec1, vec2, transition_vectorLR)
                )

    return layout_list


def free_nodes(Grid, data_qubit_layout: dict):
    # made into set so that you don't have to loop over everything
    free_nodes = {}
    occupied_positions = set(data_qubit_layout.values())
    for node in Grid:
        free_nodes[node] = node not in occupied_positions
    return free_nodes


def build_connection_graph(
    A, B, Grid, Radius, data_qubit_layout, Grid_check, X, Y, check_qubits, neighbours
):  # Both here and below, I shouldn't use the code, but the two triples of matrices that define the code. That is much easier to use.
    """
    For a given circuit and data-qubit layout, this function returns the graph that connects every check-qubit with all free coordinates in the Grid
    such that the check-qubit has distance at most Radius to all its neighbours in the Tanner graph.
    """
    # if Grid_check == "Squaregrid":
    #     print("We are assuming that Grid is an " + str(X) + " x " + str(Y) + " square grid.")

    connection_graph = nx.Graph()
    open_nodes = free_nodes(Grid, data_qubit_layout)

    # data_qubits, check_qubits, qubit_list, qubit_type, code_matrix = get_key_data(A, B)

    # neighbours = BBcodes.get_neighbours(A, B)

    # Adding the vertices to the connection graph: The check qubits and the free spots in the connection graph are added.
    for qubit in check_qubits:
        connection_graph.add_node(qubit)
    for node in Grid:
        if open_nodes[node]:
            connection_graph.add_node(node)

    for qubit in check_qubits:
        for node in Grid:
            if open_nodes[node]:
                check = True
                for dataqubit in neighbours[qubit].values():
                    if Grid_check == "Squaregrid":
                        if Grid_distance(node, data_qubit_layout[dataqubit]) > Radius:
                            # if ( min( abs(node[0] - data_qubit_layout[dataqubit][0]), X - abs(node[0] - data_qubit_layout[dataqubit][0]) ) +
                            #     min( abs(node[1] - data_qubit_layout[dataqubit][1]), Y - abs(node[1] - data_qubit_layout[dataqubit][1]) ) ) > Radius:
                            check = False
                            break  # unecessary additional calculations
                    elif Grid_check == "Octagrid":
                        if (
                            octa_grid_distance(node, data_qubit_layout[dataqubit])
                            > Radius
                        ):
                            check = False
                            break  # unecessary additional calculations
                    else:
                        if (
                            nx.shortest_path_length(
                                Grid, node, data_qubit_layout[dataqubit]
                            )
                            > Radius
                        ):
                            check = False
                if check:
                    connection_graph.add_edge(qubit, node)

    return connection_graph


def get_optimized_qubit_layout(A, B, L, M, check_qubits, qubit_list_code, neighbours):
    """
    Takes a circuit and the parameters L, M of a BB code to return a qubit-layout
    that attempts to minimize the distance between any two qubits that are supposed to interact during the circuit.
    Grid is the underlying grid on which the optimization problem is being solved.

    First, we create a list of reasonable layouts for the data qubits on the grid. Then, we use matchings to place the ancillae in a way that
    optimizes distance for each 'reasonable layout'. We then pick the 'reasonable layout' that yields the best result.

    Note that we assume that the monomial LR in the creation of the good initial values satisfies LR = 1. In general, LR could be chosen arbitrarily.

    We currently also assume that the qubits can move along a square-grid of dimensions 2*ord1, 2*ord2.
    In principle, this code is amenable to generalization, but one has to figure out what the generalization of get_good_inits should be.
    """
    # data_qubits, check_qubits, qubit_list, qubit_type, code_matrix = get_key_data(A, B)
    # good_inits = get_good_inits(L, M)
    layout_list = get_promising_data_layouts(A, B, L, M, qubit_list_code)
    qubit_layout = {}
    R_optimal = L * M
    optimal_data_layout = {}

    for layout, ord1, ord2, vec1, vec2, transition_vectorLR in layout_list:
        Grid = nx.grid_2d_graph(2 * ord1, 2 * ord2, periodic=False)
        Grid_check = "Squaregrid"
        layout_inst = fold_layout(layout, ord1, ord2)

        # Binary search instead of linear search to get log complexity
        low = 1
        high = (2 * ord1) + (2 * ord2)
        best_R_for_layout = float("inf")  # traditionally you do this
        check_qubits_layout = {}

        while low <= high:
            mid = (low + high) // 2

            G_R = build_connection_graph(
                A,
                B,
                Grid,
                mid,
                layout_inst,
                Grid_check,
                2 * ord1,
                2 * ord2,
                check_qubits,
                neighbours,
            )
            perf_match = nx.bipartite.maximum_matching(G_R, top_nodes=check_qubits)

            if all(qubit in perf_match for qubit in check_qubits):
                best_R_for_layout = mid
                check_qubits_layout = {
                    qubit: perf_match[qubit] for qubit in check_qubits
                }
                optimal_data_layout = layout_inst
                optimal_check_layout = check_qubits_layout
                R_optimal = best_R_for_layout
                Grid_optimal = Grid
                ord1_optimal = ord1
                ord2_optimal = ord2
                vec1_optimal = vec1
                vec2_optimal = vec2
                transition_vector_optimal = transition_vectorLR
                high = mid - 1
            else:
                low = mid + 1
        # if best_R_for_layout <= 29:
        #     pass
        # print(vec1, vec2, transition_vectorLR, best_R_for_layout)
    qubit_layout = optimal_data_layout | optimal_check_layout

    print(
        "The optimal layout is on a "
        + str(2 * ord1_optimal)
        + " x "
        + str(2 * ord2_optimal)
        + " Grid."
    )
    print("The largest interaction-distance is " + str(R_optimal) + ".")

    return (
        qubit_layout,
        Grid_optimal,
        2 * ord1_optimal,
        2 * ord2_optimal,
        vec1_optimal,
        vec2_optimal,
        transition_vector_optimal,
    )


def serialize_state(obj):
    """Recursively converts complex python objects to JSON-serializable dictionaries."""
    if isinstance(obj, dict):
        if any(not isinstance(k, str) for k in obj.keys()):
            return {
                "__type__": "dict_with_nonstr_keys",
                "val": [
                    [serialize_state(k), serialize_state(v)] for k, v in obj.items()
                ],
            }
        else:
            return {k: serialize_state(v) for k, v in obj.items()}
    elif isinstance(obj, list):
        return [serialize_state(v) for v in obj]
    elif isinstance(obj, tuple):
        return {"__type__": "tuple", "val": [serialize_state(v) for v in obj]}
    elif isinstance(obj, set):
        return {"__type__": "set", "val": [serialize_state(v) for v in obj]}
    elif isinstance(obj, sympy.Basic):
        return {"__type__": "sympy", "val": str(obj)}
    elif isinstance(obj, nx.Graph):
        return {"__type__": "nx_graph", "val": nx.node_link_data(obj)}
    elif isinstance(obj, stim.Circuit):
        return {"__type__": "stim_circuit", "val": str(obj)}
    elif isinstance(obj, stim.GateTarget):
        return {"__type__": "stim_gatetarget", "val": obj.value}
    elif isinstance(obj, sinter.TaskStats):
        return {
            "__type__": "sinter_taskstats",
            "strong_id": getattr(obj, "strong_id", "unknown_id"),
            "decoder": getattr(obj, "decoder", "unknown_decoder"),
            "json_metadata": getattr(obj, "json_metadata", {}),
            "errors": getattr(obj, "errors", 0),
            "shots": getattr(obj, "shots", 0),
            "discards": getattr(obj, "discards", 0),
            "seconds": getattr(obj, "seconds", 0.0),
            "custom_error_rate": getattr(obj, "custom_error_rate", None),
        }
    elif isinstance(obj, np.ndarray):
        return {"__type__": "ndarray", "val": obj.tolist()}
    elif isinstance(
        obj,
        (
            np.int_,
            np.intc,
            np.intp,
            np.int8,
            np.int16,
            np.int32,
            np.int64,
            np.uint8,
            np.uint16,
            np.uint32,
            np.uint64,
        ),
    ):
        return int(obj)
    elif isinstance(obj, (np.float16, np.float32, np.float64)):
        return float(obj)
    elif isinstance(obj, (int, float, str, bool, type(None))):
        return obj
    else:
        if hasattr(obj, "__dict__"):
            return {
                "__type__": "custom_object",
                "class": type(obj).__name__,
                "val": serialize_state(obj.__dict__),
            }
        return str(obj)


def deserialize_state(obj):
    """Recursively reconstructs complex python objects from their JSON-serialized format."""
    if isinstance(obj, dict):
        obj_type = obj.get("__type__")

        if obj_type == "dict_with_nonstr_keys":
            return {deserialize_state(k): deserialize_state(v) for k, v in obj["val"]}
        elif obj_type == "tuple":
            return tuple(deserialize_state(v) for v in obj["val"])
        elif obj_type == "set":
            return set(deserialize_state(v) for v in obj["val"])
        elif obj_type == "sympy":
            return sympy.sympify(obj["val"])
        elif obj_type == "nx_graph":
            return nx.node_link_graph(obj["val"])
        elif obj_type == "stim_circuit":
            return stim.Circuit(obj["val"])
        elif obj_type == "stim_gatetarget":
            return stim.GateTarget(obj["val"])
        elif obj_type == "sinter_taskstats":
            # UPDATED: Safely reconstructs TaskStats, providing fallback values for older JSONs
            kwargs = {
                "strong_id": obj.get("strong_id", "unknown_id"),
                "decoder": obj.get("decoder", "unknown_decoder"),
                "json_metadata": obj.get("json_metadata", {}),
                "errors": obj.get("errors", 0),
                "shots": obj.get("shots", 0),
                "discards": obj.get("discards", 0),
                "seconds": obj.get("seconds", 0.0),
            }
            if obj.get("custom_error_rate") is not None:
                kwargs["custom_error_rate"] = obj["custom_error_rate"]

            return sinter.TaskStats(**kwargs)

        elif obj_type == "ndarray":
            return np.array(obj["val"])
        elif obj_type == "custom_object":
            return deserialize_state(obj["val"])
        else:
            return {k: deserialize_state(v) for k, v in obj.items()}
    elif isinstance(obj, list):
        return [deserialize_state(v) for v in obj]
    else:
        return obj


# -------------NEAR-FAR AND AVERAGE EXPERIMENT---------------


# def get_average_experiment_circuit(L, M, polyA, polyB):
#     """
#     Builds the circuit of a memory experiment for a given code. It returns the circuit
#     in three parts: initialization, qec_cycle, readout.

#     If Distance_choice == False, the number of rounds in the syndrome extractino is equal to the distance.
#     If Distance_choice ==True, the number of rounds is determined from the input.
#     """
#     code = codes.BBCode(
#         {x: L, y: M},
#         polyA,
#         polyB,
#     )

#     distance_trials = 100
#     rounds = code.get_distance(bound=distance_trials)

#     # Collect the components of the memory experiment.  In particular, we will need the record
#     # of detectors and qubit indices.
#     (
#         initialization,
#         qec_cycle,
#         readout,
#         measurement_record,
#         detector_record,
#         qubit_ids,
#     ) = circuits.get_memory_experiment_parts(code, basis=None, num_rounds=rounds)

#     noise_model = circuits.DepolarizingNoiseModel(0, include_idling_error=False)
#     qec_cycle = noise_model.noisy_circuit(qec_cycle)
#     clean_circ = remove_noise_from_circuit(qec_cycle)

#     return (
#         initialization,
#         clean_circ,
#         readout,
#         measurement_record,
#         detector_record,
#         qubit_ids,
#     )
