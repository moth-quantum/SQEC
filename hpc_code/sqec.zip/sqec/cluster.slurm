#!/bin/bash

#SBATCH --job-name=array_analysis
#SBATCH --time=01:00:00
#SBATCH --qos=6hours
#SBATCH --ntasks=1
#SBATCH --cpus-per-task=4
#SBATCH --mem=16G
#SBATCH --array=1-600%20
#SBATCH --output=array_%A_%a.out
#SBATCH --error=array_%A_%a.err

cd ~/sqec

ARGS_FILE="arguments.txt"

TASK_ARGS=$(sed -n "${SLURM_ARRAY_TASK_ID}p" $ARGS_FILE)

.venv/bin/python Jobscript.py $TASK_ARGS
