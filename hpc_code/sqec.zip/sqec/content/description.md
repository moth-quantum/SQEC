## Overview

'Test Archeopteryx'

## Parameters

| Parameter | Type    | Default   | Description          |
|-----------|---------|-----------|----------------------|
| `example` | string  | `"hello"` | An example parameter |

## Output

```json
{
  "output": "Result for hello"
}
```
