def main():
    print("Hello from sqec!")


if __name__ == "__main__":
    main()
