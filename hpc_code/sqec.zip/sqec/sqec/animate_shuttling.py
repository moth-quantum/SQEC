from PIL import Image, ImageDraw, ImageFont
import math


def animate_shuttling(
    shuttling_routes,
    X,
    Y,
    color_dict=None,
    filename="shuttling_animation_pro.gif",
    fps=15,
    frames_between_ticks=20,
    pause_frames=5,
    cell_size=60,  # Pixels per grid square
):
    """function that takes in a list of shuttling routes (list of dicts of qubits to coordinates)
    and creates an animation of the shuttling process which highlights interactions between
    qubits when they occur.

    Args:
        shuttling_routes (shuttling_route): _description_
        X (int): X grid points
        Y (int): Y grid points
        color_dict (dict[int:colorstring], optional): dictionary of qubits to colors. Defaults to None.
        filename (str, optional): filename. Defaults to "shuttling_animation_pro.gif".
        fps (int, optional): frames per second - playback speed. Defaults to 15.
        frames_between_ticks (int, optional): smoothness of animation if higher. Defaults to 20.
        pause_frames (int, optional): how many frames for the interaction animation. Defaults to 5.
        cell_size (int, optional): resolution in pixels per cell. Defaults to 60.

    Returns:
        None: writes a file with the animation
    """
    if len(shuttling_routes) < 2:
        print("Not enough frames to animate.")
        return

    qubits = list(shuttling_routes[0].keys())
    if color_dict is None:
        color_dict = {q: "dodgerblue" for q in qubits}

    # Now we store exactly WHICH qubits are meeting WHERE
    interacting_groups_per_tick = []
    for route in shuttling_routes:
        coord_to_qs = {}
        for q, pos in route.items():
            coord_to_qs.setdefault(pos, []).append(q)

        # Keep only locations where 2 or more qubits are present
        interacting = {pos: qs for pos, qs in coord_to_qs.items() if len(qs) > 1}
        interacting_groups_per_tick.append(interacting)

    # Helper: Determine the visual offset for a qubit at a specific tick
    def get_offset(q, tick_idx):
        if tick_idx >= len(interacting_groups_per_tick):
            return 0.0, 0.0

        interactions = interacting_groups_per_tick[tick_idx]
        for pos, qs in interactions.items():
            if q in qs:
                if len(qs) == 2:
                    # If it's a pair, push one left (-0.22) and one right (+0.22)
                    idx = qs.index(q)
                    return (-0.22 if idx == 0 else 0.22), 0.0
                else:
                    # Fallback for >2 qubits: arrange in a circle
                    idx = qs.index(q)
                    angle = 2 * math.pi * idx / len(qs)
                    return 0.22 * math.cos(angle), 0.22 * math.sin(angle)
        # Solo qubit, no offset
        return 0.0, 0.0

    img_width = X * cell_size
    img_height = Y * cell_size
    base_img = Image.new("RGB", (img_width, img_height), "white")
    draw_base = ImageDraw.Draw(base_img)

    for x in range(X):
        px = int((x + 0.5) * cell_size)
        draw_base.line([(px, 0), (px, img_height)], fill="lightgray", width=1)
    for y in range(Y):
        py = int((y + 0.5) * cell_size)
        draw_base.line([(0, py), (img_width, py)], fill="lightgray", width=1)

    try:
        font = ImageFont.truetype("arial.ttf", 14)
    except IOError:
        try:
            font = ImageFont.load_default(size=14)
        except TypeError:
            font = ImageFont.load_default()

    def to_pixels(cx, cy):
        px = int((cx + 0.5) * cell_size)
        py = int(img_height - (cy + 0.5) * cell_size)
        return px, py

    total_expected = (len(shuttling_routes) - 1) * (frames_between_ticks + pause_frames)
    print(f"Generating frames (Expected: {total_expected} frames)")
    frames = []

    for tick_idx in range(len(shuttling_routes) - 1):
        current_coord = shuttling_routes[tick_idx]
        next_coord = shuttling_routes[tick_idx + 1]

        # movement
        for sub_frame in range(frames_between_ticks):
            img = base_img.copy()
            draw = ImageDraw.Draw(img)
            progress = sub_frame / frames_between_ticks

            for q in qubits:
                x1, y1 = current_coord[q]
                x2, y2 = next_coord[q]

                # Manhattan route - not reflective of real route
                if progress < 0.5:
                    p_x = progress * 2
                    base_x = x1 + (x2 - x1) * p_x
                    base_y = y1
                else:
                    p_y = (progress - 0.5) * 2
                    base_x = x2
                    base_y = y1 + (y2 - y1) * p_y

                #  offset to show both cells
                off1_x, off1_y = get_offset(q, tick_idx)
                off2_x, off2_y = get_offset(q, tick_idx + 1)

                cur_off_x = off1_x + (off2_x - off1_x) * progress
                cur_off_y = off1_y + (off2_y - off1_y) * progress

                px, py = to_pixels(base_x + cur_off_x, base_y + cur_off_y)

                # Draw main dot
                r = cell_size * 0.22
                q_val = getattr(q, "value", q)
                draw.ellipse(
                    [px - r, py - r, px + r, py + r],
                    fill=color_dict.get(q_val, "dodgerblue"),
                )

                # Draw label

                draw.text((px, py), str(q_val), fill="white", font=font, anchor="mm")

            frames.append(img)

        # Interaction Phase
        for sub_frame in range(pause_frames):
            img = base_img.copy()
            draw = ImageDraw.Draw(img)

            interactions = interacting_groups_per_tick[tick_idx + 1]
            for pos, qs in interactions.items():
                px, py = to_pixels(pos[0], pos[1])
                blink_color = "gold" if sub_frame % 2 == 0 else "darkorange"

                if len(qs) == 2:
                    r_x = cell_size * 0.48  # Wide enough to cover both
                    r_y = cell_size * 0.30  # Standard height
                    draw.rounded_rectangle(
                        [px - r_x, py - r_y, px + r_x, py + r_y],
                        radius=int(cell_size * 0.3),
                        outline=blink_color,
                        width=3,
                    )
                else:
                    # Draw a big circle if > 2 qubits (failsafe)
                    r = cell_size * 0.45
                    draw.ellipse(
                        [px - r, py - r, px + r, py + r], outline=blink_color, width=3
                    )

            # 2. Draw the Qubits on top
            for q in qubits:
                base_x, base_y = next_coord[q]
                off_x, off_y = get_offset(q, tick_idx + 1)

                px, py = to_pixels(base_x + off_x, base_y + off_y)

                r = cell_size * 0.22
                q_val = getattr(q, "value", q)
                draw.ellipse(
                    [px - r, py - r, px + r, py + r],
                    fill=color_dict.get(q_val, "dodgerblue"),
                )

                draw.text((px, py), str(q_val), fill="white", font=font, anchor="mm")

            frames.append(img)

    frame_duration = int(1000 / fps)
    frames[0].save(
        filename,
        save_all=True,
        append_images=frames[1:],
        duration=frame_duration,
        loop=0,
    )
    print(f"Animation successfully saved to {filename}!")


if __name__ == "__main__":
    import networkx as nx
    import Merlin.create_qubit_layout as cql
    from sympy.abc import x, y
    import numpy as np
    from qldpc import codes
    import Merlin.combined_memory_experiment as cmex
    import Merlin.BB_codes as BBcodes

    codes_to_simulate = [
        codes.BBCode(
            {x: 6, y: 6},
            x**3 + y + y**2,
            y**3 + x + x**2,
        )
    ]

    L = 6
    M = 6
    X = 2 * L
    Y = 2 * M

    A = []
    B = []

    A.append(BBcodes.create_x_matrix(3, L, M))
    A.append(BBcodes.create_y_matrix(1, L, M))
    A.append(BBcodes.create_y_matrix(2, L, M))

    B.append(BBcodes.create_y_matrix(3, L, M))
    B.append(BBcodes.create_x_matrix(1, L, M))
    B.append(BBcodes.create_x_matrix(3, L, M))

    Grid = nx.grid_2d_graph(X, Y, periodic=False, create_using=None)
    Grid_check = "Squaregrid"

    (
        data_qubit_list,
        check_qubit_list,
        qubit_list,
        qubit_type,
        code_matrix,
    ) = cql.get_key_data(A, B)

    # Choose error rates
    error_rates = list(np.logspace(-3, -1.5, 4))
    ratio_T1toT2 = 0
    ratio_T1toshuttlinghalf = 0.004
    (
        optimized_layout_init,
        Grid,
        X1,
        Y1,
        _,
        _,
        _,
    ) = cql.get_optimized_qubit_layout_bipartate(A, B, L, M)
    optimized_layout = cql.translate_dictionary(optimized_layout_init)
    decoding_kwargs = dict(
        with_BP_LSD=True, max_iter=30, bp_method="ms", lsd_method="lsd_cs", lsd_order=0
    )
    exp = cmex.combinedMemoryExperiment(
        codes_to_simulate,
        error_rates,
        Grid=Grid,
        X=X1,
        Y=Y1,
        Grid_check=Grid_check,
        starting_coord=optimized_layout,
        ratio_T1toT2=ratio_T1toT2,
    )
    exp.run_combined_memory_experiments(**decoding_kwargs)
    shuttling_routes = exp.shuttling_schedules[0]
    ### CONSTRTUCT COLOR DICT
    my_color_dict = {}
    for q in qubit_list:
        if q[1] == "L":
            my_color_dict[q[0]] = "blue"
        elif q[1] == "R":
            my_color_dict[q[0]] = "orange"
        elif q[1] == "X":
            my_color_dict[q[0]] = "crimson"
        elif q[1] == "Z":
            my_color_dict[q[0]] = "forestgreen"
    ### HOW TO CALL FUCNTION
    animate_shuttling(
        shuttling_routes=shuttling_routes,
        X=X,
        Y=Y,
        color_dict=my_color_dict,
        filename="bb_code_routing_fast.gif",
        fps=10,  # Higher fps = smoother
        frames_between_ticks=30,
        pause_frames=5,  # Higher number = slower movement between ticks
    )
