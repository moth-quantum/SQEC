import stim
import networkx as nx
import Merlin.add_shuttling_noise as sn
from Merlin.create_qubit_layout import create_qubit_layout


def create_qubit_list(code_matrix):
    rows = len(code_matrix)
    columns = len(code_matrix[0])
    data_qubit_list = []
    check_qubit_list = []
    qubit_type = {}
    for i in range(rows):
        if i < rows // 2:
            data_qubit_list.append((i, "L"))
            qubit_type[(i, "L")] = "L"
        else:
            data_qubit_list.append((i, "R"))
            qubit_type[(i, "R")] = "R"

    for i in range(columns):
        if i < columns // 2:
            check_qubit_list.append((rows + i, "X"))
            qubit_type[(rows + i, "X")] = "X"

        else:
            check_qubit_list.append((rows + i, "Z"))
            qubit_type[(rows + i, "Z")] = "Z"

    qubit_list = data_qubit_list + check_qubit_list

    return data_qubit_list, check_qubit_list, qubit_list, qubit_type


def get_qubit_coordinates(qubit_list, qubit_type, L, M):
    i = 0
    qubit_coordinates = {}
    for qubit in qubit_list:
        if qubit_type[qubit] == "L":
            qubit_coordinates[qubit] = (2 * ((i // M) % L), 2 * (i % M) + 1)
        if qubit_type[qubit] == "R":
            qubit_coordinates[qubit] = (2 * ((i // M) % L) + 1, 2 * (i % M))
        if qubit_type[qubit] == "Z":
            qubit_coordinates[qubit] = (2 * ((i // M) % L), 2 * (i % M))
        if qubit_type[qubit] == "X":
            qubit_coordinates[qubit] = (2 * ((i // M) % L) + 1, 2 * (i % M) + 1)
        i = i + 1

    return qubit_coordinates


def get_neighbours(A, B):
    """
    Takes two lists of matrices (three matrices each) and considers the BB code induced by these two lists.
    Returns a dictionary 'neighbours' that associates to every qubit q a dictionary that provides the A1, A2, A3, B1, B2, B3 neighbours
    of q.
    """
    code_matrix = get_parity_check_matrix(A, B)
    data_qubit_list, check_qubit_list, _, qubit_type = create_qubit_list(code_matrix)
    A_t = transpose(A)
    B_t = transpose(B)
    neighbours = {}
    for data_qubit in data_qubit_list:
        for check_qubit in check_qubit_list:
            neighbours[data_qubit] = {}
            neighbours[check_qubit] = {}
    for data_qubit in data_qubit_list:
        if (
            qubit_type[data_qubit] == "L"
        ):  # For L-qubits, the A-matrices indicate the X-checks and the B-matrices indicate the Z-checks
            for check_qubit in check_qubit_list:
                if check_qubit[0] < len(data_qubit_list) + len(A[0]):
                    if (
                        A[0][check_qubit[0] - len(data_qubit_list)][
                            data_qubit[0] % len(A[0])
                        ]
                        == 1
                    ):
                        neighbours[data_qubit]["A1"] = check_qubit
                        neighbours[check_qubit]["A1"] = data_qubit
                    if (
                        A[1][check_qubit[0] - len(data_qubit_list)][
                            data_qubit[0] % len(A[0])
                        ]
                        == 1
                    ):
                        neighbours[data_qubit]["A2"] = check_qubit
                        neighbours[check_qubit]["A2"] = data_qubit
                    if (
                        A[2][check_qubit[0] - len(data_qubit_list)][
                            data_qubit[0] % len(A[0])
                        ]
                        == 1
                    ):
                        neighbours[data_qubit]["A3"] = check_qubit
                        neighbours[check_qubit]["A3"] = data_qubit
                if check_qubit[0] >= len(data_qubit_list) + len(A[0]):
                    if (
                        B_t[0][check_qubit[0] - len(data_qubit_list) - len(A[0])][
                            data_qubit[0] % len(A[0])
                        ]
                        == 1
                    ):
                        neighbours[data_qubit]["B1"] = check_qubit
                        neighbours[check_qubit]["B1"] = data_qubit
                    if (
                        B_t[1][check_qubit[0] - len(data_qubit_list) - len(A[0])][
                            data_qubit[0] % len(A[0])
                        ]
                        == 1
                    ):
                        neighbours[data_qubit]["B2"] = check_qubit
                        neighbours[check_qubit]["B2"] = data_qubit
                    if (
                        B_t[2][check_qubit[0] - len(data_qubit_list) - len(A[0])][
                            data_qubit[0] % len(A[0])
                        ]
                        == 1
                    ):
                        neighbours[data_qubit]["B3"] = check_qubit
                        neighbours[check_qubit]["B3"] = data_qubit

        if (
            qubit_type[data_qubit] == "R"
        ):  # For R-qubits, the A-matrices indicate the Z-checks and the B-matrices indicate the X-checks
            for check_qubit in check_qubit_list:
                if check_qubit[0] >= len(data_qubit_list) + len(A[0]):
                    if (
                        A_t[0][check_qubit[0] - len(data_qubit_list) - len(A[0])][
                            data_qubit[0] % len(A[0])
                        ]
                        == 1
                    ):
                        neighbours[data_qubit]["A1"] = check_qubit
                        neighbours[check_qubit]["A1"] = data_qubit
                    if (
                        A_t[1][check_qubit[0] - len(data_qubit_list) - len(A[0])][
                            data_qubit[0] % len(A[0])
                        ]
                        == 1
                    ):
                        neighbours[data_qubit]["A2"] = check_qubit
                        neighbours[check_qubit]["A2"] = data_qubit
                    if (
                        A_t[2][check_qubit[0] - len(data_qubit_list) - len(A[0])][
                            data_qubit[0] % len(A[0])
                        ]
                        == 1
                    ):
                        neighbours[data_qubit]["A3"] = check_qubit
                        neighbours[check_qubit]["A3"] = data_qubit
                if check_qubit[0] < len(data_qubit_list) + len(A[0]):
                    if (
                        B[0][check_qubit[0] - len(data_qubit_list)][
                            data_qubit[0] % len(A[0])
                        ]
                        == 1
                    ):
                        neighbours[data_qubit]["B1"] = check_qubit
                        neighbours[check_qubit]["B1"] = data_qubit
                    if (
                        B[1][check_qubit[0] - len(data_qubit_list)][
                            data_qubit[0] % len(A[0])
                        ]
                        == 1
                    ):
                        neighbours[data_qubit]["B2"] = check_qubit
                        neighbours[check_qubit]["B2"] = data_qubit
                    if (
                        B[2][check_qubit[0] - len(data_qubit_list)][
                            data_qubit[0] % len(A[0])
                        ]
                        == 1
                    ):
                        neighbours[data_qubit]["B3"] = check_qubit
                        neighbours[check_qubit]["B3"] = data_qubit

    return neighbours


def build_Tanner_graph(code_matrix, neighbours):
    _, _, qubit_list, _ = create_qubit_list(code_matrix)
    # coord = get_qubit_coordinates(code_matrix, l, m)
    Tanner_graph = nx.Graph()
    for qubit in qubit_list:
        Tanner_graph.add_node(qubit)
    for qubit in qubit_list:
        for neighbour in neighbours[qubit].values():
            Tanner_graph.add_edge(qubit, neighbour)

    return Tanner_graph


def transpose(matrix_list):
    transposed_list = []
    for A in matrix_list:
        A_transposed = []
        for j in range(len(A)):
            vect = []
            for i in range(len(A[0])):
                vect.append(A[i][j])
            A_transposed.append(vect)
        transposed_list.append(A_transposed)

    return transposed_list


def get_parity_check_matrix(A, B):
    """
    Given two lists of three matrices each, we define the parity check matrix of the associated BB code.
    """
    # Defines the two matrices A and B
    A_full = []
    B_full = []
    for i in range(len(A[0])):
        rowA = []
        rowB = []
        for j in range(len(A[0][0])):
            rowA.append(A[0][i][j] + A[1][i][j] + A[2][i][j])
            rowB.append(B[0][i][j] + B[1][i][j] + B[2][i][j])

        A_full.append(rowA)
        B_full.append(rowB)

    # Defines the transpose of the two matrices above
    A_transposed = []
    for j in range(len(A_full)):
        vect = []
        for i in range(len(A_full[0])):
            vect.append(A_full[i][j])
        A_transposed.append(vect)

    B_transposed = []
    for j in range(len(B_full)):
        vect = []
        for i in range(len(B_full[0])):
            vect.append(B_full[i][j])
        B_transposed.append(vect)

    # Defines the full parity check matrix.
    X_checks = []
    Z_checks = []

    for i in range(len(A_full)):
        X_checks.append(A_full[i] + B_full[i])
        Z_checks.append(A_transposed[i] + B_transposed[i])

    code_matrix = X_checks + Z_checks

    return code_matrix


def get_qec_cycle(A, B, L, M, distance, strategy):
    qec_cycle = stim.Circuit()
    """
    Build the middle part of the syndrome extraction circuit.

    Args:
        A and B are two lists of three matrices each. They indicate the six matrices that go into building the code_matrix of the associated BB-code.

        'strategy' is a sequence of pairs (a,b) where a, b are in 1, 2, 3, 4, 5, 6. The first element of the tuple indicates
        which of their matrices the L-qubits do in this TICK (A1, A2, A3, B1t, B2t, B3t),
        the second element indicates which matrix the R-qubits do in this TICK (B1, B2, B3, A1t, A2t, A3t).

        For the BB codes with the special Tannergraph layout, 1 stands for the identity, 2 stands for x and y respectively,
        while 3 stands for the factor that can vary.

        WARNING: This function inserts ticks assuming that for each tuple in 'strategy', we task the L-qubits to do one type of check and R-qubits to do the other type.
        Formally, this means that each tuple (a,b) in strategy needs to satisfy a // 3 != b // 3.
    """
    code_matrix = get_parity_check_matrix(A, B)

    data_qubits, check_qubits, qubit_list, qubit_type = create_qubit_list(code_matrix)

    neighbours = get_neighbours(A, B)

    # Tanner_graph = build_Tanner_graph(code_matrix)

    for step in strategy:
        Lcolour, Rcolour = step
        for qubit in data_qubits:
            if qubit_type[qubit] == "L":
                if Lcolour < 4:  # These are the X-checks
                    qec_cycle.append(
                        "CX", [qubit[0], neighbours[qubit][f"A{Lcolour}"][0]]
                    )
                elif Lcolour > 3:  # These are the Z-checks
                    qec_cycle.append(
                        "CX", [neighbours[qubit][f"B{Lcolour - 3}"][0], qubit[0]]
                    )
            if qubit_type[qubit] == "R":
                if Rcolour < 4:  # These are the X-checks
                    qec_cycle.append(
                        "CX", [qubit[0], neighbours[qubit][f"B{Rcolour}"][0]]
                    )
                if Rcolour > 3:  # These are the Z-checks
                    qec_cycle.append(
                        "CX", [neighbours[qubit][f"A{Rcolour - 3}"][0], qubit[0]]
                    )
        qec_cycle.append("TICK")

    # print(qubit_list)

    return qec_cycle


def create_x_matrix(exponent, L, M):
    matrix = []

    for row in range(L * M):
        vect = []
        for block in range(L):
            if (row // M) == (block + exponent) % L:
                for j in range(M):
                    if j == row % M:
                        vect.append(1)
                    else:
                        vect.append(0)
            else:
                vect = vect + [0] * M
        matrix.append(vect)

    return matrix


def create_y_matrix(exponent, L, M):
    matrix = []
    for row in range(L * M):
        vect = []
        for block in range(L):
            if (row // M) == block:
                for j in range(M):
                    if j == (row % M + exponent) % M:
                        vect.append(1)
                    else:
                        vect.append(0)
            else:
                vect = vect + [0] * M
        matrix.append(vect)

    return matrix


L = 6
M = 6


A = []
B = []

A.append(create_x_matrix(3, L, M))
A.append(create_y_matrix(1, L, M))
A.append(create_y_matrix(2, L, M))


B.append(create_y_matrix(3, L, M))
B.append(create_x_matrix(1, L, M))
B.append(create_x_matrix(3, L, M))

strategy = [(1, 4), (2, 5), (3, 6), (4, 1), (5, 2), (6, 3)]
# strategy = [ (1,6), (2,5), (3,4), (4,2), (5,3), (6,1) ]

distance = 0

parity_matrix = get_parity_check_matrix(A, B)


# data_qubits, check_qubits, qubit_list, qubit_type = create_qubit_list(code_matrix)
# coords = get_qubit_coordinates(qubit_list, qubit_type, l, m)
# neighbours = get_neighbours(code_matrix)
# TG = build_Tanner_graph(code_matrix, neighbours)

# print(qubit_list)
# print(coords)
# print(neighbours)
# nx.draw(TG, with_labels=True, font_weight='bold')

qec_cycle = get_qec_cycle(A, B, L, M, distance, strategy)

qubit_list = sn.create_qubit_list(qec_cycle)
X = 2 * L
Y = 2 * M
Grid = nx.grid_2d_graph(X, Y, periodic=False, create_using=None)
p_base = 0.001

starting_coord = create_qubit_layout(qubit_list, X, Y)

noisy_circuit = sn.add_shuttling_noise(qec_cycle, starting_coord, Grid, p_base)

# qec_cycle.diagram("timeline-svg")
noisy_circuit.diagram("timeline-svg")
