# %%
import stim

TWO_QUBIT_GATES = {
    "CX",
    "CY",
    "CZ",
    "ISWAP",
    "SWAP",
    "XCX",
    "XCY",
    "XCZ",
    "YCX",
    "YCY",
    "YCZ",
    "ZCX",
    "ZCY",
    "ZCZ",
    "SQRT_XX",
    "SQRT_XX_DAG",
    "SQRT_YY",
    "SQRT_YY_DAG",
    "SQRT_ZZ",
    "SQRT_ZZ_DAG",
    "DEPOLARIZE2",
    "MXX",
    "MYY",
    "MZZ",
}

SINGLE_QUBIT_GATES = {
    "I",
    "X",
    "Y",
    "Z",
    "C_NXYZ",
    "C_NZYX",
    "C_XNYZ",
    "C_XYNZ",
    "C_XYZ",
    "C_ZNYX",
    "C_ZYNX",
    "C_ZYX",
    "H",
    "H_NXY",
    "H_NXZ",
    "H_NYZ",
    "H_XY",
    "H_XZ",
    "H_YZ",
    "S",
    "SQRT_X",
    "SQRT_X_DAG",
    "SQRT_Y",
    "SQRT_Y_DAG",
    "SQRT_Z",
    "SQRT_Z_DAG",
    "S_DAG",
}

NOISE_GATES_SINGLE = {
    "DEPOLARIZE1",
    "E",
    "HERALDED_ERASE",
    "HERALDED_PAULI_CHANNEL_1",
    "I_ERROR",
    "PAULI_CHANNEL_1",
    "X_ERROR",
    "Y_ERROR",
    "Z_ERROR",
}

NOISE_GATES_MULTIPLE = {
    "CORRELATED_ERROR",
    "DEPOLARIZE2",
    "ELSE_CORRELATED_ERROR",
    "II_ERROR",
    "PAULI_CHANNEL_2",
}


def apply_custom_noise(ideal_circuit: stim.Circuit, noise_map: dict) -> stim.Circuit:
    """
    Takes an ideal circuit and appends custom noise based on the qubit pair or solo qubit.
    1Q gates: Noise placed AFTER the gate.
    2Q gates: 1Q noise placed BEFORE the gate, 2Q noise placed AFTER the gate.
    """
    noisy_circuit = stim.Circuit()

    for inst in ideal_circuit:
        if inst.name not in TWO_QUBIT_GATES and inst.name not in SINGLE_QUBIT_GATES:
            noisy_circuit.append(inst)
            continue

        targets = inst.targets_copy()

        if inst.name in TWO_QUBIT_GATES:
            for i in range(0, len(targets), 2):
                t1 = targets[i]
                t2 = targets[i + 1]

                noise_def = noise_map.pop((t1, t2))

                noise_before = []
                noise_after = []

                if noise_def is not None:
                    for noise_entry in noise_def:
                        noise_gate, noise_args, noise_qubits = noise_entry
                        if len(noise_qubits) == 1:
                            noise_before.append(noise_entry)
                        else:
                            noise_after.append(noise_entry)

                for noise_gate, noise_args, noise_qubits in noise_before:
                    noisy_circuit.append(noise_gate, noise_qubits, noise_args)

                noisy_circuit.append(inst.name, [t1, t2], inst.gate_args_copy())

                for noise_gate, noise_args, noise_qubits in noise_after:
                    noisy_circuit.append(noise_gate, noise_qubits, noise_args)

        elif inst.name in SINGLE_QUBIT_GATES:
            for i in range(0, len(targets)):
                t1 = targets[i]

                noisy_circuit.append(
                    inst.name, [t1], inst.gate_args_copy()
                )  # Is this line causing the noise to be added twice? Once here and once 6 lines below?

                noise_def = noise_map.pop((t1, "solo"))
                if noise_def is not None:
                    for noise_entry in noise_def:
                        noise_gate, noise_args, noise_qubits = noise_entry
                        noisy_circuit.append(noise_gate, noise_qubits, noise_args)
    for entry in noise_map:
        if noise_map[entry] is not None:
            for noise_entry in noise_map[entry]:
                noise_gate, noise_args, noise_qubits = noise_entry
                noisy_circuit.append(noise_gate, noise_qubits, noise_args)
    return noisy_circuit


def remove_noise_from_circuit(
    noisy_circuit: stim.Circuit,
    noise_gates: set = NOISE_GATES_SINGLE.union(NOISE_GATES_MULTIPLE),
) -> stim.Circuit:
    """
    Removes specified noise gates from a circuit, leaving ticks.

    :param noisy_circuit: The stim.Circuit containing noise.
    :param noise_gates: A set of gate names to remove from the circuit.
    :return: A new stim.Circuit with the specified noise gates removed.
    """
    noisy_circuit = noisy_circuit.flattened()
    cleaned_circuit = stim.Circuit()

    for inst in noisy_circuit:
        if inst.name not in noise_gates:
            cleaned_circuit.append(
                inst.name, inst.targets_copy(), inst.gate_args_copy()
            )

    return cleaned_circuit


def insert_ticks_greedily(circuit: stim.Circuit) -> stim.Circuit:
    """
    Takes a STIM circuit and adds TICK commands by greedily
    grouping unpacked instructions into parallel time slices.
    """
    flat_circuit = circuit.flattened()
    ticked_circuit = stim.Circuit()
    current_layer = stim.Circuit()
    busy_qubits = set()

    #  2-qubit gates to know when to grab targets in pairs
    TWO_QUBIT_GATES = {
        "CX",
        "CY",
        "CZ",
        "ISWAP",
        "SWAP",
        "XCX",
        "XCY",
        "XCZ",
        "YCX",
        "YCY",
        "YCZ",
        "ZCX",
        "ZCY",
        "ZCZ",
        "SQRT_XX",
        "SQRT_XX_DAG",
        "SQRT_YY",
        "SQRT_YY_DAG",
        "SQRT_ZZ",
        "SQRT_ZZ_DAG",
        "DEPOLARIZE2",
        "MXX",
        "MYY",
        "MZZ",
    }

    #  annotations/gates that shouldn't be blindly chunked
    NO_SPLIT_GATES = {
        "DETECTOR",
        "OBSERVABLE_INCLUDE",
        "QUBIT_COORDS",
        "SHIFT_COORDS",
        "MPP",
        "SPP",
        "CORRELATED_ERROR",
        "ELSE_CORRELATED_ERROR",
        "E",
    }

    for inst in flat_circuit:
        if inst.name == "TICK":
            if len(current_layer) > 0:
                ticked_circuit += current_layer
                ticked_circuit.append("TICK")
                current_layer = stim.Circuit()
                busy_qubits.clear()
            else:
                ticked_circuit.append("TICK")
            continue

        targets = inst.targets_copy()
        args = inst.gate_args_copy()

        # Determine the target chunk size based on the gate type
        if inst.name in TWO_QUBIT_GATES:
            chunk_size = 2
        elif inst.name in NO_SPLIT_GATES:
            chunk_size = max(1, len(targets))  # Keep whole
        else:
            chunk_size = 1

        # Process targets in chunks (1-by-1, 2-by-2, etc.)
        for i in range(0, len(targets), chunk_size):
            chunk = targets[i : i + chunk_size]

            # Identify qubit targets (not record targets, etc.)
            op_qubits = {t.value for t in chunk if t.is_qubit_target}

            # Collision check for this specific micro-operation
            if not op_qubits.isdisjoint(busy_qubits):
                ticked_circuit += current_layer
                ticked_circuit.append("TICK")
                current_layer = stim.Circuit()
                busy_qubits.clear()

            current_layer.append(inst.name, chunk, args)
            busy_qubits.update(op_qubits)

    if len(current_layer) > 0:
        ticked_circuit += current_layer

    return ticked_circuit


def split_at_ticks(circuit: stim.Circuit) -> list[stim.Circuit]:
    """
    Splits a STIM circuit into a list of circuits based on TICK instructions.
    The TICK instructions are consumed/removed in the output list.
    """
    parts = []
    current_part = stim.Circuit()

    for inst in circuit:
        if inst.name == "TICK":
            parts.append(current_part)
            current_part = stim.Circuit()
        else:
            current_part.append(inst)

    parts.append(current_part)

    return parts


def reassemble_circuit(parts: list[stim.Circuit], insert_ticks=True) -> stim.Circuit:
    """
    Takes a list of STIM circuits and reassembles them into a single
    circuit, inserting a TICK between each part.
    """
    reassembled = stim.Circuit()

    for i, part in enumerate(parts):
        reassembled += part
        if (i < len(parts) - 1) and insert_ticks:
            reassembled.append("TICK")  # adding ticks back in for ease of use

    return reassembled
