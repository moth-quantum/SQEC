"""'Test Archeopteryx'"""

from pydantic import BaseModel, Field

try:
    from archaeo_sdk import EngineError, update_progress
except ImportError:

    class EngineError(Exception):
        """Fail a job immediately without retrying."""

    def update_progress(step: str, message: str = "") -> None:
        """Signal progress back to the platform (no-op when running locally)."""


class Params(BaseModel):
    # Every field must have a default so that run(None) works as a smoke test.
    example: str = Field(default="hello", description="An example parameter")


def run(params: dict | None) -> dict:
    p = Params(**(params or {}))

    update_progress("run", "Processing")

    return {
        "output": f"Result for {p.example}",
    }


if __name__ == "__main__":
    result = run(None)
    print(result)
