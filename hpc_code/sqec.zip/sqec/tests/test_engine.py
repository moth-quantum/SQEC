"""Tests for archaeo validate."""

from engine import Params, run


class TestParams:
    def test_defaults(self):
        p = Params()
        assert p.example == "hello"


class TestRun:
    def test_returns_output(self):
        result = run(None)
        assert "output" in result
