import unittest
import stim
from sqec.modify_stim_circuit import (
    apply_custom_pair_noise,
    remove_noise_from_circuit,
    insert_ticks_greedily,
    split_at_ticks,
    reassemble_circuit,
)


class TestCustomNoise(unittest.TestCase):
    def test_apply_custom_pair_noise_standard_case(self):
        ideal = stim.Circuit(
            """
            H 0 1 2
            CX 0 1
            CX 1 2
            M 0 1 2
        """
        )

        custom_noise = {
            (0, 1): [
                ("DEPOLARIZE1", [0.01], (0,)),
                ("DEPOLARIZE1", [0.03], (1,)),
                ("DEPOLARIZE2", [0.02], (0, 1)),
            ],
            (1, 2): [("PAULI_CHANNEL_2", [0.001] * 14 + [0.05], (1, 2))],
        }
        expected_circuit = stim.Circuit(
            """
            H 0 1 2
            CX 0 1 1 2
            DEPOLARIZE1(0.01) 0
            DEPOLARIZE1(0.03) 1
            DEPOLARIZE2(0.02) 0 1
            PAULI_CHANNEL_2(0.001, 0.001, 0.001, 0.001, 0.001, 0.001, 0.001, 0.001, 0.001, 0.001, 0.001, 0.001, 0.001, 0.001, 0.05) 1 2
            M 0 1 2
        """
        )

        result_circuit = apply_custom_pair_noise(ideal, custom_noise)

        self.assertEqual(str(result_circuit), str(expected_circuit))

    def test_no_noise_mapping(self):
        """Test that if the pair is not in the map, no noise is added."""
        ideal = stim.Circuit("CX 5 6")
        noise_map = {(0, 1): [("DEPOLARIZE1", [0.1], (0,))]}

        result = apply_custom_pair_noise(ideal, noise_map)
        self.assertEqual(str(result), "CX 5 6")

    def test_remove_noise_from_circuit(self):
        noisy_circuit = stim.Circuit(
            """
            H 0 1 2
            DEPOLARIZE1(0.01) 0
            DEPOLARIZE1(0.03) 1
            DEPOLARIZE1(0.02) 2
            TICK
            CX 0 1
            DEPOLARIZE2(0.02) 0 1
            TICK
            CX 1 2
            PAULI_CHANNEL_2(0.001, 0.001, 0.001, 0.001, 0.001, 0.001, 0.001, 0.001, 0.001, 0.001, 0.001, 0.001, 0.001, 0.001, 0.05) 1 2
            TICK
            M 0 1 2
        """
        )
        noise_gates = {"DEPOLARIZE1", "DEPOLARIZE2", "PAULI_CHANNEL_2"}
        ideal = stim.Circuit(
            """
            H 0 1 2
            TICK
            CX 0 1
            TICK
            CX 1 2
            TICK
            M 0 1 2
        """
        )
        result = remove_noise_from_circuit(noisy_circuit, noise_gates)
        self.assertEqual(str(result), str(ideal))


class TestStimCircuitEditor(unittest.TestCase):
    def test_insert_ticks_greedily_chaining(self):
        """Tests that chained instructions causing collisions are split with TICKs."""
        raw_circuit = stim.Circuit(
            """
            H 0 1 2
            CX 0 1 1 2
            CX 1 2
            M 0 1 2
        """
        )
        expected_circuit = stim.Circuit(
            """
            H 0 1 2
            TICK
            CX 0 1
            TICK
            CX 1 2
            TICK
            CX 1 2
            M 0
            TICK
            M 1 2
        """
        )
        self.assertEqual(insert_ticks_greedily(raw_circuit), expected_circuit)

    def test_insert_ticks_greedily_no_collisions(self):
        """Tests that parallel operations on disjoint qubits do not trigger TICKs."""
        raw_circuit = stim.Circuit(
            """
            H 0 1 2
            CX 0 1 2 3
            M 0 1 2 3
        """
        )
        # Because the CX targets are completely disjoint, they should stay in one tick block
        expected_circuit = stim.Circuit(
            """
            H 0 1 2
            TICK
            CX 0 1 2 3
            TICK
            M 0 1 2 3
        """
        )
        self.assertEqual(insert_ticks_greedily(raw_circuit), expected_circuit)

    def test_insert_ticks_greedily_preserves_manual_ticks(self):
        """Tests that existing TICKs in the raw circuit are respected."""
        raw_circuit = stim.Circuit(
            """
            H 0
            TICK
            H 0
        """
        )
        self.assertEqual(insert_ticks_greedily(raw_circuit), raw_circuit)

    def test_insert_ticks_greedily_annotations(self):
        """Tests that measurement records and annotations do not cause false collisions."""
        raw_circuit = stim.Circuit(
            """
            M 0 1
            DETECTOR(1, 2) rec[-1] rec[-2]
            OBSERVABLE_INCLUDE(0) rec[-1]
        """
        )
        # Since records are not qubits, they shouldn't trigger a new TICK
        self.assertEqual(insert_ticks_greedily(raw_circuit), raw_circuit)

    def test_split_at_ticks(self):
        """Tests that a circuit is properly divided into a list of tick-free circuits."""
        ticked_circuit = stim.Circuit(
            """
            H 0
            TICK
            CX 0 1
            TICK
            M 0 1
        """
        )
        parts = split_at_ticks(ticked_circuit)

        self.assertEqual(len(parts), 3)
        self.assertEqual(parts[0], stim.Circuit("H 0"))
        self.assertEqual(parts[1], stim.Circuit("CX 0 1"))
        self.assertEqual(parts[2], stim.Circuit("M 0 1"))

    def test_split_at_empty_ticks(self):
        """Tests behavior when multiple TICKs are adjacent or trailing."""
        ticked_circuit = stim.Circuit("H 0 \n TICK \n TICK \n H 1 \n TICK")
        parts = split_at_ticks(ticked_circuit)

        self.assertEqual(len(parts), 4)
        self.assertEqual(parts[0], stim.Circuit("H 0"))
        self.assertEqual(parts[1], stim.Circuit())  # Empty circuit between ticks
        self.assertEqual(parts[2], stim.Circuit("H 1"))
        self.assertEqual(parts[3], stim.Circuit())  # Empty trailing circuit

    def test_reassemble_circuit(self):
        """Tests that parts are correctly stitched back together with TICKs."""
        parts = [stim.Circuit("H 0"), stim.Circuit("CX 0 1"), stim.Circuit("M 0 1")]
        expected_circuit = stim.Circuit(
            """
            H 0
            TICK
            CX 0 1
            TICK
            M 0 1
        """
        )
        self.assertEqual(reassemble_circuit(parts), expected_circuit)

    def test_integration_roundtrip(self):
        """Tests that splitting and reassembling a ticked circuit yields the original circuit."""
        original_circuit = stim.Circuit(
            """
            H 0 1 2
            TICK
            CX 0 1
            TICK
            CX 1 2
            TICK
            M 0 1 2
        """
        )

        parts = split_at_ticks(original_circuit)
        reassembled = reassemble_circuit(parts)

        self.assertEqual(original_circuit, reassembled)


if __name__ == "__main__":
    unittest.main()
